//
// Created by Fabrizio on 6/21/20.
//

#ifndef BATTLESHIP1_PLAYER_T_H
#define BATTLESHIP1_PLAYER_T_H
#include "common_types.h"
#include "ship_t.h"
#include "tablero_t.h"

using hit_result_t = std::pair<std::unique_ptr<ship_t>&&, bool>;

class player_t {
    static bool isShipOutside(const rectangle_t& rect);
    bool isShipOverlap(const rectangle_t& rect);
public:
    // Attributes
    path_type path_;
    text_type token_;
    text_type prefix_;
    uuint_type next;
    std::vector<ship_t*> fleet_;
    tablero_t tablero;
    std::vector<char> ships = {'A','B','B','S','S','S','T','T','T','T'};
    std::map<char, int> shipSizes = {
            {'A', 4},
            {'B', 3},
            {'S', 2},
            {'T', 1}
    };
    // Constructors
    player_t() = default;
    player_t(const path_type& ,const text_type& );
    // Methods
    bool isfleetFull(char);
    bool canAddShip(const char&, const char&, const rectangle_t&);
    ship_t buildShip();
    hit_result_t hitShip(location_t location);
    dimension_t getDimension(const char&, const char&);
    bool areIntersected(const rectangle_t&, const char&, const char&);
};


#endif //BATTLESHIP1_PLAYER_T_H
