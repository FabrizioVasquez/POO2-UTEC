//
// Created by Fabrizio on 6/21/20.
//

#include "player_t.h"
#include "utils.h"


player_t::player_t(const path_type &path, const text_type &prefix) {
    this->path_ = path;
    this->prefix_ = prefix;
    tablero.fill();
}

bool is_inside(const location_t& location, const rectangle_t& rectangle) {
    auto [x, y] = location;
    auto [l, d] = rectangle;
    return (x >= l.x && x < l.x + d.w && y >= l.y && y < l.y + d.h);
}

bool player_t::areIntersected(const rectangle_t& rect, const char& orientation, const char& model) {
    auto modelSize = shipSizes[model];
    if (orientation == 'H') {
        for (int i = 0; i < modelSize; i++) {
            if (tablero.table_[rect.first.y - 1][rect.first.x + i - 1] != '.')
                return true;
        }
    }
    if (orientation == 'V') {
        for (int i = 0; i < modelSize; i++) {
            if (tablero.table_[rect.first.y + i - 1][rect.first.x - 1] != '.')
                return true;
        }
    }

    return false;
}

bool player_t::isShipOutside(const rectangle_t& rect) {
    const rectangle_t battle_field = {{0, 0}, {10, 10}};
    auto [loc, dim] = rect;
    auto x1 = loc.x;
    auto y1 = loc.y;
    auto x2 = x1 + dim.w - 1;
    auto y2 = y1 + dim.h - 1;
    return !(
            is_inside({ x1, y1 }, battle_field) &&
            is_inside({ x1, y2 }, battle_field) &&
            is_inside({ x2, y1 }, battle_field) &&
            is_inside({ x2, y2 }, battle_field));
}

ship_t player_t::buildShip() {
    int TAM = 0;
    // Get random values
    int position_g, row;
    char model, column, orientation;
    location_t location{}; dimension_t dimension{};

    model = ships.back();
    orientation = rand_char_orientation();
    do {
        column = rand_char_column();
        row = rand_int(1, 10);
        //std::cout << row << " " << column << std::endl;
        location = {column - 64, row};
        dimension = getDimension(model, orientation);
    }while (!canAddShip(model, orientation, std::make_pair(location, dimension)));

    std::cout << "Ship "<< model << " added at position: " << char(location.x + 64) <<
    " , " << location.y << " in " << orientation<< std::endl;
    auto newShip = new ship_t(model, column, row, orientation, dimension);
    fleet_.emplace_back(newShip);
    ships.pop_back();

    tablero.addShips(fleet_);
    tablero.print();
    return *newShip;
}

bool player_t::canAddShip(const char& model, const char& orientation, const rectangle_t& rect) {
    if (isfleetFull(model)) return false;
    if (isShipOutside(rect)) return false;
    //if (isShipOverlap(rect)) return false;
    if (areIntersected(rect, orientation, model)) return false;
    return true;
}

bool player_t::isfleetFull(char shipType) {
    if (std::find(ships.begin(), ships.end(), shipType) != ships.end())
        return false;
    return true;
}

dimension_t player_t::getDimension(const char& model, const char& orientation) {
    if (orientation == 'V') {
        return {1, shipSizes[model]};
    }
    return {shipSizes[model], 1};
}
