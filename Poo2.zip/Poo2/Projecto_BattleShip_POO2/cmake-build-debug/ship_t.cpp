//
// Created by Fabrizio on 6/21/20.
//

#include "ship_t.h"


void ship_t::addCells() {
    if (orientation_ == 'H') {
        for (int i = 0; i < dimension_.w; i++) {
            cells.push_back({location_.row, location_.column + i});
        }
    }
    if (orientation_ == 'V') {
        for (int i = 0; i < dimension_.h; i++) {
            cells.push_back({location_.row + i, location_.column});
        }
    }
}
