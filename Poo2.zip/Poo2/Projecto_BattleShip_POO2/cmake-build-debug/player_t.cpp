//
// Created by Fabrizio on 6/21/20.
//

#include "player_t.h"
#include "utils.h"

player_t::player_t(): attackCount{}, next{} {
    tablero.fill('.');
    enemy.fill('?');
}

player_t::player_t(const path_type &path, const text_type &prefix): attackCount{}, next{} {
    this->path_ = path;
    this->prefix_ = prefix;
    tablero.fill('.');
    enemy.fill('?');
}

bool is_inside(const location_t& location, const rectangle_t& rectangle) {
    auto [x, y] = location;
    auto [l, d] = rectangle;
    return (x >= l.column && x < l.column + d.w && y >= l.row && y < l.row + d.h);
}

bool player_t::areIntersected(const rectangle_t& rect, const char& orientation, const char& model) {
    auto modelSize = shipSizes[model];
    if (orientation == 'H' && rect.first.column + modelSize <= 10) {
        for (int i = 0; i < modelSize; i++) {
            if (tablero.table_[rect.first.row - 1][rect.first.column + i - 1] != '.')
                return true;
        }
    }
    if (orientation == 'V' && rect.first.row + modelSize <= 10) {
        for (int i = 0; i < modelSize; i++) {
            if (tablero.table_[rect.first.row + i - 1][rect.first.column - 1] != '.')
                return true;
        }
    }

    return false;
}

bool player_t::isShipOutside(const rectangle_t& rect) {
    const rectangle_t battle_field = {{1, 1}, {10, 10}};
    auto [loc, dim] = rect;
    auto x1 = loc.column;
    auto y1 = loc.row;
    auto x2 = x1 + dim.w - 1;
    auto y2 = y1 + dim.h - 1;
    return !(
            is_inside({ x1, y1 }, battle_field) &&
            is_inside({ x1, y2 }, battle_field) &&
            is_inside({ x2, y1 }, battle_field) &&
            is_inside({ x2, y2 }, battle_field));
}

ship_t player_t::buildShip() {
    int TAM = 0;
    // Get random values
    int position_g, row;
    char model, column, orientation;
    location_t location{}; dimension_t dimension{};

    model = ships.back();
    orientation = rand_char_orientation();
    do {
        row = rand_int(1, 10);
        column = rand_char_column();
        //std::cout << row << " " << column << std::endl;
        location = {row, column - 64};
        //if (column == 'J') std::cout << location.x << std::endl;
        dimension = getDimension(model, orientation);
    }while (!canAddShip(model, orientation, std::make_pair(location, dimension)));

//    std::cout << "Ship "<< model << " added at position: " << char(location.column + 64) <<
//    " , " << location.row << " in " << orientation<< std::endl;

    auto newShip = new ship_t(model, column, row, orientation, dimension);
    fleet_.emplace_back(newShip);
    ships.pop_back();

    tablero.addShip(newShip->cells, model);
    //tablero.print();
    return *newShip;
}

bool player_t::canAddShip(const char& model, const char& orientation, const rectangle_t& rect) {
    if (isfleetFull(model)) return false;
    if (isShipOutside(rect)) return false;
    //if (isShipOverlap(rect)) return false;
    if (areIntersected(rect, orientation, model)) return false;
    return true;
}

bool player_t::isfleetFull(char shipType) {
    if (std::find(ships.begin(), ships.end(), shipType) != ships.end())
        return false;
    return true;
}

dimension_t player_t::getDimension(const char& model, const char& orientation) {
    if (orientation == 'H') {
        return {1, shipSizes[model]};
    }
    return {shipSizes[model], 1};
}

// Not working yet
location_t player_t::atack(navy_status_t status) {
    // Random position on first attack
    if (attackCount == 0 || status == navy_status_t::start) {
        attackLog.push_back(getRandomPos());
        return attackLog.back();
    }
    attackCount++;
    // If last attack failed
    if (status == navy_status_t::failed) {
        // If an attack was planned ahead of time
        if (!attackQueue.empty()) {
            auto back = attackQueue.back();
            attackQueue.pop_back();
            return back;
        }
        // If it's looking for new ships
        attackLog.pop_back();
        if (attackLog.empty()) {
            attackLog.push_back(getRandomPos());
            return attackLog.back();
        }
        attackLog.push_back(getAdjacentPos());
        return attackLog.back();
    }
    else {
        // Get last attack coordinates
        int row = attackLog.back().row, column = attackLog.back().column;
        // Try to destroy the damaged ship
        if (status == navy_status_t::damaged) {
            enemy.registerShip(row, column, 'x');
            attackLog.push_back(getAdjacentPos());
            attackQueue.clear();
            return attackLog.back();

        }
        // If destroyed, update enemy ships and generate new attack
        if (status == navy_status_t::destroyed) {
            auto n = attackLog.size();
            char ship = n == 1 ? 'T' : n == 2 ? 'S' : n == 3 ? 'B' : 'A';
            enemy.registerShip(row, column, ship);
            for (auto &a : attackLog) {
                enemy.registerShip(a.row, a.column, ship);
            }
            attackLog.clear();
            enemyShips[ship]--;
            attackLog.push_back(getRandomPos());
            return attackLog.back();
        }
    }
}

// todo: some positions are being marked as '.' when there's a ship
location_t player_t::atack2(navy_status_t status) {
    if (status == navy_status_t::start) {
        attackLog.push_back(getRandomPos());
        return attackLog.back();
    } else {
        auto row = attackLog.back().row;
        auto col = attackLog.back().column;
        if (status == navy_status_t::destroyed) {
            enemy.registerShip(row, col, 'x');
            attackQueue.clear();
            attackLog.push_back(getRandomPos());
            return attackLog.back();
        }
        if (status == navy_status_t::damaged) {
            enemy.registerShip(row, col, 'x');
            if (attackQueue.empty()) {
                getRadialPos(row, col, 3);
            }
            auto back = attackQueue.back();
            attackQueue.pop_back();
            attackLog.push_back(back);
            return back;
            return attackLog.back();
        }
        else {
            enemy.registerShip(row, col, '.');
            //attackLog.pop_back();
            if (!attackQueue.empty()) {
                auto back = attackQueue.back();
                attackQueue.pop_back();
                attackLog.push_back(back);
                return back;
            }
            attackLog.push_back(getRandomPos());
            return attackLog.back();
        }
    }
}

void player_t::buildShips() {
    while (!ships.empty()) buildShip();
}

navy_status_t player_t::defend(location_t pos) {
    auto model = tablero.getShipAt(pos.row, pos. column);
    //auto modelSize = shipSizes[model];
    if (model != '.') {
        // Check whether a ship has been destroyed
        /*int sum = 0;
        for (auto &ship : fleet_) {
            if (ship->ship_type_ == model) {
                if (ship->orientation_ == 'H' && pos.column + modelSize - 1 < 10) {
                    for (int i = 0; i < ship->dimension_.w; i++) {
                        if (tablero.table_[pos.row - 1][pos.column + i - 1] == 'x') sum++;
                    }
                }
                if (ship->orientation_ == 'V' && pos.row + modelSize - 1 < 10) {
                    for (int i = 0; i < ship->dimension_.h; i++) {
                        if (tablero.table_[pos.row + i - 1][pos.column - 1] == 'x') sum++;
                    }
                }
                if (sum == modelSize) return navy_status_t::destroyed;
            }
        }*/
        for (auto &ship : fleet_) {
            for (auto cell = begin(ship->cells); cell != end(ship->cells); cell++) {
                if (cell->row == pos.row && cell->column == pos.column) {
                    ship->cells.erase(cell);
                    if (ship->cells.empty()) {

                        return navy_status_t::destroyed;
                    }
                    return navy_status_t::damaged;
                }
            }
        }
        //return navy_status_t::damaged;
    }
    return navy_status_t::failed;
}

location_t player_t::getRandomPos() {
    int row;
    char column;
    do {
        row = rand_int(1, 10);
        column = rand_char_column();
    }while (enemy.getShipAt(row, column - 64) != '?');
    return {row, column - 64};
}

// Not working yet
location_t player_t::getAdjacentPos() {
    // todo: Attack the adjacent positions
    int column = attackLog.back().column;
    int row = attackLog.back().row;
    int x0 = (attackLog.end() - 2)->column; int y0 = (attackLog.end() - 2)->row;
    if (attackLog.size() == 1) {
        attackQueue.push_back({row + 1, column});
        attackQueue.push_back({row - 1, column});
        attackQueue.push_back({row, column + 1});
        attackQueue.push_back({row, column - 1});
    }
    if (attackLog.size() >= 2) {
        if (row - x0 > 0) {
            attackQueue.push_back({row + 1, column});
            attackQueue.push_back({row - 2, column});
        };
        if (row - x0 < 0) {
            attackQueue.push_back({row + 2, column});
            attackQueue.push_back({row - 1, column});
        }
        if (column - y0 > 0) {
            attackQueue.push_back({row, column + 1});
            attackQueue.push_back({row, column - 2});
        }
        if (column - y0 < 0) {
            attackQueue.push_back({row, column + 2});
            attackQueue.push_back({row, column - 1});
        }
    }
    return getRandomPos();
}

void player_t::getRadialPos(int row, int col, int radio) {
    // Set limits
    int minRow = row - radio >= 1 ? row - radio : 1;
    int maxRow = row + radio <= 10 ? row + radio : 10;
    int minCol = col - radio >= 1 ? col - radio : 1;
    int maxCol = col + radio <= 10 ? col + radio : 10;
    /*rectangle_t searchField = {{minRow, minCol}, {maxRow, maxCol}};
    while (tablero.getUnknown(searchField) != 0) {
        int row0;
        char col0;
        do {
            row0 = rand_int(minRow, maxRow);
            col0 = rand_char_column(minCol, maxCol);
        }while (enemy.getShipAt(row0, col0 - 64) != '?' ||
        (abs(row - row0) != 0 && abs(col - col0) != 0) ||
                (std::find_if(attackQueue.begin(), attackQueue.end(), [row0, col0](auto l) {
                    return l.row == row0 && l.column == col0;
                }) != attackQueue.end()));
        attackQueue.push_back({row0, col0});
    }*/
    for (int i = minRow; i < maxRow; i++) {
        if (enemy.getShipAt(i, col) == '?')
            attackQueue.push_back({i, col});
    }
    for (int i = minCol; i < maxCol; i++) {
        if (enemy.getShipAt(row, i) == '?')
            attackQueue.push_back({row, i});
    }
}
