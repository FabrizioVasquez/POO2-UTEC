//
// Created by Fabrizio on 6/21/20.
//

#ifndef BATTLESHIP1_PLAYER_T_H
#define BATTLESHIP1_PLAYER_T_H
#include "common_types.h"
#include "ship_t.h"
#include "tablero_t.h"

using hit_result_t = std::pair<std::unique_ptr<ship_t>&&, bool>;

class player_t {
    static bool isShipOutside(const rectangle_t& rect);
    bool isShipOverlap(const rectangle_t& rect);
    std::vector<ship_t*> fleet_;
//    tablero_t tablero;
//    tablero_t enemy;
    std::vector<char> ships = {'B','B','S','S','S','T','T','T','T', 'A'};
    std::map<char, int> enemyShips = {
            {'A', 1},
            {'B', 2},
            {'S', 3},
            {'T', 4}
    };
    std::map<char, int> shipSizes = {
            {'A', 4},
            {'B', 3},
            {'S', 2},
            {'T', 1}
    };
    int attackCount;
    std::vector<location_t> attackLog;
    std::vector<location_t> attackQueue;
public:
    tablero_t tablero;
    tablero_t enemy;
    // Attributes
    path_type path_;
    text_type token_;
    text_type prefix_;
    uuint_type next;
    // Constructors
    player_t();
    player_t(const path_type& ,const text_type&);
    // Methods
    bool isfleetFull(char);
    bool canAddShip(const char&, const char&, const rectangle_t&);
    ship_t buildShip();
    dimension_t getDimension(const char&, const char&);
    bool areIntersected(const rectangle_t&, const char&, const char&);
    location_t atack(navy_status_t);
    location_t atack2(navy_status_t);
    // For simulation
    navy_status_t defend(location_t);
    void buildShips();
    location_t getRandomPos();
    location_t getAdjacentPos();
    void getRadialPos(int, int, int);
};


#endif //BATTLESHIP1_PLAYER_T_H
