    //
// Created by Fabrizio on 6/21/20.
//

#ifndef BATTLESHIP1_SHIP_T_H
#define BATTLESHIP1_SHIP_T_H
#include "common_types.h"

class ship_t{
public:
    char ship_type_;
    char orientation_;
    location_t location_;
    dimension_t dimension_;
    std::vector<location_t> cells;
    int row_;
    char column_;
    ship_t(const char &ship_type, const char &column, const int &row, const char &orientation, dimension_t dimension):
    location_{row, column - 64}, dimension_(dimension) {
        ship_type_ = ship_type;
        orientation_ = orientation;
        row_ = row;
        column_ = column;
        addCells();
    }
    void addCells();
};

#endif //BATTLESHIP1_SHIP_T_H
