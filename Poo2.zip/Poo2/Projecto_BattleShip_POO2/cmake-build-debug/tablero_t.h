//
// Created by Fabrizio on 6/22/20.
//

#ifndef BATTLESHIP1_TABLERO_T_H
#define BATTLESHIP1_TABLERO_T_H
#include "casilla_t.h"
#include "common_types.h"
#include "ship_t.h"

using table_t = std::vector<std::vector<char>>;

class tablero_t {
public:
    table_t table_;
    tablero_t(): table_(10, std::vector<char>(10)) {}
    void addShips(std::vector<ship_t*> &fleet);
    void addShip(std::vector<location_t>, char);
    void registerShip(int, int, char);
    void print();
    void fill(char);
    table_t getTable(){
        return table_;
    }
    char getShipAt(int, int);
    int getUnknown(rectangle_t);
};


#endif //BATTLESHIP1_TABLERO_T_H
