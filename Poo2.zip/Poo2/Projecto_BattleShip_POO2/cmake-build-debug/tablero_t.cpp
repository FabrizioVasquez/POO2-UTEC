//
// Created by Fabrizio on 6/22/20.
//

#include "tablero_t.h"
#include "rlutil.h"

void tablero_t::fill(char c) {
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 10 ; ++j) {
            table_[i][j] = c;
        }
    }
}

void tablero_t::addShips(std::vector<ship_t*> &fleet) {
    for (auto &ship : fleet) {
        //table_[ship->location_.y][ship->location_.x] = ship->ship_type_;
        if (ship->orientation_ == 'H') {
            for (int i = 0; i < ship->dimension_.w; i++) {
                table_[ship->location_.row - 1][ship->location_.column + i - 1] = ship->ship_type_;
            }
        }
        if (ship->orientation_ == 'V') {
            for (int i = 0; i < ship->dimension_.h; i++) {
                table_[ship->location_.row + i - 1][ship->location_.column - 1] = ship->ship_type_;
            }
        }
    }
}

void tablero_t::addShip(std::vector<location_t> cells, char model) {
    for (auto &cell : cells) {
        table_[cell.row-1][cell.column-1] = model;
    }
}


void tablero_t::print() 
{
    rlutil::setColor(7);
    std::cout << "   A B C D E F G H I J" << std::endl;
    for (int i = 0; i < 10; ++i) {
        rlutil::setColor(7);
        std::cout << i+1 << " ";
        if  (i < 9) {
            std::cout << " ";
        }
        for (int j = 0; j < 10 ; ++j) {
            rlutil::setColor(15);
            if (table_[i][j] == 'A') {
                rlutil::setColor(10);
            }
            else if (table_[i][j] == 'B') {
                rlutil::setColor(11);
            }
            else if (table_[i][j] == 'S') {
                rlutil::setColor(14);
            }
            else if (table_[i][j] == 'T') {
                rlutil::setColor(13);
            }
            else if (table_[i][j] == 'x') {
                rlutil::setColor(4);
            }
            std::cout << table_[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void tablero_t::registerShip(int row, int column, char ship) {
    table_[row - 1][column - 1] = ship;
}

char tablero_t::getShipAt(int row, int column) {
    return table_[row-1][column-1];
}

int tablero_t::getUnknown(rectangle_t rect) {
    int sum = 0;
    for (int i = rect.first.row; i < rect.second.h; ++i) {
        for (int j = rect.first.column; j < rect.second.w; j++) {
            if (table_[i-1][j-1] == '?') sum++;
        }
    }
    return sum;
}
