//
// Created by Fabrizio on 6/21/20.
//

#ifndef BATTLESHIP1_COMMON_TYPES_H
#define BATTLESHIP1_COMMON_TYPES_H
#include <map>
#include <vector>
#include <queue>
#include <string>
#include <string_view>
#include <memory>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <filesystem>
#include <numeric>
#include <random>
#include <sstream>
#include <future>
#include <optional>
#include <regex>        // regular expression
#include <utility>
#include<filesystem>
#include <type_traits>
#include <queue>
#include <deque>


namespace filesystem = std::filesystem;

using text_type = std::string;
using character_type = char;
using uuint_type = size_t;
using path_type = filesystem::path;
class statement_t ;
using statement_item_type = std::pair<uuint_type ,statement_t>;
using statement_list_type = std::queue<statement_item_type>;
using position_type = std::pair<char, uuint_type>;

enum class orientation_t { horizontal = 'H', vertical = 'V'};
enum class status_t { model_full, fleet_full, busy, outside, ok, winner, game_over };
enum class model_t { aircraft_carrier = 'A', battle_cruiser = 'B', submarine = 'S', torped_boat = 'T' };
enum class navy_status_t { healthy, damaged, destroyed };
enum class action_t { start, build, attack };

struct statement_t{
public:
    text_type token_;
    text_type action_;
    text_type message;
};

struct location_t {
    int x;
    int y;
    bool operator < (const location_t& other) const {
        return (x < other.x) || (x == other.x && y < other.y);
    }
};

struct dimension_t {
    int w;
    int h;
};

using model_size_t = std::pair<size_t, dimension_t>;
using rectangle_t = std::pair<location_t, dimension_t>;

#endif //BATTLESHIP1_COMMON_TYPES_H
