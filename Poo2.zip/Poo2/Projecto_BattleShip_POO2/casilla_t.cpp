//
// Created by Fabrizio on 6/22/20.
//

#include "casilla_t.h"


