# proyecto-battleship-poo3
proyecto-battleship-poo3 created by GitHub Classroom

El presente proyecto es sobre un battleship multijugador en un servidor online. En esta primera entrega, nos centramos en el posicionamiento de naves automático de forma aleatoria por parte de la pc, para poder testearlo con mayor facilidad e identificar los errores. Asimismo, contamos con un una jerarquía de clases organizada, entre ellas destacan la clase tablero, controller, player, entre otras. Finalmente, hemos empleado diversos containers, así como también conceptos aprendidos en clase como por ejemplo la reducción de la complejidad del big O que optimiza el código para que sea lo más escalable posible.

Integrantes:

Sebastián Alonso Knell Noriega

Fabrizio Jesús Vásquez Auqui

José Adrián Porres Brugué

Diego Sebastián Ortiz Sánchez

Presentations: https://docs.google.com/presentation/d/1ODOgwPMNqAo4qL3j-NELLSDkX_ea_kyh3C-l3LC1o8I/edit?usp=sharing
