#include "controller_t.h"

using namespace std;

int main() {
    controller_t controller("firstPlayer", "secondPlayer", 'J', 10);
    controller.execute();
    return 0;
}
