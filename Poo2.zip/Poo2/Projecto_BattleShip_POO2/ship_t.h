//
// Created by Fabrizio on 6/21/20.
//

#ifndef BATTLESHIP1_SHIP_T_H
#define BATTLESHIP1_SHIP_T_H
#include "common_types.h"

class ship_t{
public:
    char ship_type_;
    char orientation_;
    location_t location_;
    dimension_t dimension_;
    int row_;
    char column_;
    ship_t(const char &ship_type, const char &column, const int &row, const char &orientation, dimension_t dimension):
    location_{column - 64, row}, dimension_(dimension) {
        ship_type_ = ship_type;
        orientation_ = orientation;
        row_ = row;
        column_ = column;
    }
};

#endif //BATTLESHIP1_SHIP_T_H
