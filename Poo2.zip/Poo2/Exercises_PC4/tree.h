//
// Created by Fabrizio on 7/17/20.
//

#ifndef EXERCISES_PC4_TREE_H
#define EXERCISES_PC4_TREE_H
#include<iostream>
#include<utility>
#include <algorithm>
#include <memory>
#include <filesystem>
using namespace std;

template < typename T>
class node_ptr;

template < typename T >
using node_t = shared_ptr<node_ptr<T>>;

template < typename T, typename ...U>
auto make_node_t(U... u){return make_shared<node_ptr<T>>(u...);}


template < typename T>
struct node_ptr{
    T data;
    node_ptr<T> parent = nullptr;
    node_ptr<T> left = nullptr;
    node_ptr<T> right = nullptr;
    node_ptr()=default;
    node_ptr(T data, node_ptr<T>parent_ = nullptr):data{data},parent{parent_},left{nullptr},right{nullptr}{}
};

template < typename T>
class binary_tree_t{
    node_ptr<T> root = nullptr;
    static void count_in_order(node_t<T> root, size_t& result){
        if(!root) return;
        count_in_order(root->left, result);
        result++;
        count_in_order(root->right,result);
    }

    static size_t size(node_ptr<T> root){
        if(!root) return 0;
        size_t count = 0;
        count_in_order(root,count);
        return count;
    }

    static size_t height(node_ptr<T> root){
        if(!root) return 0;
        return max(height(root.right),height(root.left))+1;
    }
    static void in_order_rec(node_ptr<T> root, vector<T>& result){
        if (!root) return;
        in_order_rec(root->left, result);
        result.push_back(root->data);
        in_order_rec(root->right, result);
    }

    static void count_in_leaf_recursion(node_ptr<T>root, size_t& result){
        if(!root) return;
        if(root.left == nullptr && root.right == nullptr) ++result;
        count_in_leaf_recursion(root.right,result);
        count_in_leaf_recursion(root.right,result);
    }

    static void count_node_full(node_ptr<T>root, size_t &result){
        if(!root) return;
        if(root->left != nullptr && root->right != nullptr) result++;
        count_in_leaf(root->left,result);
        count_in_leaf(root->right,result);
    }
public:
    binary_tree_t()=default;
    binary_tree_t(T data):root{make_node_t<T>(data)}{}
    node_t<T>& get_root(){return root;}
    size_t size(){return size(root);}
    size_t height(){return height(root);}
    void insert(T data) {
        if(!root){
            root = make_node_t<T>(data);
            return;
        }
        auto current = root;
        while (current) {
            if (data < current->data) {
                if (!current->left) {
                    current->left = make_node_t<T>(data, current);
                    break;
                }
                current = current->left;
            } else {
                if (!current->right) {
                    current->right =  make_node_t<T>(data, current);
                    break;
                }
                current = current->right;
            }
        }
    }


    std::vector<T> in_order(){
        std::vector<T>result;
        post_order_rec(root,result);
        return result;
    }

    void post_order_rec(node_t<T> start, std::vector<T>& result){
        if(!start) return;
        post_order_rec(start->left,result);
        post_order_rec(start->right,result);
        result.push_back(start->data);
    }

    std::vector<T> post_order(){
        std::vector<T>result;
        post_order_rec(root,result);
        return result;
    }

    node_t<T> find(T data){
        auto current = root;
        while(current){
            if(data > current->data){
                current = current->right;
            }else if(data < current->data){
                current = current->data;
            }else{
                return current;
            }
            return current;
        }
    }

    size_t maximum() {
        node_t<T> aux = root;
        while(aux->left != nullptr || aux->right != nullptr){
            if(aux->right != nullptr){
                aux = aux->right;
            }
            else if(aux->left != nullptr){
                aux = aux->left;
            }
        }
        return aux->data;
    }

    size_t minimum() {
        node_t<T> aux = root;
        while(aux->left != nullptr || aux->right != nullptr){
            if(aux->left != nullptr){
                aux = aux->left;
            }
            else if(aux->right != nullptr){
                aux = aux->right;
            }
        }
        return aux->data;
    }


    size_t count_leafs(){
        node_t<T>aux = root;
        if (!root) return 0;
        size_t count = 0;
        count_in_leaf(root, count);
        return count;
    }

    size_t count_fullnodes(){
        node_t<T>aux = root;
        if(!root) return 0;
        size_t memories = 0;
        count_nodes_full(root,count);
        return memories;
    }
    size_t count_nodehalf(){
        size_t memories = 0;
        queue<node_t<T>>queue;
        queue.push(root);
        while(!queue.empty()){
            auto aux = queue.front();
            queue.pop();
            if(aux->left && !aux->right) ++memories;
            if(aux->right && !aux->left) ++memories;
            if(aux->left) queue.push(aux->left);
            if(aux->right) queue.push(aux->right);
        }
        return memories;
    }

    size_t findDiameter(node_t<T> root) {
        if(!root) return 0;
        auto hl = this->height(root->left);
        auto hr = this->height(root->right);
        auto ld = this->findDiameter(root->left);
        auto rd = this->findDiameter(root->right);
        return std::max(hl + hr + 1, std::max(ld,rd));
    }

    bool identicalT(node_t<T> root1, node_t<T> root2){
        if(!root1 && !root2) return true;
        if(root1 && root2){
            return (root1->data == root2->data && identicalT(root1->left, root2->right) && identicalT(root1->righfmaxt));
        }
        return false;
    }
};




#endif //EXERCISES_PC4_TREE_H
