//
// Created by Fabrizio on 7/16/20.
//

#ifndef EXERCISES_PC4_RESTAURANT_H
#define EXERCISES_PC4_RESTAURANT_H

#include <iostream>
#include <memory>
#include <algorithm>
#include <utility>
#include <vector>
#include <string>

using namespace std;

class observer_t{
public:
    virtual void update() = 0;
};

class observable_t{
private:
    vector<observer_t*> observers{};
public:
    void agregar(observer_t* observer);
    void remove(observer_t* observer);
    void notify();
};

class client_t : public observer_t{
    pair<int,int> position;
public:
    client_t(pair<int,int>pos):position{std::move(pos)}{}
    void update() override;

};

class table_t : public observable_t{
    vector<client_t*> lots;
public:
    table_t(int capacity):lots(capacity){}
    pair<int,bool> check_in(client_t* client);
    bool check_out(client_t* client);
};


#endif //EXERCISES_PC4_RESTAURANT_H
