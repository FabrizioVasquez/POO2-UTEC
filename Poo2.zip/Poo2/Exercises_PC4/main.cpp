#include <iostream>
#include "restaurant.h"

int main() {

    return 0;
}
