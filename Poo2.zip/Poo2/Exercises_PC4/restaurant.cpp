//
// Created by Fabrizio on 7/16/20.
//

#include "restaurant.h"

#include <utility>

void observable_t::agregar(observer_t* observer) {
    observers.push_back(observer);
}

void observable_t::remove(observer_t* observer) {
    auto it = find(begin(observers),end(observers),observer);
    if(it != end(observers))
        observers.erase(it);
}

void observable_t::notify() {
    for(auto &o: observers)o->update();
}

void client_t::update() {
    cout<<"Ya hay un espacio disponible en la posicion: "<<this->position.first<<" , "<<this->position.second <<endl;
}

pair< int, bool> table_t::check_in(client_t*  client) {
    auto it = find_if(begin(lots), end(lots), []( client_t* &client){return client == nullptr;});
    if (it != end(lots))
    {
        *it = client;
        auto index = distance(it, begin(lots));
        it = find_if(begin(lots), end(lots), []( client_t*  &client){return client == nullptr;});
        if (it != end(lots))
            notify();
        return {index, true};
    }
    return {-1, false};
}


bool table_t::check_out(client_t*  client) {
    auto it = find(begin(lots), end(lots), client);
    if (it != end(lots)) {
        *it = nullptr;
        notify();
        return true;
    }
    return false;
}
