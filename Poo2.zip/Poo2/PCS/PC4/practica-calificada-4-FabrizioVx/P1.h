//
// PREGUNTA #1
//

#ifndef P1_H
#define P1_H

void P1();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//










#endif //P1_H
