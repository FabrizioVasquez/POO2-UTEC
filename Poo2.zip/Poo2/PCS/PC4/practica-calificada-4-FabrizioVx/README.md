# Practica Calificada # 4
**curso**: CS1103 - Programación Orientada a Objetos 2  
**profesor**: Rubén Rivas  
**semestre**: 2020-1
