//
// PREGUNTA #2
//

#ifndef P2_H
#define P2_H

void P2();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//






#endif //P2_H
