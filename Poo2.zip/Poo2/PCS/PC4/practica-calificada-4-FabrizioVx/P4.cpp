//
// Created by rudri on 6/19/2020.
//

#include "P4.h"

#include <vector>
#include <list>
#include<string>
#include <functional>
#include <queue>
#include <tuple>
#include <unordered_map>
#include <algorithm>
#include <numeric>
#include <stack>

using namespace std;

class graph_t{
public:
    int n_v;
    list<int>*adjacent;
    graph_t(int n_v_):n_v{n_v_}{
        adjacent = new list<int>[n_v+1];
    }
    void add_edge(int begin,int end){
        adjacent[begin].push_back(end);
        adjacent[end].push_back(begin);
    }
    vector<int>bfs(int li ,int start,int visitados[]){
        queue<int> q;
        q.push(start);
        visitados[start] = li;
        vector<int> next_nodes;

        while(!q.empty())
        {
            int aux = q.front();
            q.pop();

            next_nodes.push_back(aux);
            for (auto it = adjacent[aux].begin();
                 it != adjacent[aux].end(); it++)
            {
                if (!visitados[*it])
                {
                    visitados[*it] = li;
                    q.push(*it);
                }
            }
        }
        return next_nodes;
    }
};



void P4() {

}
