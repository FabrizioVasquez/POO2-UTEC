//
// PREGUNTA #4
//

#ifndef P4_H
#define P4_H

void P4();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//






#endif //P4_H
