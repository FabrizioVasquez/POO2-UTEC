//
// Created by rudri on 6/19/2020.
//

#include "P2.h"

#include <vector>
#include <string>
#include <memory>
#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;

//using T = int;

template < typename T>
class node_impl_t;

//Nueva forma de Alias template
template < typename T>
using node_t = shared_ptr<node_impl_t<T>>;

//Usando template de lambdas (SE NECESITAN DOS PARAMETROS)
//template < typename T, typename ... U>
//auto make_node_t = [](U... u){return make_shared<node_impl_t<T>>(u...);};

//Usando template con funciones para make_shared
template<typename T, typename ...U>
auto make_node_t(U... u) {return make_shared<node_impl_t<T>>(u...);};

template < typename T>
struct node_impl_t{
    T data;
    node_t<T> parent = nullptr;
    node_t<T> left = nullptr;
    node_t<T> right = nullptr;
    node_impl_t()=default;
    node_impl_t(T data,  node_t<T> parent = nullptr):data{data},parent{parent},
                                                     left{nullptr},right{nullptr}{}
};


template < typename T>
class binary_tree_t {
    node_t<T> root = nullptr;
public:
    binary_tree_t() = default;

    binary_tree_t(T data) : root{make_node_t<T>(data)} {}
    node_t<T> &get_root() { return root; }
    size_t size() { return size(root); }
    size_t height() { return height(root); }

    void insert(T data) {
        if (!root) {
            root = make_node_t<T>(data);
            return;
        }
        auto current = root;
        while (current) {
            if (data < current->data) {
                if (!current->left) {
                    current->left = make_node_t<T>(data, current);
                    break;
                }
                current = current->left;
            } else {
                if (!current->right) {
                    current->right = make_node_t<T>(data, current);
                    break;
                }
                current = current->right;
            }
        }
    }
    bool is_skew(node_t<T> root){
        if (root == nullptr || (root->right == nullptr && root->left == nullptr))
            return true;
        if (root->right != nullptr && root->left != nullptr) {
            return false;
        }
        if (root->left) {
            return is_skew(root->left);
        }
        return is_skew(root->right);
    }
};


void P2() {

    cout<<"PREGUNTA 2"<<endl;
    binary_tree_t<int> t1(1);
    t1.insert(3);
    t1.insert(2);
    t1.insert(5);

    binary_tree_t<int> t2(1);
    t2.insert(2);
    t2.insert(3);
    t2.insert(4);

    cout<<std::boolalpha<<t1.is_skew(t1.get_root())<<endl;
    cout<<std::boolalpha<<t2.is_skew(t2.get_root())<<endl;
}
