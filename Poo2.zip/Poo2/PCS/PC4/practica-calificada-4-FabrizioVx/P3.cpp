//
// Created by rudri on 6/19/2020.
//

#include "P3.h"
#include <iostream>
#include <vector>
#include <list>
#include<string>
#include <functional>
#include <queue>
#include <tuple>
#include <unordered_map>
#include <algorithm>
#include <numeric>
#include <stack>

using namespace std;


using vertex_t = size_t;
using weight_t = size_t;
using identify_t = string;
using adjacent_t = tuple <vertex_t , weight_t >;                // vertice y peso
using edge_t = tuple <vertex_t, vertex_t, weight_t >;           //el origen, el destino y el peso
//using edge_queue_t = priority_queue<edge_t , vector<edge_t >, function<bool(edge_t, edge_t)>>;
using edge_queue_t = priority_queue<edge_t , vector<edge_t >,greater<>>;
using row_t = vector<weight_t>;
using matrix_t = vector<row_t>;
// para < lo ordena de menor a mayor y > lo ordena de mayor a menor.
auto edge_compare = [](edge_t e1, edge_t e2){return get<2>(e1) < get<2>(e2);};      //lamamos al tercer elemento con <2>
const int INF = 0x3f3f3f3f;


//UNDIRECTED GRAPH
template<typename T>
class undirected_graph_t {
private:
    vector<list<adjacent_t >> adjacent_;
    unordered_map<T, vertex_t> vertices_;
    edge_queue_t edge_queue_;
    vector<edge_t> edges;

public:
    undirected_graph_t() {}

    size_t vertices() { return adjacent_.size(); }

    size_t edge_queue_Size() { return edge_queue_.size(); }

    //agregar vertices
    void add_vertex(T identify) {
        if (vertices_.find(identify) == end(vertices_)) {
            vertices_[identify] = vertices_.size();
            adjacent_.resize(vertices_.size());
        }
    }

    void add_edge(T id1, T id2, weight_t weight) {
        edge_queue_.push({vertices_[id1], vertices_[id2], weight});
        adjacent_[vertices_[id1]].push_back({vertices_[id2], weight});
        adjacent_[vertices_[id2]].push_back({vertices_[id1], weight});
        edges.emplace_back(vertices_[id1], vertices_[id2], weight);
    }

    //Getter
    weight_t get_edge(T id1, T id2) {
        auto v1 = vertices_[id1];
        auto v2 = vertices_[id2];
        auto it = find_if(begin(adjacent_[v1]), end(adjacent_[v1]), [&v2](adjacent_t a) { return get<0>(a) == v2; });
        if (it != end(adjacent_[v1])) // quiere decir que lo ha encontrado
            return get<1>(*it);
            //else
            //    return 0; otra forma como la de abajo ya aquí esta hardcodeado
        else
            return weight_t{};
    }

    T get_identify(vertex_t v1) {
        string aux{};
        for (auto const &i: vertices_) {
            if (v1 == i.second) {
                aux = i.first;
            }
        }
        return aux;
    }

    void dfs(int aux, bool visitados []){
        visitados[aux] = true;
        for(auto x: adjacent_[aux]){
            if(!visitados[get<0>(x)]) {
                dfs(get<0>(x), visitados);
            }
        }
    }
    bool is_conected(){
        bool *visitados = new bool[vertices_.size()];
        for(int i = 0; i < vertices_.size(); ++i) {
            visitados[i] = false;
        }

        auto curr = vertices_.size();
        dfs(curr,visitados);
        //for (int v=0; v<vertices_.size(); v++){
        while(curr){
            dfs(curr,visitados);
            if (!visitados[curr]){
                return true;
            }
            curr--;
        }
        delete[] visitados;
    }
};



void P3() {
    cout<<"PREGUNTA 3"<<endl;
    undirected_graph_t<int> g;
    g.add_vertex(1);
    g.add_vertex(2);
    g.add_vertex(3);
    g.add_edge(1,0,0);
    g.add_edge(4,3,0);
    g.add_edge(3,4,0);
    cout<<std::boolalpha<<g.is_conected()<<endl;

}
