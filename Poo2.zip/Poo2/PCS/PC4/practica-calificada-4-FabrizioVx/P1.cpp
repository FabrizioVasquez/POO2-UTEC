//
// Created by rudri on 6/19/2020.
//

#include "P1.h"

#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>

int nivel_embalse_mil_millones = 0;

class observer_t{
public:
    virtual void alert() = 0;
};

class observable_t{
private:
    std::vector<observer_t*> observers{};
public:
    void suscribir(observer_t* observer){
        observers.push_back(observer);
        ++nivel_embalse_mil_millones;
    }
    void dar_baja(observer_t* observer){
        auto it = find(begin(observers),end(observers),observer);
        if(it != end(observers))
            observers.erase(it);
        --nivel_embalse_mil_millones;
    }

};



class operador_t : public observer_t{
    std::string name_;
public:
    operador_t(std::string name):name_{std::move(name)}{}
    std::string getName(){return this->name_;}
    void alert() override {
        if(nivel_embalse_mil_millones <= 3){
            std::cout<<"OPERADOR "<<this->getName()<<" LA REPRESA SE ENCUENTRA EN EL NIVEL MINIMO"<<std::endl;
        }else if(nivel_embalse_mil_millones > 3){
            std::cout<<"OPERADOR "<<this->getName()<<" LA REPRESA SE ENCUENTRA EN EL NIVEL MAXIMO"<<std::endl;
        }else{
            std::cout<<"OPERADOR "<<this->getName()<<" LA PRESA ESTA VACIA"<<std::endl;
        }
    }
};

class represa_t : public observable_t{
    std::vector<operador_t*> operators_represa;
    bool is_empty(){
        return nivel_embalse_mil_millones == 0;
    }
    bool fully_draw_down() const{
        return nivel_embalse_mil_millones <= 3;
    }
    bool top_water_level() const{
        return nivel_embalse_mil_millones > 3;
    }
public:
    represa_t() = default;
    void notify(){
        if(fully_draw_down()){
            std::cout<<"La represa no alcanza los niveles maximos (NIVEL MINIMO)\n";
            for(const auto &o:operators_represa)o->alert();
        }
        if(top_water_level()){
            std::cout<<"La represa sobrepasa los niveles mínimos (NIVEL MAXIMO)\n";
            for(const auto &o:operators_represa)o->alert();
        }
        if(is_empty()){
            std::cout<<"La represa esta vacía\n";
            for(const auto &o:operators_represa)o->alert();
        }
    }
};



void P1() {
    std::cout<<"PREGUNTA 1"<<std::endl;
    represa_t represa;
    operador_t op1("Ruben");
    operador_t op2("Fabrizio");
    operador_t op3("Anderson");
    operador_t op4("Anderson");
    represa.suscribir(&op1);
    represa.suscribir(&op2);
    represa.suscribir(&op3);
    represa.suscribir(&op4);
    represa.dar_baja(&op4);
    represa.notify();
    //op1.alert();//verificando si se ocasiona la alerta
    //Mientras se agrege mas personal la cantidad(nivel_embalse_mil_millones) de la represa aumenta,
    //ocasionando que pueda llegar a niveles minimos o maximos;
}
