//
// PREGUNTA #3
//

#ifndef P3_H
#define P3_H

void P3();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//






#endif //P3_H
