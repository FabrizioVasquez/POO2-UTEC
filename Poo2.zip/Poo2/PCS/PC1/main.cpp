#include<bits/stdc++.h>
#include <utility>


//EXCERISE 1
using namespace std;
template <typename number_t>
class sort_t{
protected:
    string name;
    long long duration;
public:
    sort_t(string name_):name(std::move(name_)),duration(0){}
    virtual sort_t operator()(vector<number_t>&data){}
};

template <typename number_t>
class merge_sort_t: public sort_t<number_t>{
public:
    merge_sort_t operator()(vector<number_t> &data) override {
        typename vector<number_t>::iterator it1, it2;
        for(it1 = data.begin() ; it1 != data.end(); it1++ ){
            for(it2 = data.begin(); it2 != it1 ; it2++){
                if(*it1 < *it2){
                    auto aux_it = *it1;
                    *it1 = *it2;
                    *it2 = aux_it;
                }
            }
        }
    }
};

template <typename number_t>
class bubble_sort_t: public sort_t<number_t>{
public:
    bubble_sort_t operator()(vector<number_t> &data) override {
        typename vector<number_t>::iterator it1, it2;
        for(it1 = data.begin() ; it1 != data.end(); it1++ ){
            for(it2 = data.begin(); it2 != it1 ; it2++){
                if(*it1 < *it2){
                    auto aux_it = *it1;
                    *it1 = *it2;
                    *it2 = aux_it;
                }
            }
        }
    }
};

template <typename Number>
class queue_t : public sort_t<Number>{
private:
    sort_t<Number>* data;
    size_t size;
    size_t CAPACITY;
    size_t index_t = 0;
public:
    queue_t(){
        size = 0;
        index_t = 0;
        CAPACITY = 3;       // se agrego esta variable
        data = new Number[3];
    }
    void push(Number& value){
        if(size == CAPACITY){
            size_t nCapacity = 2 * CAPACITY;
            auto * nData = new Number[nCapacity];
            for(size_t i = 0 ; i < size ; ++i){
                nData[i] = data[i];
            }
            delete [] data;
            data = nData;
            CAPACITY = nCapacity;
        }else{
            data[size++] = value;
        }
    }
    Number pop(){
        Number* nuevaCola= new Number[size];
        Number auxtmp= data[0];
        Number aux=0;
        for(int i=1;i< index_t+1 ;i++){
            nuevaCola[aux]=data[i];
            aux++;
        }
        delete[] data;
        data = nuevaCola;
        index_t--;
        return auxtmp;
    }
    Number front(){
        return data[0];
    }
    Number back(){
        return data[size-1];
    }


    bool empty(){
        if(index_t == 0){
            return true;
        }else{
            return false;
        }
    }
    bool full(){
        if(index_t == 0){
            return true;
        }else{
            return false;
        }
    }
    Number size_(){
        return size;
    }

    queue_t &operator+(const queue_t &other){
        queue_t aux;
        aux.queue = this->queue + other.queue;
        return aux;
    }

};

template <typename type_value>
class tester_t{
private:
    queue_t<type_value> queue_;
    vector<int> data_;

public:
    void push_method(sort_t<type_value> sort_) {
        sort_.operator()(data);
    }
    explicit operator tester_t(){}
    tester_t &operator <<(const string& file_name){
        std::ofstream out("../"+file_name);

        if(!out.is_open()){
            cout<<"ERROR";
        }
        else{
            for (size_t i = 0; i < data_.size(); ++i) {
                out<<data_[i]<<endl;
            }
        }
        return*this;
    }
};


//EXERCISE 2

template <typename T, int CAPACITY>
class queue_t2{
private:
    T * queue;
    size_t size_q;
    size_t index_q;
public:
    queue_t2<T>(){
        size_q = CAPACITY;
        index_q = 0;
        queue = new T[size_q];
    }
    void push(const T &item){
        queue[index_q]= item;
        index_q++;
    }
    T pop(){
        T* nuevaCola= new T[size_q];
        T aux0= queue[0];
        T aux=0;
        for(int i=1;i< index_q+1 ;i++){
            nuevaCola[aux]=queue[i];
            aux++;
        }
        delete[] queue;
        queue=nuevaCola;
        index_q--;
        return aux0;
    }

    T front(){
        return queue[0];
    }
    T back(){
        return queue[size_q-1];
    }


    bool empty(){
        if(index_q == 0){
            return true;
        }else{
            return false;
        }
    }
    bool full(){
        if(index_q == 0){
            return true;
        }else{
            return false;
        }
    }
    T size(){
        return size_q;
    }

    queue_t2 &operator+(const queue_t2 &other){
        queue_t2 aux;
        aux.queue = this->queue + other.queue;
        return aux;
    }
};

//EXERCISE 3
queue<char> inverter(queue<char>&queue2){
    stack<char> stack6;
    while(!queue2.empty()){
        stack6.push(queue2.front());
        queue2.pop();
    }
    while(!stack6.empty()){
        queue2.push(stack6.top());
        stack6.pop();
    }
    return queue2;
}



void palyondrome(queue<char>& pal,queue<char>pal2){
    if(pal2 == inverter(pal) ){
        cout<<"Es paliondromo";
    }else{
        cout<<"No es paliondromo";
    }
}


//EXERCISE 4

template <typename type_value>
void exercise4(string filename){
    string values1,values2,line1,line2;
    int value1=0,value2=0,paso=0,col_value=0;
    vector<unsigned>array_position;
    vector<type_value>array_data;
    ifstream file_read;
    string size;
    string vector_position;
    string vector_data;

    file_read.open(filename);
    if(!file_read.is_open()){
        cout<<"El archivo no esta abierto"<<endl;
    }
    else{
        getline(file_read,values1);
        istringstream i__(values1);
        while(i__ >> value1){
            array_position.push_back(value1);
        }
        getline(file_read,values2);
        istringstream i_(values2);
        while(i_ >> value2){
            array_data.push_back(value2);
        }
        file_read>>paso;
        file_read>>col_value;
    }
    auto size_ = 3*paso*(array_data.size())/4 +1;
    vector<type_value>array_result(size_);

    for(size_t i = 0; i < array_position.size()+1; ++i ){
        array_result[paso*(array_position[i]-1)] = array_data[i];
    }

    for(size_t j = 0; j < array_result.size();++j){
        if(array_result[j] == 0){
            array_result[j] = col_value;
        }
    }

    cout<<endl;
    for(int i = 0 ; i <array_result.size();++i){
        cout<< array_result[i]<<" ";
    }
}


int main() {

    auto fifo = new queue_t2<int,3>();
    fifo->push(1);
    fifo->push(2);
    fifo->push(4);
    auto b = fifo->front();
    auto c = fifo->back();
    cout<<b<<"-> front"<<endl;
    cout<<c<<"-> back"<<endl;
    auto h = fifo->empty();
    cout<<h<<"--> false "<<endl;

    queue<char>nombre1;
    queue<char>nombre2;
    queue<char>nombre1_original;
    queue<char>nombre2_original;

    nombre1.push('m');
    nombre1.push('a');
    nombre1.push('d');
    nombre1.push('a');
    nombre1.push('m');
    nombre1_original.push('m');
    nombre1_original.push('a');
    nombre1_original.push('d');
    nombre1_original.push('a');
    nombre1_original.push('m');
    nombre2.push('f');
    nombre2.push('b');
    nombre2.push('a');
    nombre2_original.push('f');
    nombre2_original.push('b');
    nombre2_original.push('a');
    cout<<endl;
    palyondrome(nombre1,nombre1_original);
    cout<<endl;
    palyondrome(nombre2,nombre2_original);
    cout<<endl;

    exercise4<int>("inputA.txt");
    exercise4<int>("inputB.txt");




    return 0;
}

