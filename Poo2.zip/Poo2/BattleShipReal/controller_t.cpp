#include "controller_t.h"

controller_t::controller_t(std::string first, std::string second) : columns_{'J'}, rows_{10} {
    players_.push_back(std::make_unique<player_t>(filesystem::current_path() / first, "FirstPlayer"));
    players_.push_back(std::make_unique<player_t>(filesystem::current_path() / second, "SecondPlayer"));

    for(const auto& player : players_) {
        if(!filesystem::exists(player->path_ / "in"))
            filesystem::create_directories(player->path_ / "in");

        if(!filesystem::exists(player->path_ / "out"))
    filesystem::create_directories(player->path_ / "out");
    }
}

void controller_t::start(const statement_item_t& item) {
    /*auto& player = players_[item.first];
    std::string action = "HANDSHAKE=";
    std::string nombre = "Fabrizio"//random_name(5, 5);

    auto file_name = player->prefix_ + std::to_string(player->sequence++) + ".in";
    std::ofstream file(player->path_ / "in" / file_name);

    file << action << nombre << '\n';*/
}

void controller_t::build(const statement_item_t& item) {
    /*auto& player = players_[item.first];
    std::string tk = "TOKEN=";
    std::string action = "PLACEFLEET=";

    auto file_name = player->prefix_ + std::to_string(player->sequence++) + ".in";
    std::ofstream file(player->path_ / "in" / file_name);

    //auto ship = players_.
    //auto temp_nave = random_nave();

    file << tk << player->token << '\n';
    file << action << temp_nave.id << '-' <<  temp_nave.posicion.first << temp_nave.posicion.second << '-' << temp_nave.orientacion << '\n';*/
}

void controller_t::attack(const statement_item_t& item) {

    /*auto& player = players_[item.first];
    std::string tk = "TOKEN=";
    std::string action = "ATTACK=";

    auto file_name = player->prefix_ + std::to_string(player->sequence++) + ".in";
    std::ofstream file(player->path_ / "in" / file_name);

    auto temp_attack = random_location();

    file << tk << player->token << '\n';
    file << action << temp_attack.first << temp_attack.second << '\n';*/
}

statement_t push_statement(const path_t& file_name) {
    std::ifstream file(file_name.generic_string());
    if(!file.is_open())
        throw std::runtime_error("no open");

    std::string line;
    getline(file, line, '\n');
    std::stringstream first(line);

    std::string action;
    getline(first, action, '\n');

    statement_t result {};

    std::string key_status, key_message;
    std::string value_status, value_message;

    if(action == "HANDSHAKE") {
        getline(file, line, '\n');
        std::stringstream second(line);

        getline(second, key_status, '=');
        getline(second, value_status, '\n');

        if(value_status == "ACCEPTED") {
            getline(second, key_message, '=');
            getline(second, value_message, '\n');

            result.token = value_message;
            result.action = "build";
        }

        else if(value_status == "REJECTED")
            result.action = "start";
    }

    else if(action == "PLACEFLEET") {
        getline(file, line, '\n');
        std::stringstream second(line);

        getline(second, key_status, '=');
        getline(second, value_status, '\n');

        if(value_status == "ACCEPTED") {
            getline(second, key_message, '=');
            getline(second, value_message, '\n');

            if(value_message == "FULL")
                result.action = "attack";

            else
                result.action = "build";
        }

        else if(value_status == "REJECTED")
            result.action = "build";
    }

    else if(action == "ATTACK") {
        getline(file, line, '\n');
        std::stringstream second(line);

        getline(second, key_status, '=');
        getline(second, value_status, '\n');

        if(value_status == "ACCEPTED") {
            getline(second, key_message, '=');
            getline(second, value_message, '\n');

            if(value_message == "FAILED" || value_message == "DAMAGED" || value_message == "DESTROYED")
                result.action = "attack";

            else if(value_message == "WINNER")
                result.action = "win";

            else if(value_message == "GAMEOVER")
                result.action = "lose";

        }

        else if(value_status == "REJECTED")
            result.action = "attack";

    }

    return result;
}

void controller_t::load_tokens()
{
    auto end_ = filesystem::directory_iterator{};
    std::error_code e;
    while (true) {
        try {
            filesystem::directory_iterator first_{ players_[0]->path_ / "in" };
            filesystem::directory_iterator second_{ players_[1]->path_ / "in" };
            while (first_ != end_ || second_ != end_) {
                if (first_ != end_) {
                    statements_.push({ 0u, push_statement(*first_) });
                    filesystem::remove(*first_++, e);
                    if (e)
                        std::cerr << e.message() << "\n";
                }
                if (second_ != end_) {
                    statements_.push({ 1u, push_statement(*second_) });
                    filesystem::remove(*second_++, e);
                    if (e)
                        std::cerr << e.message() << "\n";
                }
            }
        }
        catch (const std::exception& e) {
            std::cerr << e.what();
        }
    }
}

void controller_t::save_tokens()
{
    auto end_ = filesystem::directory_iterator{};
    while (true) {
        try {
            while (!statements_.empty()) {
                auto item = statements_.front();
                statements_.pop();
                if (item.second.action == "start")
                    start(item);

                else if (item.second.action == "build")
                    build(item);

                else if (item.second.action == "attack")
                    attack(item);

                else if (item.second.action == "lose" || item.second.action=="win")
                    break;
            }
        }

        catch (const std::exception& e) {
            std::cerr << e.what();
        }
    }
}

void controller_t::execute()
{
    load_tokens();
    save_tokens();
}

