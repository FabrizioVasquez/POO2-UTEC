//
// Created by Fabrizio on 6/16/20.
//

#ifndef BATTLESHIPREAL_PLAYER_H
#define BATTLESHIPREAL_PLAYER_H


#include "common_types.h"
#include "ship_t.h"

struct player_t {
    std::vector<ship_t> flota;
    std::string token;
    path_t path_;
    std::string prefix_;
    size_t sequence;

    player_t(const path_t &path, const std::string& prefix);
};


#endif //BATTLESHIPREAL_PLAYER_H
