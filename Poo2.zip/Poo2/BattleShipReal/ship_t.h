//
// Created by Fabrizio on 6/16/20.
//

#ifndef BATTLESHIPREAL_SHIP_T_H
#define BATTLESHIPREAL_SHIP_T_H
#include "common_types.h"

class ship_t {
public:
    location_t location_;
    orientation_t orientation_;
    model_t model_;
    ship_t(location_t,orientation_t,model_t)
};


#endif //BATTLESHIPREAL_SHIP_T_H
