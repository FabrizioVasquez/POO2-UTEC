//
// Created by Fabrizio on 6/16/20.
//

#include "player.h"
player_t::player_t(const path_t& path, const std::string& prefix) :
        path_{path}, prefix_{prefix} {}