//
// Created by Fabrizio on 6/16/20.
//

#ifndef BATTLESHIPREAL_CONTROLLER_T_H
#define BATTLESHIPREAL_CONTROLLER_T_H


#include "common_types.h"
#include "player.h"
#include "ship_t.h"

struct statement_t {
    action_t action;
    text_t token;
    status_t status;
    text_t parameter;
};

using statement_item_t = std::pair<size_t, statement_t>;
using statement_list_t = std::queue<statement_item_t>;

class controller_t {
    char columns_;
    size_t rows_;
    std::vector<std::unique_ptr<player_t>> players_;

    statement_list_t statements_;

    void start(const statement_item_t& item);
    void build(const statement_item_t& item);
    void attack(const statement_item_t& item);
    friend class player_t;
public:
    controller_t(std::string first, std::string second);

    void load_tokens();
    void save_tokens();
    void execute();
};

#endif //BATTLESHIPREAL_CONTROLLER_T_H
