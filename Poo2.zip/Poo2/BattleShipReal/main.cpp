#include "controller_t.h"

int main() {
    controller_t ctrl("first","second");
    ctrl.execute();

    return 0;
}
