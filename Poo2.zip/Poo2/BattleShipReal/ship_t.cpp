//
// Created by Fabrizio on 6/16/20.
//

#include "ship_t.h"

ship_t::ship_t(location_t location, orientation_t orientation, model_t model) {
 location_ = location;
 orientation_ = orientation;
 model_ = model;
}
