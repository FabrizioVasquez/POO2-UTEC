//
// Created by Fabrizio on 6/21/20.
//

#include "player_t.h"



player_t::player_t(const path_type &path, const text_type &prefix) {
    this->path_ = path;
    this->prefix_ = prefix;
}
