# Mandelbrot Set

A simple graph representing the Mandelbrot set.

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
