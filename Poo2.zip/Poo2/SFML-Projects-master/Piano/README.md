# Piano

A simple piano.

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
- **Soham Kar** - [2bit-hack](https://github.com/2bit-hack)
