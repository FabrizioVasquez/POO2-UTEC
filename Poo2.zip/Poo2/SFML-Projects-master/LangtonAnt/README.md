# Langton's Ant

A simple simulation of Langton's Ant.

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
