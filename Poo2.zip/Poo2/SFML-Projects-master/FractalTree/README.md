# Fractal tree

A simple fractal tree visualisation.

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
