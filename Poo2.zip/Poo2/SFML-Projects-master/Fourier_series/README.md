# Fourier series

A simple fourier series visualisation

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
