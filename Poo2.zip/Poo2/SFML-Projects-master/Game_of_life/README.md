# Game of Life

A simple simulation of the Conway's game of life.

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
