# n_queen

A simple solution to the classic N-Queen problem.

## Authors

- **Anubhab Mukherjee** - [phoenix-zero](https://github.com/phoenix-zero)
- **Soham Kar** - [2bit-hack](https://github.com/2bit-hack)
