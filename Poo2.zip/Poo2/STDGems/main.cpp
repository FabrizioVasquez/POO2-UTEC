
#include <iostream>
#include <vector>

int main() {

    return 0;
}
