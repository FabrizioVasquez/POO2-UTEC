//
// Created by Fabrizio on 7/29/20.
//

#ifndef STDGEMS_COPY_FILTER_H
#define STDGEMS_COPY_FILTER_H
/*
using namespace std;

template < class Container>
auto write_to_cout(const Container& container, const char* delimiter =" ") -> void {
    std::copy(begin(container),end(container),std::ostream_iterator<typename Container::value_type>(std::cout,delimiter));
}


int main() {

    vector<int>vector1 = {1,2,3,4,5,6,7,8,10};
    vector<std::string>vector_aux = {"1","2","3","4","5"};
    //vector_aux.resize(vector1.size()); //Give to the size in another Container to copy items.
    //int i = 0;
    while(i < 3) {
        copy(begin(vector1), begin(vector1) + 2, vector1.begin() + 2*i);
        ++i;
    }
    cout<<endl;
    copy_if(begin(vector1),end(vector1),vector_aux.begin(),[](auto &x){'
        return x % 2 == 0;
    });

    //write_to_cout(vector1);cout<<endl;
    //for(const auto&i:vector_aux) cout<<i<<" ";
    std::copy_n(std::istream_iterator<std::string>(std::cin),3,vector_aux.begin());
    write_to_cout(vector_aux);

    //std::cout << "Hello, World!" << std::endl;
    return 0;
}
*/





#endif //STDGEMS_COPY_FILTER_H
