#include <iostream>
#include<random>
#include <list>
#include <ctime>
#include <initializer_list>
#include <tuple>

using namespace std;


template <typename T>
T rand_integral(T start, T end){
    random_device rd;
    default_random_engine eng (rd());
    uniform_int_distribution<T>dis(start,end);
    return dis(eng);
}

template <typename T>
vector<T> generate_repeat(size_t n){
    vector<T> source(n);
    for(T& item: source) item = rand_integral(1,10);

    vector<T> target;
    for(const T& item : source){
        auto start = target.size();
        target.resize(target.size()+item);
        fill(begin(target)+start,end(target),item);
    }
    return target;
}

template <typename T>
list<T> eliminate (size_t n){

    list<T>nuevo(n);
    for(T& item: nuevo) item = rand_integral(1,10);
    nuevo.sort();
    typename list<T>::iterator i , j;
    for(i = nuevo.begin(); i != nuevo.end();++i ){
        for( j = nuevo.begin() ; j != i ;++j){
            if(*i == *j){
                nuevo.erase(i);
            }
        }
    }
    return nuevo;

}


//EXERCISE 4
struct Fecha {
    int dia_;
    int mes_;
    int anio_;
    Fecha()=default;
    Fecha(int dia, int mes, int anio):dia_(dia),mes_(mes),anio_(anio){}
};

struct Hora : public Fecha{
    Fecha fecha;
    size_t hora_;
    size_t minuto_;
    size_t segundo_;
    Hora()=default;
    Hora(int hora ,int minuto, int segundo):hora_(hora),minuto_(minuto),segundo_(segundo){}
};

struct Agenda{
    vector<tuple<Fecha,Hora,string>> elem;
public:
    void insertar_evento(const Fecha &fecha, const Hora &hora, const string& descripcion){
        elem.emplace_back(fecha,hora,descripcion);
    }
    //list<pair<Hora,string> > eventos_dia(const Fecha &fecha){
    //    list<pair<Hora,string> > elemen;

    void mostras_evento(){
        for(auto&g:elem) {
            cout << "Dia: "<<get<0>(g).dia_ << endl;
            cout << "Mes: "<<get<0>(g).mes_ << endl;
            cout << "Año: "<<get<0>(g).anio_<<endl;
            cout << "Hora: "<<get<1>(g).hora_<<endl;
            cout << "Minuto: "<<get<1>(g).minuto_<<endl;
            cout << "Segundo: "<<get<1>(g).segundo_<<endl;
            cout << "Descripcion: "<<get<2>(g)<<endl;
            cout << endl;
        }
    }
    
    //}
};





int main() {

    //for(const auto &item: generate_repeat<int>(10))
    //    cout<< item << " ";
    //cout<<endl;


    
    
    /*unsigned t0, t1;
    t0=clock();
    for(const auto &item :eliminate<int>(20))
        cout<< item << " ";
    cout<<endl;
    t1 = clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    cout << "Execution Time: " << time << endl;
    */

    Agenda agenda;
    agenda.insertar_evento(Fecha(10,12,2000),Hora(20,59,30),"Mi primer evento agregado");
    agenda.insertar_evento(Fecha(25,10,1985),Hora(12,20,12),"Mi segundo evento agregado");
    agenda.mostras_evento();


    return 0;
}
