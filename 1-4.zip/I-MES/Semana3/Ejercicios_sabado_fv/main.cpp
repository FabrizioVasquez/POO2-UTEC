#include <iostream>
#include <stack>
#include <string>
#include<queue>
#include <algorithm>
using namespace std;

 //EXERCISE 1
stack<int> union_sandwich(stack<int> stack1, stack<int> stack2 ){
    stack<int> stack3;
    if(stack1.empty()){
        return stack2;
    }
    else if(stack2.empty()){
        return stack1;
    }
    else if(stack2.empty() && stack2.empty()){
    }

    size_t new_size = stack2.size()+ stack1.size();
    cout<<endl;
    for(size_t i = 1 ; i <= new_size; ++i){
        if(i % 2 == 0){
            int value = stack1.top();
            stack1.pop();
            stack3.push(value);
        }
        else if(i % 2 != 0){
            int value2 = stack2.top();
            stack2.pop();
            stack3.push(value2);
        }
    }
    return stack3;
}


//EXERCISE 2
stack<int>union_stacks(stack<int> stack3, stack<int> stack4 ) {
    stack<int> stack5;

    if(stack3.empty()){
        return stack4;
    }
    else if(stack4.empty()){
        return stack3;
    }
    else if(stack3.empty() && stack4.empty()){
    }
    size_t size_total = stack4.size()+stack3.size() -1 ;

    size_t size_3 = stack3.size();
    size_t size_4 = stack4.size();
    for(size_t i = 1 ; i <= size_3 ; ++i){
        int value_type = stack3.top();
        stack3.pop();
        stack5.push(value_type);
    }

    for(size_t i = size_3 ; i <= size_total; ++i){
        int value_type4 = stack4.top();
        stack4.pop();
        stack5.push(value_type4);
    }

    return stack5;
}

//EXERCISE 3
stack<string> sequence(stack<char>pal){
    stack<string> pala;
    if(!pal.empty()){
        basic_string<char> v = reinterpret_cast<basic_string<char> &&>(pal.top());
        pal.pop();
        pala.push(v);
    }
    return pala;
}

template <typename T>
void PrintStack(stack<T> stack1)
{
    if (stack1.empty())
        return;
    T x = stack1.top();

    stack1.pop();

    PrintStack(stack1);
    cout << x << " ";
    stack1.push(x);
}


//EXERCISE 6 a
void search_queue(queue<int> queue1, int value) {
    size_t index = 0;
    while (!queue1.empty()) {
        int value_type = queue1.front();
        if (value_type == value) {
            cout << "Valor encontrado en la posicion " << index+1;
        } else {
            index++;
        }
        queue1.pop();
    }
}

//EXERCISE 6 b
void inverter(queue<int>&queue2){
    stack<int> stack6;
    while(!queue2.empty()){
        stack6.push(queue2.front());
        queue2.pop();
    }
    while(!stack6.empty()){
        queue2.push(stack6.top());
        stack6.pop();
    }
    while(!queue2.empty()) {
        cout << queue2.front() << " ";
        queue2.pop();
    }
}



int main() {
    cout<<"EXERCISE 1"<<endl;

    stack<int> stack1;
    for(int i = 1; i <= 10; i++)
        stack1.push(i);


    stack<int> stack2;
    for(int i = 10 ; i <= 20;i++)
        stack2.push(i);

    PrintStack(stack1);
    cout<<endl;
    PrintStack(stack2);

    stack<int>pt = union_sandwich(stack1,stack2);
    PrintStack(pt);
    cout<<endl;


    cout<<"EXERCISE 2"<<endl;
    stack<int> stack3;
    for(int i = 1; i <= 10; i++)
        stack3.push(i);


    stack<int> stack4;
    for(int i = 10 ; i <= 20;i++)
        stack4.push(i);

    PrintStack(stack3);
    cout<<endl;
    PrintStack(stack4);
    cout<<endl;

    stack<int>pt2 = union_stacks(stack3,stack4);
    PrintStack(pt2);
    cout<<endl;



    cout<<"EXERCISE 6a"<<endl;
    queue<int>values;
    values.push(1);
    values.push(2);
    values.push(3);
    values.push(4);
    values.push(20);
    values.push(5);
    search_queue(values,20);


    cout<<"\nEXERCISE 6b"<<endl;
    queue<int>values2;
    values2.push(1);
    values2.push(2);
    values2.push(3);
    values2.push(4);
    values2.push(20);
    values2.push(5);
    inverter(values2);
    cout<<endl;


    stack<char>pal;
    pal.push('E');
    pal.push('A');
    pal.push('S');
    pal.push('Y');
    pal.push('*');
    pal.push('T');
    auto t1 = sequence(pal);
    PrintStack(t1);


    return 0;
}
