#include <iostream>
#include "funciones.h"
int main() {
    utec::first::f();
    utec::second::f();
    utec::f();      //namespace por default con inline
    //g();
    return 0;
}
