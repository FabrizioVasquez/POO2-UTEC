//
// Created by Fabrizio on 4/4/20.
//

#include "funciones.h"
#include <iostream>
using namespace std;

void utec::first::f() {
    std::cout<<"Funcion f - first"<<endl;
}

void utec::second::f() {
    std::cout<<"Funcion f - second"<<endl;
}

void utec::third::f() {
    std::cout<<"Funcion f - third"<<endl;
}

static void g(){
    cout<<"Funcion g"<<endl;
}
