//
// Created by Fabrizio on 4/4/20.
//

#ifndef NAMESPACE_FUNCIONES_H
#define NAMESPACE_FUNCIONES_H

namespace utec{
    namespace first{
        void f();
    }
    namespace second{
        void f();
    }
    inline namespace third{
        void f();
    }

}
static void g();

/*
namespace{
    void g();
}
*/

/*
 1.Existe un namesapce global
 2. Los namespace pueden ser anidados
 3. existen un namespace anidado por deafult (inline)
 4. existe un namespace sin-nombre que reemplaza funciones y variables estaticas
 5. namespace se pueden sub_dividir por archivos
 */


#endif //NAMESPACE_FUNCIONES_H
