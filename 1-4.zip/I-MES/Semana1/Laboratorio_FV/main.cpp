#include "Integer.h"

int buscar_impar(initializer_list<int>li){
    map<int,int>current;
    int max = 0,element_impar = 0;
    for(auto &elem:li){
        current[elem]++;
    }
    for(auto it = current.begin(); it !=current.end();++it){
        if(it->second % 2 == 1){
            if(it->second > max){
                max = it->second;
                element_impar = it->first;
            }
        }
    }
    return element_impar;
}

int calcular_pentagono(int n){
    int first = 1,sum = 0,new_suma = 0;
    for (int i = 1; i < 8; ++i) {
        sum += 5;
        new_suma += sum;
    }
    return new_suma + 1 ;
}

long long int factorial(int n){ //function factorial with tgamma function
    return tgamma(n+1);
}

template <size_t n > struct fact;   //Construction is necessary
template <> struct fact<0>{      //Base Case
    const static auto value = 1;
};
template <size_t n> struct fact{ //Recusive Definiton
    const static auto value = n * fact<n-1>::value;
};

// constexpr es una variable de solo lectura, el dice al compilador que calcule antes de hacer el ejecutable en tiempo de compilacion
template <typename T>
auto printStuff(T arg)->void{
    cout << arg <<endl;
}
template<typename Tfirst, typename ...Trest>
void printStuff(Tfirst first, Trest... rest){
    cout<<first<<' ';
    printStuff(rest...);
}

auto suma(auto a, auto b) -> decltype(b){
    return a + b;
}


int main() {
    //Lambda functions
    //cout<<[](int x, int y){return x+y;}(3,4)<<endl;
    //auto f = [](int x , int y){return x+y;};

    Integer a{},b{},c{};
    int d = 2;
    a = 5;
    b = 10;
    //c = a + 2;
    //a += b;
    a += 20;
    cout<<a;

    cout<<suma(10,20.9);


    /*
    auto a = buscar_impar({1, 1, 2, -2, 5, 2, 4, 4, -1, -2, 5});
    auto b = buscar_impar({20, 1, 1, 2, 2, 3, 3, 5, 5, 4, 20, 4, 5});
    auto c = buscar_impar({10});
    cout<<a<<endl;
    cout<<b<<endl;
    cout<<c<<endl;
    auto d = calcular_pentagono(8);
    cout<<d<<endl;

    cout<<fact<5>::value<<endl;
    cout<<factorial(5)<<endl;
    printStuff(3,3.3,"foo",42);
    */






    return 0;
}
