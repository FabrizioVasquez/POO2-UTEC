//
// Created by Fabrizio on 4/2/20.
//

#ifndef LABORATORIO_FV_VECTOR_HPP
#define LABORATORIO_FV_VECTOR_HPP

#include <cstddef>



namespace utec {
    class Vector {

    public:
        typedef std::size_t size_type;





        size_type size() const;


    private:
        int*data_;
        size_type m_size;
        size_type m_reserved;
    public:

        Vector();
        Vector(const Vector &other);   //Copy Constructor
        Vector (Vector &&other);          // Move constructor no crea copias temporales de modo que es mas eficiente
        Vector &operator=(const Vector &other);
        ~Vector();
        void push_back(int &other);
        void pop_back();
        void insert(int &item);
        void erase(int &item);
        Vector &operator+(const Vector &other);





    };

    //constexpr : obliga a que ocurra el cálculo en tiempo de compilación
    utec::Vector::Vector():data_(nullptr),m_size(0),m_reserved(0){}

    utec::Vector::Vector(const utec::Vector &other) {
        *this = other;
    }

    //
    utec::Vector::Vector(utec::Vector &&other) {
        this->data_ = other.data_;
        other.data_ = nullptr;
        this->m_size = 0;
        this->m_reserved = 0;
    }
    Vector & utec::Vector::operator=(const Vector &other) {
        m_reserved = other.size();

    }


    utec::Vector::size_type Vector::size() const {
        return m_size;
    }




}


#endif //LABORATORIO_FV_VECTOR_HPP
