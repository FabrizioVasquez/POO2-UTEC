//
// Created by Fabrizio on 3/30/20.
//
#include <iostream>
#include <map>
#include <cstddef>
#include <cmath>
using namespace std;
#ifndef LABORATORIO_FV_INTEGER_H
#define LABORATORIO_FV_INTEGER_H

//NOTA:
//1.-Si se agrea la palabra const "tipo de variable" e & entonces el constructor acepta tanto numeros aceptados
//   directamente como numeros pasados mediante variables.

class Integer {
        private:
        int value;
        public:
        Integer()= default;
        Integer(const Integer& other){                          // TODOS TIENE ESTO PARA LAS PRUEBAS
            value = other.value;                                // Integer a{},b{},c{};
                                                                // int d = 2;
                                                                // a = 5;
                                                                // b = 10;
        }
        Integer &operator=(const Integer &other){
            if(this == &other)return *this;
            value = other.value;
            return *this;
        }

        Integer &operator=(const int other_value){
            value = other_value;
            return *this;
        }

        //REVISAR ESTE CONSTRUCTOR PARA VER SI FUNCIONA CON Integer y no con int
        int operator+(const int &other_value){                // Constructor para que funcione esta suma:
            Integer aux;                                      //    c = a + d;
            aux.value = this->value + other_value;            //    c = a + 2;
            return aux.value;
        }
        Integer operator+(const Integer &other){
            Integer aux;
            aux.value = this->value + other.value;
            return aux;
        }

        Integer &operator+=(const Integer &other){            // Constructor that work to acumulate sum;
            value += other.value;                             //    a += b;
            return *this;
        }

        Integer &operator+=(const int &other_value){          // Constructor that work to acumulate sum;
            value += other_value;                             //    a += 20;
            return *this;
        }


        Integer operator-(int value);
        Integer operator-=(const Integer &other);

        Integer &operator>(const Integer &other);
        Integer &operator>=(const Integer &other);
        Integer &operator<(const Integer &other);
        Integer &operator<=(const Integer &other);
        Integer &operator!=(const Integer &other);
        Integer &operator==(const Integer &other);

        //operator int();
        friend ostream& operator <<(ostream&os, const Integer& other){
            os << other.value<<endl;
        }
        friend ostream& operator >>(istream&os, Integer& other);

};


#endif //LABORATORIO_FV_INTEGER_H
