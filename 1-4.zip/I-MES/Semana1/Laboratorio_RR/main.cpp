#include <iostream>
#include <fstream>
using namespace std;

int main() {

    fstream in;
    in.open("../in.txt",ios::in);
    //ifstream in("in.txt");
    if(!in.is_open()){
        cout<<"ERROR: no se pudo abrir el archivo"<<endl;
    }
    //leer el contenido
    int x;
    int i = 0;
    int *arr = nullptr;
    int size = 0;
    //file >> x; //enviar el contenido de file hacia la variable con ">>"
    while(in >> x){
        int *aux = new int[size+1];
        for (int i = 0; i < size;i++) {
            aux[i] = arr[i];
        }
        aux[size++] = x ;
        delete []arr;
        arr = aux;
        size++;
    }

    //Cierro el archivo
    in.close();

    //in.clear(); // se resetea el puntero
    //in.seekg(0,ios::beg); //aqui indicamos que indice de nuevo el recorrido desde el principio con ios::beg
    ofstream out("../out.txt");
    while(in>>x){
        out<< x <<endl;
    }



    return 0;
}
