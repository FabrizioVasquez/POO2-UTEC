//
// Created by Fabrizio on 3/31/20.
//
#include <iostream>
#include <vector>
#include <ctime>
#include <sstream>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Audio.hpp>

#ifndef SFML_ONE_GAME_H
#define SFML_ONE_GAME_H


//NOTA 1: Si deseas usar texturas primero debes usar Sprites.
//NOTA 2: Si deseas agregar texto debes crear una sf::Text que almacene tu tipo de variable sf::font

class Game {
private:
    //VARIABLES
    //WINDOW
    sf::RenderWindow* window;
    sf::VideoMode videoMode;
    sf::Event ev;

    //MOUSE POSITION
    sf::Vector2i mousePosWindow;    //Se usa para trabajar con el interfaz del usuario
    sf::Vector2f mousePosView;  //Se usa este tipo de variable flotante porque SFML trabajo con dicho valores y queremos manejar la pnatalla.

    //RESOURCES
    sf::Font font;

    //TEXT
    sf::Text uiText;

    //GAME LOGIC
    bool endGame;
    unsigned points;
    int health;
    float enemySpawTimer;
    float enemySpawTimerMax;
    int maxEnemies;

    bool mouseHeld;


    //GAME OBJECT
    std::vector<sf::RectangleShape> enemies;
    sf::RectangleShape enemy;

    //PRIVATE FUNCTIONS
    void intializeVariables();
    void initWindow();
    void initFonts();
    void initText();
    void initEnemies();

public:
    Game();
    virtual ~Game();

    //ACCESSORS
    const bool running() const;    //booleano para reconocer si window isOpen() == true.
    const bool getEndGame() const;

    //FUNCTIONS
    void spawnEnemy();          //funcion para engendrar enemigos dentro de updateEnemies


    void pollEvents();
    void updateMousePosition(); //funcion para actualizar la posicion del mouse (UPDATE.SECUNDARIO)

    void updateText();

    void updateEnemies();       //funcion para actualizar a los enemigos (UPDATE.SECUNDARIO)

    void update();              //funcion para actualizar ALL (UPDATE.PRINCIPAL)


    void renderText(sf::RenderTarget& target);

    void renderEnemies(sf::RenderTarget& target);       //funcion para renderizar a los enemigos (RENDER.SECUNDARIO)

    void render();              //funcion para renderiar ALL (RENDER.PRINCIPAL)
};


#endif //SFML_ONE_GAME_H
