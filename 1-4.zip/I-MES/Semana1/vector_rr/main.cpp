#include <iostream>
#include "vector.h"
int& f(int &x){
    return x;
}

int main() {
    int x = 10;
    f(x) = 20;


    //la linea 9 es equivalente a 13 y 14
    //int &f_ = x;
    //f_ = 20;

    //std::cout<<x<<std::endl;

    //utec::alpha::vector<char> vector = {'f','a','b','r','i','z','i','o'};
    //vector.push_back('f');
    //vector.push_back('a');
    //vector.push_back('b');
    //vector.push_back('r');
    //vector.push_back('i');
    //vector.push_back('z');
    //vector.push_back('i');
    //vector.push_back('o');
    //vector.push_back('v');
    //vector.push_back('a');
    //vector.erase(0);

    utec::alpha::vector<int>vector{};
    vector.push_back(1,2,3,4,5,6,7,8,9,10);
    std::cout<<"{";
    for (int i = 0; i < vector.size(); ++i) {
        std::cout<<vector[i];
        if(i < vector.size()-1){
            std::cout<<",";
        }
        else {
            std::cout << "}";
        }
    }



    return 0;
}
