//
// Created by Fabrizio on 4/4/20.
//

#include "vector.h"
utec::beta::vector::vector(size_t n):size_(n),capacity_(n == 0 ? 1 : n),data_(new int [n]) {}

utec::beta::vector::vector(const utec::beta::vector &other):
size_(other.size_),
capacity_(other.capacity_),
data_(new int [other.capacity_]){
    for (size_t i = 0; i < size_ ; ++i) {
        data_[i] = other.data_[i];
    }
}

utec::beta::vector &utec::beta::vector::operator=(const utec::beta::vector &other) {
    capacity_ = other.capacity_;
    size_= other.size_;
    if(this == &other)return *this;
    if(data_ != nullptr) delete [] data_;

    //se refiere al almacenamiento del other.*
    data_ = new int[capacity_];
    for (size_t i = 0; i < size_ ; ++i) {
        data_[i] = other.data_[i];
    }
    return *this;
}


utec::beta::vector::vector(utec::beta::vector &&other)noexcept:
        size_(std::move(other.size_)),
        capacity_(std::move(other.capacity_)),
        data_(std::move(other.data_)) {
    other.data_ = nullptr;
}

utec::beta::vector &utec::beta::vector::operator=(utec::beta::vector &&other)noexcept{
    delete [] data_;
    size_ = std::move(other.size_);
    capacity_ = std::move(other.capacity_);
    data_ = std::move(other.data_);
    return *this;
}

utec::beta::vector::~vector() {
    size_ = capacity_ = 0;
    delete [] data_;
}

void utec::beta::vector::push_back(int item) {

    if(size_ + 1 >= capacity_){
        capacity_ *= 2;
        int *aux = new int[capacity_];
        for (size_t i = 0; i < size_    ; ++i)
            aux[i] = data_[i];
        delete [] data_;
        data_ = aux;     //DATA APUNTE A AUX
    }
    data_[size_++] = item;

}

void utec::beta::vector::pop_back() {
    if(size_ == 0)return;
    if(size_ - 1  <= capacity_  / 4){
        capacity_ /=2;
        int *aux = new int[capacity_];
        for (size_t i = 0; i < size_ ; ++i)
            aux[i] = data_[i];
        delete [] data_;
        data_ = aux;
    }
    --size_;
}
void utec::beta::vector::insert(size_t index, int item) {
    if(size_+1 > capacity_){
        capacity_ *= 2;
        int *aux = new int[capacity_];

        size_t j = 0, i = 0;
        while(i < index)
            aux[j++] =  data_[i++];
        aux[j++] = item;

        while(i < size_)
            aux[j++] = data_[i++];
        data_ = aux;
    }
    else{
        size_t i = size_;           //asigamos el ultimo a i
        while(i++ > index)
            data_[i+1] = data_[i];
        data_[index] = item;
    }
    ++size_;
}

void utec::beta::vector::erase(size_t index) {
    //auto item = data_[index];
    //if(size_ == index == 0)return;
    for (size_t i = index; i < size_ ; ++i) {
        data_[i] = data_[i+1];
    }
    size_--;

}

int &utec::beta::vector::operator[](size_t index) {
    return data_[index];
}

const int &utec::beta::vector::operator[](size_t index) const {
    return data_[index];
}

size_t utec::beta::vector::size() const {
    return size_;
}
