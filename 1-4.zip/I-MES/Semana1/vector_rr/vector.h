//
// Created by Fabrizio on 4/4/20.
//

#ifndef VECTOR_RR_VECTOR_H
#define VECTOR_RR_VECTOR_H

#include <cstddef>
#include <initializer_list>
#include <algorithm>


namespace utec{
    inline namespace beta{
        class vector {
        private:
            int* data_ = nullptr;
            size_t size_ = 0 ;
            size_t capacity_ = 1;
        public:
            vector(size_t n);                       //constructor por parametro
            vector()= default;                               //constructor por defecto
            vector(const vector& other);            //constructor copia
            vector&operator=(const vector& other);  //operador asignacion
            vector(vector&& other) noexcept ;            //constructor move
            vector&operator=(vector&& other) noexcept ;  //operador asignacion move

            ~vector();


            void push_back(int item);
            void pop_back();
            void insert(size_t index, int item);
            void erase(size_t index);

            int& operator[](size_t index);                 //Asignacion(escritura) de valores
            const int& operator[](size_t index) const;     //Leer valores       hay dos referencia la primera es const reference

            size_t size() const;                            //cuando declare const puedo usar las otras funciones tipo const, esta no hace niguna modificacion

        };
    };

    inline namespace alpha{
        template<typename T > class vector{
        private:
            T *data_;
            size_t size_;
            size_t CAPACITY_;
        public:
            vector()=default;
            template<T>
            explicit vector(size_t n):size_(n),CAPACITY_(n==0 ? 1:n),data_(new T[n]){}

            vector(std::initializer_list<T> il){
                size_ = il.size();
                CAPACITY_ = il.size();
                data_ = new T[il.size()];
                std::copy(il.begin(),il.end(),data_);
            }


            template<T>
            explicit vector(const vector<T>& other):
            size_(other.size_),
            CAPACITY_(other.CAPACITY_),
            data_(new T[other.CAPACITY_]){
                for (size_t i = 0; i < size_ ; ++i) {
                    data_[i] = other.data_[i];
                }
            }

            template<T>
            vector&operator=(const vector<T>& other){
                CAPACITY_ = other.capacity_;
                size_= other.size_;
                if(this == &other)return *this;
                if(data_ != nullptr) delete [] data_;

                //se refiere al almacenamiento del other.*
                data_ = new T[CAPACITY_];
                for (size_t i = 0; i < size_ ; ++i) {
                    data_[i] = other.data_[i];
                }
                return *this;
            }

            ~vector(){
                size_ = CAPACITY_ = 0;
                delete [] data_;
            }


            void push_back(T item){
                if(size_ + 1 >= CAPACITY_){
                    CAPACITY_ *=2;
                    T *aux = new T[CAPACITY_];
                    for (size_t i = 0; i < size_; ++i) {
                        aux[i] = data_[i];
                    }
                    delete [] data_;
                    data_ = aux;
                }
                data_[size_++] = item;
            }

            template <typename ... Args>
            void push_back(Args ... args){
                (this->push_back(args),...);
            }

            template<T>
            void pop_back(){
                if(size_ == 0)return;
                if(size_ - 1 <= CAPACITY_ / 4){
                    CAPACITY_ /=2;
                    T *aux = new T[CAPACITY_];
                    for (size_t i = 0; i < size_; ++i) {
                        aux[i] = data_[i];
                    }
                    delete []data_;
                    data_ = aux;
                }
                --size_;
            }



            void erase(int index){
                for (size_t i = index; i < size_ ; ++i) {
                    data_[i] = data_[i+1];
                }
                --size_;
            }


            size_t size() const{
                return size_;
            }

            T& operator[](size_t index){
                return data_[index];
            }
            const T& operator[](size_t index)const {
                return data_[index];
            }

        };

    }
}


#endif //VECTOR_RR_VECTOR_H
