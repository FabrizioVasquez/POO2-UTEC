#include <iostream>
#include <string>
using namespace std;


auto f(const string &texto) -> void{
    cout<<"Texto: "<< texto;
}

int main() {
    f("Ruben");            //esto se le pasa un rvalue
    int x = 10;                 // 10 is a rvalue
    int &y = x ;                // reference lvalue
    const int &z = 10;          // reference rvalue/lvalue . this cannot be modified(READ ONLY)
    const int &w = x;

    //Version   C++11
    int&& g = 10;               // reference rvalue
    cout<< g <<endl;
    g = 20;
    cout<< g <<endl;

    //&&
    // 1. move semantic (constructores del tipo)
    // 2. forward reference (deducion de argumentos de template)

    return 0;
}
