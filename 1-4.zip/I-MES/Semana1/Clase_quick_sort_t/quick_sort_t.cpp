//
// Created by Fabrizio on 3/30/20.
//

#include "quick_sort_t.h"
#include "funciones.h"


quick_sort_t::quick_sort_t():m_data{nullptr},m_size{0} {

}

quick_sort_t::~quick_sort_t() {

        delete [] m_data;

}


quick_sort_t &quick_sort_t::operator<<(const string &file_name) {

    ifstream in("../"+file_name);

    //validar la apertura
    if(!in.is_open()){
        std::cout << "ERROR: Failed, file not found";
        return *this;   //THIS ES UN PUNTERO QUE SE RETORNA  ASI MISMO,(*THHIS) NOS DEVUELVE E OBJETO. THIS NOS DEVUELVE LA DIRECCION
    }

    //GENERAMOS EL ARREGLO DINAMICO CON INFORMACION DEL ARCHIVO

    int value{};        //Asi se inicializa para generalizar cualquier valor con "{}"
    while(in >> value){
        int *aux = new int[m_size+1];
        for (int i = 0; i < m_size;i++) {
            aux[i] = m_data[i];
        }
        aux[m_size] = value ;
        delete []m_data;
        m_data = aux;    //aux apunta a la direccion de memoria de m_data y por lo tanto le pasa los datos
        m_size++;
    }

    //ORDENAR
    in.close();
    quick_sort(m_data,0, m_size-1);

    return*this;
}

quick_sort_t &quick_sort_t::operator>>(const string &file_name) {
    std::ofstream out("../"+file_name);


    if(!out.is_open()){
        cout<<"ERROR";
    }
    else{
        for (size_t i = 0; i < m_size; ++i) {
            out<<m_data[i]<<endl;
        }
    }
    return*this;
}
//quick_sort_t &operator<<(quick_sort_t &qs, const string &file_name) {
    //return <#initializer#>;
//}

//quick_sort_t &operator>>(quick_sort_t &qs, const string &file_name) {
    //return <#initializer#>;
//}
