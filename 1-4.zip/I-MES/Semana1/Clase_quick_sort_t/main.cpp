#include <iostream>
#include "quick_sort_t.h"

int main() {
    quick_sort_t qs;
    qs << "in.txt";
    qs >> "out.txt";

    return 0;
}
