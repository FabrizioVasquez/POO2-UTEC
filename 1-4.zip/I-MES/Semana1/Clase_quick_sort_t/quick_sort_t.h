//
// Created by Fabrizio on 3/30/20.
//

#ifndef CLASE_QUICK_SORT_T_QUICK_SORT_T_H
#define CLASE_QUICK_SORT_T_QUICK_SORT_T_H

#include <fstream>
#include <iostream>
#include <cstddef>
using namespace std;

class quick_sort_t {
private:
    int* m_data;
    int m_size;  //nomenclatura underscore_

public:
    quick_sort_t();
    ~quick_sort_t();
    quick_sort_t&operator <<(const string& file_name);
    quick_sort_t&operator >>(const string& file_name);

    //friend quick_sort_t& operator << (quick_sort_t& qs, const string& file_name );
    //friend quick_sort_t& operator >> (quick_sort_t& qs, const string& file_name );
};


#endif //CLASE_QUICK_SORT_T_QUICK_SORT_T_H
