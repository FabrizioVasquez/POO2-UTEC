//
// Created by Fabrizio on 3/30/20.
//

#include "funciones.h"


//QUICKSORT RECURSIVO
int partition(int *data, int start, int end) {
    auto pivot = data[end];
    auto pi = start;
    for (int i = start; i < end; i++) {
        if(data[i] <= pivot){
            swap(data[pi], data[i]);
            pi++;
        }
    }
    swap(data[pi],data[end]);
    return pi;
}

void quick_sort(int *data, int start, int end) {
    if(start >= end)return; // solo retorna asi porque la funcion es void
    auto pi = partition(data,start,end);
    quick_sort(data,start,pi-1);
    quick_sort(data,pi+1,end);
}



//QUICKSORT ITERATIVO
// Función para dividir el array y hacer los intercambios
int divide(int *array, int start, int end) {
    int left;
    int right;
    int pivot;
    int temp;

    pivot = array[start];
    left = start;
    right = end;

    // Mientras no se cruzen los índices
    while (left < right) {
        while (array[right] > pivot) {
            right--;
        }

        while ((left < right) && (array[left] <= pivot)) {
            left++;
        }

        // Si todavía no se cruzan los indices seguimos intercambiando
        if (left < right) {
            temp = array[left];
            array[left] = array[right];
            array[right] = temp;
        }
    }

    // Los índices ya se han cruzado, ponemos el pivot en el lugar que le corresponde
    temp = array[right];
    array[right] = array[start];
    array[start] = temp;

    // La nueva posición del pivot
    return right;
}

// Función recursiva para hacer el ordenamiento
void quicksort_iterativo(int *array, int start, int end)
{
    int pivot;

    if (start < end) {
        pivot = divide(array, start, end);

        // Ordeno la lista de los menores
        quicksort_iterativo(array, start, pivot - 1);

        // Ordeno la lista de los mayores
        quicksort_iterativo(array, pivot + 1, end);
    }
}