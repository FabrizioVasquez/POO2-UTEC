//
// Created by Fabrizio on 3/30/20.
//

#ifndef QUICKSORT_FUNCIONES_H
#define QUICKSORT_FUNCIONES_H

#include <utility>
using namespace std;

//QUICKSORT_RECURSIVO
int partition(int *data, int start, int end );
void quick_sort(int *data, int start, int end);

//QUICKSORT_ITERATIVO
int divide(int *array,int start,int end);
void quicksort_iterativo(int* array,int start,int end);
#endif //QUICKSORT_FUNCIONES_H
