//
// Created by root on 3/28/20.
//

#ifndef CLASE_QUICKSORT_QUICK_SORT_H
#define CLASE_QUICKSORT_QUICK_SORT_H

#include <string>

using namespace std;

class quick_sort_t {
private:
    int* m_data;
    int m_size;
public:
    quick_sort_t();
    ~quick_sort_t();
    quick_sort_t&operator << (const string& file_name);
    quick_sort_t&operator >> (const string& file_name);
};


#endif //CLASE_QUICKSORT_QUICK_SORT_H
