//
// Created by root on 3/28/20.
//

#ifndef QUICK_SORT_FUNCIONES_H
#define QUICK_SORT_FUNCIONES_H
#include <utility>

using namespace std;

int partition(int *data, int start, int end);
void quick_sort(int* data, int start, int end);

#endif //QUICK_SORT_FUNCIONES_H
