//
// Created by root on 3/28/20.
//

#include "quick_sort.h"
#include "funciones.h"
#include <iostream>
#include <fstream>

quick_sort_t::quick_sort_t(): m_data(nullptr), m_size(0)  {
}

quick_sort_t::~quick_sort_t() {
    delete [] m_data;
}

/*
 *
    Operador unario
    bool activo = false;
    if (!activo)
        .......

    Operadores binarios
    int a = 20;
    int b = 30;

    auto z = a + b;
    auto y = a << b;

    Operador Terciario
    auto w = condicion_logica ? valor_verdadero : valor_falso;
 *
 */

quick_sort_t &quick_sort_t::operator<<(const string &file_name) {
    // Crear el objeto archivo
    ifstream in(file_name);

    // Validar la apertura
    if (! in.is_open()) {
        std::cout << "Error: Archivo incorrecto";
        return *this;
    }

    // Generamos el arreglo dinamico con informacion de archivo
    int value{};
    while (in >> value)
    {
        int* aux = new int[m_size + 1];
        for(int i = 0; i < m_size; i++) {
            aux[i] = m_data[i];
        }
        aux[m_size] = value;
        delete [] m_data;
        m_data = aux;
        m_size++;
    }

    // Ordenar
    quick_sort(m_data, 0, m_size -1);
    return *this;
}


quick_sort_t &quick_sort_t::operator>>(const string &file_name) {
    std::ofstream out(file_name);
    if (out.is_open()) {
        for (size_t i = 0; i < m_size; ++i)
            out << m_data[i] << std::endl;
    }
    return *this;
}

