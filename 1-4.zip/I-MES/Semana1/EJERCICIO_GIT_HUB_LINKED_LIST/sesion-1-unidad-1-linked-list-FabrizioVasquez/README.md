# cs1103_2020_1_linked_list
Ejercicio de Linked List
