#include <iostream>
#include <random>
#include <map>
#include <unordered_map>
#include <set>
#include <algorithm>
#include <list>
using namespace std;


//RANDOM
template <typename T = int>
void random(T n){
    random_device rd;
    default_random_engine re(rd());
    uniform_int_distribution<T>ud(1,10);

    vector<int> vector1(n);
    unordered_map<int,int> map1;


    for(auto &elem:vector1) {
        elem = ud(rd);
        map1[elem]++;
    }

    cout<<"\nOriginal\n";
    for(auto &e:vector1)cout<<e<<" ";
    cout<<endl;


    for(auto &a:map1){
        for(int i = 0; i < a.first;i++){
            cout<< a.first <<" ";
        }
    }
}


template < typename T >
void delete_repet(){
    random_device rd;
    default_random_engine re(rd());
    uniform_int_distribution<T>ud(1,50);
    typedef std::pair<int,int> pair;




    vector<T>vector2(500);
    vector<pair>order_vector2;
    map<int,int> mapa2;

    //contando frecuencias
    for(auto it = vector2.begin(); it != vector2.end();it++){
        auto elem = ud(rd);
        mapa2[elem]++;
    }
    //Copiando  llaves y valor del mapa en un vector order_vector;
    copy(mapa2.begin(),mapa2.end(),back_inserter<vector<pair>>(order_vector2));

    //Ordenando usando sort y una funcion anonima dentro de esta
    sort(order_vector2.begin(),order_vector2.end(),[](const pair& l,const pair& r){
        if(l.second != r.second){
            return l.second < r.second;
        }
        return l.first < r.first;
    });


    //Imprimiendo frecuencias
    //for(auto& il:mapa2){
    //    cout<<il.first<<" -> "<<il.second<<endl;
    //}
    cout<<endl;
    cout<<endl;
    cout<<endl;


    for(auto it = order_vector2.begin(); it != order_vector2.end();it++){
        if (it->second > 1){
            order_vector2.erase(order_vector2.begin());
        }
    }






    //Imprimiendo frecuencias ordenadas por valor
    for(auto const &other:order_vector2){
        cout<<other.first<< " -> "<<other.second<<endl;
    }





}


template <typename T>
void partir(list<T>& lista_origen, T &pivote, list<T> &izquierda, list<T> &derecha){
    auto it = lista_origen.begin();
    auto beg = lista_origen.begin();
    std::advance(it, pivote);

    izquierda.splice(izquierda.begin(),izquierda,beg,it);
    derecha.splice(derecha.begin(),derecha,it,lista_origen.end());
    ss
    //copy(cbegin(izquierda),cend(izquierda),ostream_iterator<int>(cout," "));cout << endl;
    //copy(cbegin(derecha),cend(derecha),ostream_iterator<int>(cout, " "));cout<<endl;
}

template < typename T>
void sort(list<T> &list1){
    list<T>izquierda;
    list<T>derecha;

    auto it = list1.begin();
    int index = *it;


    if(!list1.empty()){
        int i = 0;
        while(i < list1.size())   {
            partir(list1,i,izquierda,derecha);
            partir(list1,i,izquierda,derecha );
            i++;
        }
    }
}

bool menor(int &a, int&b){
    return a < b ;
}


int main() {
    //random<int>(10);
    //delete_repet<int>();

    list<int>list1{3,6,9,7,4,2,1};
    list<int>list2{};
    list<int>list3{};

    partir(list1, 2, list3, list2);


    for(auto &it: list1)
        cout<<it;

    //sort(list1);

    list<int>::iterator it;
    /*
    it = list1.begin();
    it++;
    list2.splice(list2.begin(),list1);


    std::cout << "mylist1 contains:";
    for (it=list1.begin(); it!=list1.end(); ++it)
        std::cout << ' ' << *it;
    std::cout << '\n';

    std::cout << "mylist2 contains:";
    for (it=list2.begin(); it!=list2.end(); ++it)
        std::cout << ' ' << *it;
    std::cout << '\n';
     */


    return 0;
}
