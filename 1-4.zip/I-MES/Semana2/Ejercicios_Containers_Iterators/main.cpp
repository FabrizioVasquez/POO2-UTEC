#include <iostream>
#include <vector>
#include <list>
#include<unordered_set>
#include <ctime>
using namespace std;

//EXERCISE 1
template< typename Iterator , typename Object>
Iterator buscar(Iterator start, Iterator end, const Object & x){
    for(auto it = start ; it != end;++it){
        if(*it == x) {
            return it;
        }
    }
    return end;
}
//EXERCISE 2
template< class Input1, class Input2, class Output>
Output Merge(Input1 first1,Input1 last1, Input2 first2, Input2 last2, Output d_first){
    for (;first1 != last1; ++d_first) {
        if (first2 == last2) {
            return std::copy(first1, last1, d_first);
        }
        if (*first2 < *first1) {
            *d_first = *first2;
            ++first2;
        } else {
            *d_first = *first1;
            ++first1;
        }
    }
    return std::copy(first2, last2, d_first);
}


//EXERCISE 3
void intersection(list<int>&lista1,list<int>&lista2){
    lista1.sort();
    lista2.sort();
    for(auto it1 = lista1.begin(); it1 != lista1.end(); it1++){
        for(auto it2 = lista2.begin();it2 != lista2.end();it2++){
            if(*it1 == *it2){
                lista1.erase(it1);
            }
        }
    }
    lista1.merge(lista2);
}

//EXERCISE 4
template< class Input1, class Input2, class Output>
Output Union(Input1 first1,Input1 last1, Input2 first2, Input2 last2, Output d_first){

    for (auto it = first1;first1 != last1; ++d_first) {
        if (first2 == last2) {
            return copy(it, last1, d_first);
        }
        if (*first2 < *it) {
            *d_first = *first2;
            ++first2;
        } else {
            *d_first = *it;
            ++it;
        }
    }
    return copy(first2, last2, d_first);
}



//EXERCISE 5

//template < template <class>typename Container ,typename T>
//void insert_sorted(Container<T> cnt, T value);
//No se logro deducir la funcion dentro del main por lo que desarrolle dos versiones para el insert sorted.

void insert_sorted(vector<int> &cnt, int value){
    typename vector<int>::iterator it1,it2;
    cnt.push_back(value);
    for(it1 = cnt.begin() ; it1 != cnt.end(); it1++ ){
        for(it2 = cnt.begin(); it2 != it1 ; it2++){
            if(*it1 < *it2){
                auto aux_it = *it1;
                *it1 = *it2;
                *it2 = aux_it;
            }
        }
    }
    cout<<endl;
    for(auto it = cnt.begin() ; it != cnt.end(); it++ ){
        cout<<*it<<" ";
    }
}

void insert_sorted(list<int> &cnt, int value){
    cnt.push_back(value);
    typename list<int>::iterator it1 ,it2;
    for(it1 = cnt.begin() ; it1 != cnt.end(); it1++ ){
        for(it2 = cnt.begin(); it2 != it1 ; it2++){
            if(*it1 < *it2){
                auto aux_it = *it1;
                *it1 = *it2;
                *it2 = aux_it;
            }
        }
    }

    cout<<endl;
    /*for(auto it = cnt.begin() ; it != cnt.end(); it++ ){
        cout<<*it<<" ";
    }
    cout<<endl;*/
}



//EXERCISE 6
template< class ForwardIt, class T>
ForwardIt Remove(ForwardIt first, ForwardIt last, const T& value ){
    first = find(first, last, value);
    auto f = last;
    if (first != last)
        for(auto it2 = first; it2 != last;++it2 ) {
            if (!(*it2 == value)) {
                *first++ = move(*it2);
                *f++;
            }
        }
    return f;
}


//EXERCISE 7
template < class InputIt, class OutputIt>
OutputIt Copy(InputIt first, InputIt last, OutputIt d_first){
    for(auto it = first; it != last; it++){
        *d_first = *it;
        ++d_first;
    }
    return d_first;
}


//EXERCISE 8
template < class InputIt, class UnaryFunction>
void For_each(InputIt first, InputIt last, UnaryFunction function){
    for(auto it = first;first != last; ++first){
        function(*it);
        *it++;
    }
}

//EXERCISE 9
template < class InputIt, class OutputIt ,class UnaryFunction>
OutputIt Transform(InputIt first, InputIt last, OutputIt d_first ,UnaryFunction function){
    for(;first != last; ++first){
        *d_first = *first;
        *d_first= function(*d_first);
        *d_first++;
    }
    return d_first;
}

//EXERCISE 10

struct Nodo{
            size_t terror;
            Nodo *next;
            Nodo(size_t mirror, Nodo* pointer):terror(mirror),next(pointer){}

        };


void function_josefo(size_t N,size_t M,vector<int>&muertos){
    size_t i{};
    unsigned t0{}, t1{};
    t0=clock();

    Nodo* around = new Nodo{1, nullptr};
    Nodo* init = around;
    for(i = 2 ; i <= N;i++) {
        init->next = new Nodo{i,around};
        init = init->next;
    }
    cout<<"Muertos: ";
    while(init != init->next){
        for(i = 0 ; i< M; i++){
            init = init->next;
        }
        around = init->next;
        init->next = around->next;
        cout<<around->terror<<" ";
        muertos.push_back(around->terror);
        delete around;
    }
    cout<<"\nSuvivor: " << init->terror<<endl;

    t1 = clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    cout << "Execution Time: " << time << endl;
}

void function_josefo(size_t N,size_t M){
    size_t i{};
    unsigned t0{}, t1{};
    t0=clock();

    Nodo* around = new Nodo{1, nullptr};
    Nodo* init = around;
    for(i = 2 ; i <= N;i++) {
        init->next = new Nodo{i,around};
        init = init->next;
    }

    while(init != init->next){
        for(i = 0 ; i< M; i++){
            init = init->next;
        }
        around = init->next;
        init->next = around->next;
        delete around;
    }

    cout<<"Suvivor: " << init->terror<<endl;
    t1 = clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    cout << "Execution Time: " << time << endl;
}

int main() {

    //EXERCISE 10
    vector<int>muertos1;
    vector<int>muertos2;
    cout<<"+"<<endl;
    function_josefo(5,1,muertos1);
    cout<<"+"<<endl;
    function_josefo(5,0,muertos2);
    cout<<"+++"<<endl;
    function_josefo(10000,4);
    cout<<"+++++"<<endl;
    function_josefo(100000,4);
    vector<int>result1{2,4,1,5};
    vector<int>result2{1,2,3,4};
    assert(result1 == muertos1);
    assert(result2 == muertos2);


    //EXERCISE 1
    vector<int> vector1={10,20,30,40,50};
    int number = 40;
    vector<int>::iterator it ;
    it = buscar<vector<int>::iterator,int>(vector1.begin(),vector1.end(),number);
    int rpt = *it;
    assert(number == rpt);

    //cout<<endl;

    //EXERCISE 2

    vector<int> vector11={100,30,40,60,80};
    vector<int>vector2={90,10,50,20,70};
    vector<int>merge;
    vector<int>result={90,10,50,20,70,100,30,40,60,80};
    //sort(vector1.begin(),end(vector1));
    //sort(vector2.begin(),end(vector2));

    Merge(vector11.begin(), vector11.end(), vector2.begin(), vector2.end(), std::back_inserter(merge));
    //for(auto & i:merge){
    //    cout<<i<<" ";
    //}
    //assert(result == merge);


    //EXERCISE 3
    list<int>lista13{5,7,3,9,2,3,4,6};
    list<int>lista23{1,7,8,9,2,3,4,6};
    list<int>result3{1,2,3,4,5,6,7,8,9};
    intersection(lista13,lista23);
    //lista1{1,2,3,4,5,6,7,8,9}
    assert(result3 == lista13);


    //EXERCISE 4

    list<int>vector14={100,30,40,60,80,20};
    list<int>vector24={90,10,50,20,70};
    list<int>merge4;
    list<int>result4={90,10,50,20,70,100,30,40,60,80,20};
    //sort(vector1.begin(),end(vector1));
    //sort(vector2.begin(),end(vector2));

    Union(vector14.begin(), vector14.end(), vector24.begin(), vector24.end(), std::back_inserter(merge4));
    //for(auto & i:merge4)
    //    cout<<i<<" ";

    assert(result4 == merge4);


    //EXERCISE 5
    list<int> list15{6,7,5};
    vector<int> vector35{150,1000,23,2,45};
    list<int>result15{5,6,7,8};
    vector<int>result25{2,23,45,150,200,1000};
    insert_sorted(list15,8);
    insert_sorted(vector35,200);
    assert(result15 == list15);
    assert(result25 == vector35);


    //EXERCISE 6
    list<int> vector46{5,6,8,9,10,6,7,6,9,4,5,10,8};
    auto end2 = Remove(begin(vector46),end(vector46),6);
    //auto end3 = Remove(begin(vector4),end(vector4),3); caso donde el elemento no existe
    vector46.resize(*end2);
    //for(auto i = vector46.begin(); i != end(vector46);++i){
    //    cout<<*i;
    //}
    //Verificando el tamaño de la lista sea menos que la lista original despues de eliminar elemento value
    auto iterator_end2 = 10;
    auto iterator_end3 = 13;
    //assert(iterator_end3 == *end3 );
    assert(iterator_end2 == *end2 );

    //EXERCISE 7
    vector<int>vector7{1,2,3,4,5,6,7,8,9,10};
    vector<int>aux7;
    auto it7 = aux7.begin();
    Copy(vector7.begin(),vector7.end(),it7);
    assert(aux7 == vector7 );


    //EXERCISE 8
    list<int>lista8{1,2,3,4,5,6,7,8,9,10};
    list<int>lista8_result{0,1,2,3,4,5,6,7,8,9};
    For_each(lista8.begin(),lista8.end(),[](int &a){
       return  a--;
    });
    assert(lista8_result == lista8);


    //EXERCISE 9
    list<int>lista9{1,2,3,4,5,6,7,8,9,10};
    list<int>lista9_result{2,4,6,8,10,12,14,16,18,20};
    string nombre = "FABRIZIO";
    string nombre_result = "fabrizio";

    Transform(nombre.begin(),nombre.end(),nombre.begin(),(int(*)(int))tolower);
    Transform(lista9.begin(),lista9.end(),lista9.begin(),[](int &a){
        return  a*2;
    });
    assert(lista9_result == lista9);
    assert(nombre_result == nombre);

    return 0;
}
