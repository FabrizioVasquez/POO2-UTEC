//
// Created by Fabrizio on 4/15/20.
//

#ifndef PC1_2019_TWOLINKEDLIST_H
#define PC1_2019_TWOLINKEDLIST_H

#include <iostream>
#include <fstream>
#include <ostream>
using namespace std;
struct Node{
    int value = 0;
    Node* next;
};

class TwoLinkedList {
public:
    Node *head1;
    Node *head2;
    Node *tail1;
    Node *tail2;
    Node *tail;
    int size = 0;
public:
    TwoLinkedList(){
        head1 = nullptr;
        head2 = nullptr;
        tail1 = nullptr;
        tail2 = nullptr;
        tail = nullptr;
    }
    ~TwoLinkedList(){
    }
    void push_back1(int value){
        Node *node = new Node{value};

        if(tail== nullptr) {
            if (head1 == nullptr) {
                head1 = node;
                tail1 = node;
            } else {
                tail1->next = node;
                tail1 = node;
            }
        }else{
            tail->next=node;
            tail = node;
        }
    }

    void push_back2(int value){
        Node *node = new Node{value};
        tail2 = node;
        if(tail2 == nullptr){
            tail2 = node;
        }else{
            if(is_merge()){
                tail->next = node;
                tail = node;
            }else{
                tail2->next = node;
                tail2 = node;
            }
        }
        size++;
    }

    string merge(int value){
        if(size != 0){
            Node*intersection = new Node{};
            if(is_merge()){
                return "Operacion Duplicada";
            }else{
                tail->next = intersection;
                tail = intersection;
                return "Operacion Exitosa";
            }
        }
    }


    bool is_merge(){
        while(tail1->next != nullptr && tail2->next != nullptr) {
            tail1 = tail1->next;
            tail2 = tail2->next;
            if( tail1->value == tail2->value) {
                tail->value = tail1->value;
                return true;
            }
            return false;
        }
    }

    string getList(int choose){
        string nodos;
        if(choose == 1){
            cout<< tail1;
        }
        else if(choose == 2 ){

        }
        else if(choose == 0){

        }
    }

    Node* search(int value){

    }

    void save(){

    }

    void load(){

    }


    friend ostream &operator<<(ostream &os, TwoLinkedList &other){
        if(other.head1 != nullptr){
            other.head1 = other.head1->next;
            os << other.head1->value<<" ";
        }
        return os;
    }
};


#endif //PC1_2019_TWOLINKEDLIST_H
