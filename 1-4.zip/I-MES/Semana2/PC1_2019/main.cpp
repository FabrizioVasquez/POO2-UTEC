#include <iostream>
#include "TwoLinkedList.h"


int main() {

    TwoLinkedList twoLinkedList;
    twoLinkedList.push_back1(20);
    twoLinkedList.push_back1(30);

    twoLinkedList.getList(1);

    std::cout << "Hello, World!" << std::endl;
    return 0;
}
