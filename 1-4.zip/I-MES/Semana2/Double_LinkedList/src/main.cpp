#include <iostream>
#include "DoubleLinkedList.h"
using namespace std;

int main() {

    DoubleLinkedList doubleLinkedList;
    doubleLinkedList.push_front(25);
    doubleLinkedList.push_front(30);
    doubleLinkedList.push_front(35);
    doubleLinkedList.push_front(40);
    /*doubleLinkedList.push_front(45);
    doubleLinkedList.push_back(100);*/
    doubleLinkedList.insert(2,15);


    cout<<doubleLinkedList;

    //assert(doubleLinkedList.size() == 2 );


    return 0;
}
