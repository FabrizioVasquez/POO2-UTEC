//
// Created by Fabrizio on 4/13/20.
//

#ifndef SRC_DOUBLELINKEDLIST_H
#define SRC_DOUBLELINKEDLIST_H

#include <cstddef>
#include <iostream>
using namespace std;
struct Node{
    int value{};
    Node* next_ = nullptr;
    Node* previous_ = nullptr;
};

class DoubleLinkedList {
private:
    typedef Node* node;
    size_t size_ = 0;
    Node* head_ = nullptr;
    Node* tail_ = nullptr;
public:
    DoubleLinkedList()= default;
    void push_front(int VALUE){

            Node* node = new Node;
            node->next_ = nullptr;
            node->previous_ = nullptr;
            node->value = VALUE;

            if(head_ == nullptr){
                head_ = node;
                tail_ = node;

            }else {
                node->next_ = head_;
                head_->previous_ = node;
                head_ = node;
            }
            size_++;
    }

    void push_back(int VALUE){
        Node *new_node = new Node;
        new_node->next_ = nullptr;
        new_node->previous_ = nullptr;
        new_node->value = VALUE;

        if(tail_ == nullptr){
            head_ = new_node;
            tail_ = new_node;
        }else{
            new_node->previous_ = tail_;
            tail_->next_ = new_node;
            tail_ = new_node;
        }
    }

    void insert(int index, int VALUE){
        auto current = new Node{};
        current = head_;

        auto current_prev = new Node{};
        Node* new_node = new Node{VALUE};
        new_node->value = VALUE;
        current_prev = head_;

        Node * storage_pre_new_node =new Node{};
        Node * storage_next_new_node = new Node{};


        for (int i = 0; i < index; ++i) {
            current = current->next_;
        }
        storage_pre_new_node->next_ = current->previous_;

        for (int j = 0; j < index-2; ++j) {
            current_prev = current_prev->next_;
        }

        storage_next_new_node->next_ = current_prev->next_;


        storage_pre_new_node->next_ = new_node;
        new_node->next_ = storage_pre_new_node->next_;


        new_node->previous_ = storage_next_new_node->next_;



        size_++;

    }

    friend ostream &operator<<(ostream& os, DoubleLinkedList &other){
        while (other.head_ != nullptr) {
            os << other.head_->value << " - ";
            other.head_ = other.head_->next_;
            if(other.head_ == nullptr){
                os<<"nullptr";
                os<<endl;
            }
        }
        return os;
    }


    size_t size(){
        return size_;
    }
};


#endif //SRC_DOUBLELINKEDLIST_H
