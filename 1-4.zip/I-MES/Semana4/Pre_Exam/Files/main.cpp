#include<bits/stdc++.h>

using namespace std;
void uva(){
        map<int,vector<int>> bills;
        size_t first_while=1;
        size_t size_day;
        string line;
        string line_size_bills;
        int size_bills;
        int count_day = 0;
        int bill_value;
        vector<int>all_value_for_line;
        vector<int>val;
        string a;

        ifstream file_read("uva11136.txt");
        if(!file_read.is_open()){
            cout<<"File not Found"<<endl;
        }
        else{
            while(first_while != 0){
                file_read >> size_day;
                file_read.get();
                while(count_day < size_day){
                    getline(file_read,line_size_bills,'\n');
                    istringstream i_(line_size_bills);
                    i_>>line_size_bills;
                    i_ >> a;
                    all_value_for_line.push_back(stoi(line_size_bills));

                    //size_bills = stoi(line_size_bills);
                    auto && key_number = bills[size_bills];
                    istringstream i__(line);
                    i__ >> bill_value;
                    key_number.push_back(bill_value);

                    ++count_day;
                }
                first_while=0;

            }
            file_read.close();
        }


        /*
        for( auto& dolar_bill:bills){
            for( auto& values:dolar_bill.second){
                cout<< values <<" "<<endl;
            }
        }*/



        /*
        for(const auto&item:all_value_for_line){
            bills[item] = vector<int>{1,2,3,4,5};
        }*/


        /*for(auto &i: bills){
            cout<<i.first<<" ";
            for(auto&j : i.second){
                cout<< j <<" ";
            }
            cout<<endl;
        }*/

        for(auto&i : val){
            cout<<i<<" "<<endl;
        }
}


template < typename value_type>
void quickSort(vector<float> &vector_quick,size_t first , size_t last){
    size_t i = 0;  //controla la parte izquierda
    size_t j = 0;  //controla la parte derecha
    size_t central = 0; //posicion central del arreglo
    value_type pivot = 0;
    central = (first+last)/2;
    pivot = vector_quick[central];
    i = first;
    j = last;

    do{
        while(vector_quick[i] < pivot)i++;
        while(vector_quick[j] > pivot)j--;

        if(i <= j ){
            value_type tmp = vector_quick[i];
            vector_quick[i] = vector_quick[j];
            vector_quick[j] = tmp;
            i++;
            j--;
        }
    }while( i < j);

    if (first < j){
        quickSort<value_type>(vector_quick,first,j);
    }
    if (i < last){
        quickSort<value_type>(vector_quick,i,last);
    }

}

// Es necesario que el contenedor debe estar ordenado de forma ascendente

struct Cliente{
    char nombre[30];
    char clave[10];
    int edad;
};

struct Nodo{
    Cliente cliente;
    Nodo *next;
};

void load_client(Cliente &cliente){
    cout<<"Digita tu nombre: "; cin.getline(cliente.nombre,30,'\n');
    cout<<"Digita tu clave: ";cin.getline(cliente.clave,10,'\n');
    cout<<"Digita tu edad: "; cin>>cliente.edad;
    cout<<endl;
}
bool cola_empty( Nodo *head){
    return (head == nullptr)?true: false;
}

void insert_client(Nodo*& head,Nodo *&fin, Cliente cliente){
    Nodo *new_node = new Nodo{};
    new_node->cliente = cliente;
    new_node->next = nullptr;
    if(cola_empty(head)){
        head = new_node;
    }
    else{

    }

}
void program_cola(){
    Nodo*head = nullptr;
    Nodo*tail = nullptr;
    Cliente cliente{};
}

void hanoi(char varInicial, char varCentral, char varFinal, int n){
    if(n == 1 ){    //Base Case
        cout<< "Mover disco "<< n << " desde la varilla "<< varInicial << " a la varilla " << varFinal<<endl;
    }else{          //Recursive Case
        hanoi(varInicial,varFinal,varCentral, n-1);
        cout<< "Move disco "<< n << " desde la varilla "<< varInicial << " a la varilla "<< varFinal<<endl;
        hanoi(varCentral,varFinal,varInicial,n-1);

    }
}


int main() {
    /*
    vector<float>values{20,40,1,2,5,100,80.3,80.1};
    quickSort<float>(values,0,7);

    for(auto&i:values)cout<<i<<" ";*/
    hanoi('A','B','C',3);
    return 0;
}
