#include<iostream>
#include<bits/stdc++.h>
#include<initializer_list>
#include<stack>
#include<string>
using namespace std;

template <typename value_type>
void rules_stack(stack<value_type>stack_implement){
    stack<value_type>stack_temporaly;
    string word_pop;
    while(!stack_implement.empty()){
        value_type value = stack_implement.top();
        if(value == '*'){
            cout<<"Soy un: "<<value <<endl;
            stack_implement.pop();
            value_type letter = stack_implement.top();
            value_type letter2;
            cout<<"Soy una letra de las letras del pop pedido: "<<letter<<endl;
            if(stack_implement.top() == '*'){
                while(stack_implement.top() == '*'){
                    stack_implement.pop();
                    if(stack_implement.top() != '*'){   
                        value_type letter2 = stack_implement.top();
                        cout<<"ESTE ES LEETER2: "<<letter2<<endl;
                        
                    }
                }
            }
            else{
                cout<<stack_implement.top()<<"<----"<<endl;
            }
            
        }
        else{
            stack_temporaly.push(value);
            while(!stack_temporaly.empty()){
                cout<<stack_temporaly.top()<<endl;
                stack_temporaly.pop();
            }
        }
        stack_implement.pop();
    }
}

template < typename value_type>
void printStack(stack<value_type> stack_example){
    while(!stack_example.empty()){
        cout<< stack_example.top();
        stack_example.pop();
    }
}


template< typename value_type>
int binary_search(vector<value_type> vector_search, value_type value_search){
    int left=0, right = vector_search.size(),center;
    bool flag = false;
    while((!flag) && (left <= right)){
        center = (left + right)/2;
        if(vector_search[center] == value_search){
            flag = true;
        }
        else if(value_search < vector_search[center]){
            right = center - 1;
        }
        else{
            left = center + 1;
        }
    }
    return center;
}


int main(){

    /*stack<char> stack1;
    stack1.push('E');stack1.push('A');stack1.push('S');stack1.push('*');stack1.push('Y');stack1.push('*');stack1.push('Q');stack1.push('U');
    stack1.push('E');stack1.push('*');stack1.push('*');stack1.push('*');stack1.push('S');stack1.push('T');
    stack1.push('*');stack1.push('*');stack1.push('*');stack1.push('I');stack1.push('O');stack1.push('*');
    stack1.push('N');stack1.push('*');stack1.push('*');stack1.push('*');
    //printStack(stack1);
    rules_stack<char>(stack1);
    */
   vector<int>vector_example;
   for(size_t i = 0 ; i < 20 ; ++i )
         vector_example.push_back(i);

   int f = binary_search<int>(vector_example,15);
   cout<<f;
    return 0;
}