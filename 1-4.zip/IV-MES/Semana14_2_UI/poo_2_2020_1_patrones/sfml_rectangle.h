//
// Created by Fabrizio on 7/15/20.
//

#ifndef POO_2_2020_1_PATRONES_SFML_RECTANGLE_H
#define POO_2_2020_1_PATRONES_SFML_RECTANGLE_H
#include "abstract_shape.h"
#include <SFML/Graphics.hpp>

class rectangle_t : public shape_t{
private:
    float x;
    float y;
    float width;
    float height;
    sf::RenderWindow* window;
public:
    rectangle_t(float x, float y, float width, float height, sf::RenderWindow* window);
    void draw() const override ;
};


#endif //POO_2_2020_1_PATRONES_SFML_RECTANGLE_H
