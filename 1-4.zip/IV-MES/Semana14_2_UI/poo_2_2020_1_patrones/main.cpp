#include <iostream>
#include <SFML/Graphics.hpp>
#include "abstract_controller.h"
#include "sfml_controller.h"



int main()
{
    abstract_controller_ptr controller = std::make_shared<sfml_controller>(600, 400, "UTEC");
    controller->run();

    /*
    sf::RenderWindow window(sf::VideoMode(200, 200), "SFML works!");
    sf::CircleShape shape(100.f);
    shape.setFillColor(sf::Color::Green);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        window.draw(shape);
        window.display();
    }*/


    return 0;
}