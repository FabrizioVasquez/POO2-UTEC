//
// Created by Fabrizio on 7/15/20.
//

#ifndef POO_2_2020_1_PATRONES_ABSTRACT_SHAPE_H
#define POO_2_2020_1_PATRONES_ABSTRACT_SHAPE_H


#include <memory>

class shape_t {
public:
    virtual void draw() const = 0;
};
#endif //POO_2_2020_1_PATRONES_ABSTRACT_SHAPE_H
