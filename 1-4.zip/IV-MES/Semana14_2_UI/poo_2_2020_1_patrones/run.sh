#!/bin/bash

{
    cmake --build ./build
    ./build/poo_2_2020_1_patrones
} || {
    ./build.sh
    cmake --build ./build
    ./build/poo_2_2020_1_patrones
}
