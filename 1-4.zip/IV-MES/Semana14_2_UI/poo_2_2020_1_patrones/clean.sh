#!/bin/bash

rm -f CMakeCache.txt
rm -f CMakeFiles -rf
rm -f cmake_install.cmake
rm -f Makefile
rm -rf build
