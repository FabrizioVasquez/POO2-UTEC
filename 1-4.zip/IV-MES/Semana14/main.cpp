#include <iostream>
#include <iomanip>
#include "grafo.h"
int main() {

    undirected_graph_t<string> ug;
    ug.add_vertex("A");
    ug.add_vertex("B");
    ug.add_vertex("C");
    ug.add_vertex("D");
    ug.add_vertex("E");
    ug.add_vertex("F");
    ug.add_vertex("G");
    ug.add_vertex("H");
    ug.add_vertex("I");



    ug.add_edge("C","B",4);
    ug.add_edge("C","H",8);
    ug.add_edge("B","C",8);
    ug.add_edge("B","H",11);
    ug.add_edge("C","D",7);
    ug.add_edge("C","I",2);
    ug.add_edge("C","F",4);
    ug.add_edge("D","E",9);
    ug.add_edge("D","F",14);
    ug.add_edge("E","F",10);
    ug.add_edge("F","G",2);
    ug.add_edge("G","H",1);
    ug.add_edge("G","I",6);
    ug.add_edge("H","I",7);


    cout<<endl;
    cout<<"Kruskal"<<endl;
    for(int i = 0; i < ug.kruskal().size(); i++){
        cout<<get<0>(ug.kruskal()[i])<<"  -  "<<get<1>(ug.kruskal()[i])<<endl;
    }


    cout<<"Prim's"<<endl;
    for(int i = 1; i < ug.prim().size();i++){
        cout<<ug.prim()[i]<<"  -  " <<i<<endl;
    }

    cout<<"Dijkstra"<<endl;
    undirected_graph_t<int> g;
    g.add_vertex(0);
    g.add_vertex(1);
    g.add_vertex(2);
    g.add_vertex(3);
    g.add_vertex(4);
    g.add_vertex(5);
    g.add_vertex(6);
    g.add_vertex(7);
    g.add_vertex(8);

    g.add_edge(4, 1, 4);
    g.add_edge(4, 7, 8);
    /*g.add_edge(1, 2, 8);
    g.add_edge(1, 7, 11);
    g.add_edge(2, 3, 7);
    g.add_edge(2, 8, 2);
    g.add_edge(2, 5, 4);
    g.add_edge(3, 4, 9);
    g.add_edge(3, 5, 14);
    g.add_edge(4, 5, 10);
    g.add_edge(5, 6, 2);
    g.add_edge(6, 7, 1);
    g.add_edge(6, 8, 6);
    g.add_edge(7, 8, 7);*/

    for(int i = 0; i < ug.prim().size();i++){
        cout<<i<<"  -  "<<g.dijkstra()[i]<<endl;
    }
    //cout<<get<0>(g.find_pair_vertex_minimun())<<"  -  "<<get<1>(g.find_pair_vertex_minimun())<<"  ->  "<<get<2>(g.find_pair_vertex_minimun());

    cout<<"Floyd"<<endl;
    auto matrix_floyd = ug.floyd(ug.get_matrix());

    //

    return 0;
}
