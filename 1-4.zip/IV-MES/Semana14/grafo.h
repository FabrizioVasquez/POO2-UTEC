//
// Created by Fabrizio on 7/8/20.
//

#ifndef SEMANA14_GRAFO_H
#define SEMANA14_GRAFO_H
#include <vector>
#include <list>
#include<string>
#include <functional>
#include <queue>
#include <tuple>
#include <unordered_map>
#include <algorithm>
#include <numeric>
#include <stack>

using namespace std;

using vertex_t = size_t;
using weight_t = size_t;
using identify_t = string;
using adjacent_t = tuple <vertex_t , weight_t >;                // vertice y peso
using edge_t = tuple <vertex_t, vertex_t, weight_t >;           //el origen, el destino y el peso
//using edge_queue_t = priority_queue<edge_t , vector<edge_t >, function<bool(edge_t, edge_t)>>;
using edge_queue_t = priority_queue<edge_t , vector<edge_t >,greater<>>;
using row_t = vector<weight_t>;
using matrix_t = vector<row_t>;
// para < lo ordena de menor a mayor y > lo ordena de mayor a menor.
auto edge_compare = [](edge_t e1, edge_t e2){return get<2>(e1) < get<2>(e2);};      //lamamos al tercer elemento con <2>
const int INF = 0x3f3f3f3f;

//UNION FIND
class union_find {
    vector<vertex_t> parent;
public:
    explicit union_find(size_t n) : parent(n) {
        iota(begin(parent), end(parent), 0);
    }
    vertex_t find(vertex_t x) {
        return x == parent[x] ? x : (parent[x] = find(parent[x]));
    }

    void join(vertex_t x, vertex_t y) {
        auto x_root = find(x);
        auto y_root = find(y);
        parent[x_root] = y_root;
    }
};


//UNDIRECTED GRAPH
//armamos el grafo
template<typename T>
class undirected_graph_t{
private:
    vector<list<adjacent_t >> adjacent_;
    unordered_map<T ,vertex_t > vertices_;
    edge_queue_t edge_queue_;
    vector<edge_t > edges;

public:
    undirected_graph_t(){}

    size_t vertices(){return adjacent_.size();}
    size_t edge_queue_Size() { return edge_queue_.size();}

    //agregar vertices
    void add_vertex(T identify){
        if(vertices_.find(identify) == end(vertices_)){
            vertices_[identify] = vertices_.size();
            adjacent_.resize(vertices_.size());
        }
    }

    void add_edge(T id1, T id2, weight_t weight){
        edge_queue_.push({vertices_[id1],vertices_[id2],weight});
        adjacent_[vertices_[id1]].push_back({vertices_[id2],weight});
        adjacent_[vertices_[id2]].push_back({vertices_[id1],weight});
        edges.emplace_back(vertices_[id1],vertices_[id2],weight);
    }

    //Getter
    weight_t get_edge(T id1,T id2){
        auto v1 = vertices_[id1];
        auto v2 = vertices_[id2];
        auto it = find_if(begin(adjacent_[v1]),end(adjacent_[v1]),[&v2](adjacent_t a){return get<0>(a) == v2; });
        if(it != end(adjacent_[v1])) // quiere decir que lo ha encontrado
            return get<1>(*it);
        //else
        //    return 0; otra forma como la de abajo ya aquí esta hardcodeado
        else
            return weight_t{};
    }

    T get_identify(vertex_t v1){
        string aux{} ;
        for(auto const &i: vertices_){
            if( v1 == i.second){
                aux = i.first;
            }
        }
        return aux;
    }


    vector<edge_t >kruskal(){
        int weight = 0; //still pending result to use
        vector<edge_t >result;
        sort(edges.begin(),edges.end(),edge_compare);
        union_find uf(vertices_.size());
        for (auto it=edges.begin(); it!=edges.end(); it++) {
            auto u = get<0>(*it);
            auto v = get<1>(*it);

            auto setu = uf.find(u);
            auto setv = uf.find(v);

            if(setu != setv) {
                weight += get<2>(*it);
                uf.join(setu, setv);
                result.emplace_back(get<0>(*it),get<1>(*it),get<2>(*it));
            }
        }
        return result;
    }

    vector<vertex_t> prim(){
        vertex_t first = 0;
        vector<size_t> k(vertices_.size(), INF);
        vector<size_t> parents(vertices_.size(), 0);
        vector<bool> visitados(vertices_.size(), false);
        edge_queue_.push({first,0,0});
        k[first] = 0;
        while (!edge_queue_.empty())
        {
            int u = get<0>(edge_queue_.top());
            edge_queue_.pop();
            visitados[u] = true;

            for (auto x : adjacent_[u])
            {
                int v = get<0>(x);
                int w = get<1>(x);

                if (!visitados[v] && k[v] > w)
                {
                    k[v] = w;
                    edge_queue_.push({get<0>(x),get<1>(x),k[v]});
                    parents[v] = u;
                }
            }
        }

        return parents;
    }

    vector<vertex_t > dijkstra(){
        vertex_t first = 0;
        vector<size_t> distancia(vertices_.size(), INF);
        vector<size_t> parents(vertices_.size(), 0);
        vector<bool> visitados(vertices_.size(), false);
        edge_queue_.push({first,0,0});
        distancia[first] = 0;
        while (!edge_queue_.empty())
        {
            int u = get<0>(edge_queue_.top());
            edge_queue_.pop();
            visitados[u] = true;

            for (auto x : adjacent_[u])
            {
                int v = get<0>(x);
                int w = get<1>(x);
                if (distancia[v] > distancia[u] + w)
                {
                    distancia[v] = distancia[u] + w; //update core
                    edge_queue_.push({get<0>(x),get<1>(x),distancia[v]});
                }
            }
        }
        return distancia;
    }

    // Get matrix
    matrix_t get_matrix() {
        matrix_t result = matrix_t(vertices(), row_t(vertices(), 0));
        for(char i = 0; i < vertices(); ++i)
            for (char j = 0; j < vertices(); ++j)
                result[i][j] = get_edge(identify_t(1, 'A'+i), identify_t(1, 'A'+j));
        return result;
    }

    edge_t find_pair_vertex_minimun(){
        vertex_t minimum_weight = INF;
        vertex_t first = 0, second = 0;
        for(const auto&i: this->edges){
            if(get<2>(i) < minimum_weight) {
                minimum_weight = get<2>(i);
                first = get<0>(i);
                second = get<1>(i);
            }
        }
        return make_tuple(first,second,minimum_weight);
    }

    matrix_t floyd(const matrix_t &graph){
        T distancia [vertices_.size()][vertices_.size()];
        //init
        for(int i = 0;  i < vertices_.size(); ++i){
            for(int j = 0 ; j < vertices_.size();++j){
                distancia[i][j] = graph[i][j];
            }
        }
        for (int k = 0; k < vertices_.size(); k++){
            for (int i = 0; i < vertices_.size(); i++){
                for (int j = 0; j < vertices_.size(); j++){
                    if (distancia[i][k] + distancia[k][j] < distancia[i][j]){
                        distancia[i][j] = distancia[i][k] + distancia[k][j];
                    }
                }
            }
        }

        for (int i = 0; i < vertices_.size(); i++){
            cout<<"\nCosto minimo respecto a nodo: "<<i<<endl;
            for (int j = 0; j < vertices_.size(); j++){
                cout<<graph[i][j]<<"\t";
            }
        }

        return graph;
    }
};


#endif //SEMANA14_GRAFO_H
