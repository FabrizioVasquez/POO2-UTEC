//
// Created by Fabrizio on 6/8/20.
//

#ifndef EJERCICIOS_HEAP_HEAP_H
#define EJERCICIOS_HEAP_HEAP_H


#include<iostream>
#include<algorithm>
#include <vector>
#include<cmath>
#include<map>
#include <cassert>
#include <tgmath.h>
using namespace std;

template < typename T>
class max_heap{
private:
    vector<T>data_;
public:
    //void percolate_down(size_t);
    //void percolate_up(size_t);
    void percolate_up();
    void percolate_down();
    void Swap(T,T);
    static size_t left_child(size_t);
    static size_t right_child(size_t);
    static size_t getParent(size_t);
    ~max_heap(){}
    void push(T);
    T removeMax();
    void removeAsteriscos();
    void removebyValue(T);
    void pop();
    void replace(T,T);
    bool isEmpty();
    void erasebyIndex(size_t);
    void eraseAllbyValue(const T&);
    void print();

    void p1test1();
    void p1test2();
    void p1test3();
    void p2test1();
    void p2test2();
    void p2test3();
    void p3test1();
    void p3test2();
    void p4test1();
};

//
// Created by Fabrizio on 6/8/20.
//

#include "heap.h"

template < typename T> void
max_heap<T>::push(T value){
    data_.push_back(value);
    /*for (int i = 0; i < log2w(data_.size()); ++i) {
        percolate_up(i);
    }*/
    percolate_up();
}

template < typename T > T
max_heap<T>::removeMax(){
    auto charc = data_.erase(data_.begin());
    for (int i = 0; i < data_.size(); i++) {
        if((*charc) == '*'){
            data_.erase(data_.begin()+i);
        }
    }/*
       if((*charc) == '*'){
           charc = data_.erase(data_.begin());
       }*/
    //this->percolate_down(0);
    this->percolate_down();
    return (*charc);
}


template < typename T > void
max_heap<T>::removeAsteriscos(){
    vector<T> word_max;
    for (int i = 0; i < data_.size(); i++) {
        if(data_[i] == '*'){
            auto c = removeMax();
            word_max.push_back(c);
        }
    }
}


template < typename T > void
max_heap<T>::removebyValue(T value){
    for (int i = 0; i < data_.size(); i++) {
        if(data_[i] == '*'){
            data_.erase(data_.begin()+i);
        }
    }
}

template < typename T > void
max_heap<T>::pop(){
    //data_.erase(data_.begin());
    //percolate_down(0);
}

template < typename T > void
max_heap<T>::replace(T fvalue,T svalue){
    vector<int>pos;
    vector<int>sva;
    for (int i = 0; i < 3; i++) {
        sva.push_back(svalue);
    }
    for (size_t i = 0; i < data_.size(); i++) {
        if (data_[i] == fvalue){
            data_[i] = svalue;
            //percolate_down(i);
            this->percolate_down();
        }
    }
}
template < typename T > bool
max_heap<T>::isEmpty(){
    return false;
}


template < typename T > void
max_heap<T>::erasebyIndex(size_t index){
    data_.erase(data_.begin()+index);
    //percolate_down(index);
    percolate_down();
}


template < typename T > void
max_heap<T>::eraseAllbyValue(const T &value){
    for (int i = 0; i < data_.size();++i) {
        if(data_[i] == value ){
            erasebyIndex(i);
        }
    }
}


template < typename T> size_t
max_heap<T>::getParent(size_t index){
    auto i = 0;
    if(index % 2 == 0){
        i = ((index/2)-1);
    }
    else if (index % 2 != 0){
        i = (index/2);
    }
    return i;
}

template<typename T>
void max_heap<T>::percolate_down() {
    int parent = 0;
    while (1) {
        int left = this->left_child(parent);
        int right = this->right_child(parent);
        auto length = data_.size();
        int largest = parent;

        if (left < length && data_[left] > data_[largest])
            largest = left;

        if (right < length && data_[right] > data_[largest])
            largest = right;

        if (largest != parent) {
            swap(largest, parent);
            parent = largest;
        }
        else
            break;
    }
}

/*
template < typename T> void
max_heap<T>::percolate_down(size_t index){

    auto index_left = this->left_child(index);
    auto index_right = this->right_child(index);

    while(data_[index] < data_[index_left] ||  data_[index] < data_[index_right]){
        if(data_[index_left] > data_[index_right] && data_[index_left] > data_[index]){
            swap(data_[index],data_[index_left]);
            percolate_down(index_left);
        }
        else if(data_[index_right] > data_[index_left] && data_[index_right] > data_[index]){
            swap(data_[index],data_[index_right]);
            percolate_down(index_right);
        }

    }
}*/

template<typename T>
void max_heap<T>::percolate_up() {
    size_t index = data_.size() - 1;
    T parent = getParent(index);
    while (data_[index] > data_[parent] && index >=0 && parent >= 0) {
        Swap(index, parent);
        index = parent;
        parent = getParent(index);
    }
}
/*
template < typename T> void
max_heap<T>::percolate_up(size_t index){

    auto index_left = this->left_child(index);
    auto index_right = this->right_child(index);
    auto index_parent =this->getParent(index);

    while(data_[index_left] > data_[index] || data_[index_right] > data_[index]){
        if(data_[index_left] > data_[index_right] && data_[index] < data_[index_left]){
            swap(data_[index],data_[index_left]);
            if(index_parent == -1){
                return;
            }else{
                percolate_up(index_parent);
            }
        }
        else if(data_[index_right] > data_[index_left] && data_[index] < data_[index_right]){
            swap(data_[index],data_[index_right]);
            if(index_parent == -1){
                return;
            }
            else{
                percolate_up(index_parent);
            }
        }
    }
}*/



template < typename T> void
max_heap<T>::print(){
    for(auto&i:data_)cout<<i<<endl;
}

template <typename T> size_t
max_heap<T>::left_child(size_t index){
    return 2*index+1;
}

template < typename T> size_t
max_heap<T>::right_child(size_t index){
    return 2*index+2;
}



template<typename T> void
max_heap<T>::Swap(T v1, T v2) {
    T temp;
    temp = data_[v1];
    data_[v1] = data_[v2];
    data_[v2] = temp;
}


template<typename T> void
max_heap<T>::p1test1() {
    //1. Implementar un método que permita borrar un ítem de un heap dado un subíndice.
    std::cout<<"Pregunta 1 "<<std::endl;
    std::cout<<"Prueba 1";
    std::cout<<"Sacamos el item 0 de {1,3,5,9,10,7,20,30} luego de realizar percolate up por cada push\n";
    std::cout<<endl;
    this->push(1);
    this->push(3);
    this->push(5);
    this->push(9);
    this->push(10);
    this->push(7);
    this->push(20);
    this->push(30);
    this->print();
    this->erasebyIndex(0);
    vector<int>vec{20,10,9,5,3,7,1};
    assert(vec == data_);
    std::cout<<std::endl;
    this->print();

}

template<typename T>void
max_heap<T>::p1test2() {
    std::cout<<"\nPrueba 2 "<<std::endl;
    std::cout<<"Sacamos el item con index 3 de {A,D,F,G} luego de realizar percolate up por cada push y verificando que sea max_heap\n";
    max_heap<char> exe;
    exe.push('A');
    exe.push('D');
    exe.push('F');
    exe.push('G');
    cout<<"\n";
    exe.print();
    cout<<"\n";
    exe.erasebyIndex(3);
    exe.print();
}

template<typename T>void
max_heap<T>::p1test3() {
    std::cout<<"\nPrueba 3 "<<std::endl;
    max_heap<int> pal;
    pal.push(121212);
    pal.push(41234);
    pal.push(123123);
    pal.push(93499);
    pal.push(395239);
    pal.push(39523912);
    std::cout<<"\n";
    pal.print();
    std::cout<<"\n";
    pal.erasebyIndex(4);
    pal.print();

}

template<typename T>void
max_heap<T>::p2test1() {
    //2. Implementar un método que permita borrar todos los elementos iguales a un valor dado.
    std::cout<<"\nPregunta 2"<<std::endl;
    std::cout<<"\nPrueba 1 "<<std::endl;
    max_heap<char> p2;
    p2.push('F');
    p2.push('E');
    p2.push('A');
    p2.push('A');
    p2.push('R');
    p2.push('E');

    std::cout<<"\n";
    p2.print();
    p2.eraseAllbyValue('A');
    std::cout<<"\n";
    p2.print();
}

template<typename T>void
max_heap<T>::p2test2() {
    std::cout<<"\nPrueba 2 "<<std::endl;
    max_heap<int> p2;
    p2.push(1);
    p2.push(1);
    p2.push(3);
    p2.push(2);
    p2.push(2);
    p2.push(2);
    p2.push(3);
    std::cout<<"\n";
    p2.print();
    p2.eraseAllbyValue(2);
    std::cout<<"\n";
    p2.print();
}

template<typename T>void
max_heap<T>::p2test3() {
    std::cout<<"\nPrueba 3 "<<std::endl;
    max_heap<char> p2;
    p2.push('G');
    p2.push('G');
    p2.push('A');
    p2.push('A');
    p2.push('R');
    p2.push('B');
    p2.push('E');

    std::cout<<"\n";
    p2.print();
    p2.eraseAllbyValue('A');
    std::cout<<"\n";
    p2.print();
}

template<typename T>
void max_heap<T>::p3test1() {
    std::cout<<"\nPregunta 3"<<std::endl;
    std::cout<<"\nPrueba 1 "<<std::endl;
    max_heap<char>p3;
    p3.push('F');
    p3.push('A');
    p3.push('T');
    p3.push('A');
    p3.push('Y');
    std::cout<<"\n";

    p3.print();
    p3.replace('A','G');
    std::cout<<"\n";
    p3.print();
}

template<typename T>
void max_heap<T>::p3test2() {
    std::cout<<"\nPrueba 2 "<<std::endl;
    max_heap<int>p3;
    p3.push(1);
    p3.push(5);
    p3.push(6);
    p3.push(6);
    p3.push(9);
    std::cout<<"\n";

    p3.print();
    p3.replace(6,9);
    std::cout<<"\n";
    p3.print();
}

template<typename T>
void max_heap<T>::p4test1() {
    std::cout<<"\nPregunta 4"<<std::endl;
    max_heap<char>max_heap_char;
    max_heap_char.push('P');
    max_heap_char.push('R');
    max_heap_char.push('I');
    max_heap_char.push('O');
    max_heap_char.push('*');
    max_heap_char.push('R');
    max_heap_char.push('*');
    max_heap_char.push('*');
    max_heap_char.push('I');

    max_heap_char.print();
    std::cout<<"\n"<<std::endl;
    max_heap_char.removeAsteriscos();
    max_heap_char.print();

}


#endif //EJERCICIOS_HEAP_HEAP_H
