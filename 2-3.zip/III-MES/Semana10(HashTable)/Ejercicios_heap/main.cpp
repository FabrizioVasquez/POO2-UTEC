#include <iostream>
#include "heap.h"
int main() {

    max_heap<int>max_heap_;
    max_heap_.p1test1();
    max_heap_.p1test2();
    max_heap_.p1test3();
    max_heap_.p2test1();
    max_heap_.p2test2();
    max_heap_.p2test3();
    max_heap_.p3test1();
    max_heap_.p3test2();
    max_heap_.p4test1();


    return 0;
}
