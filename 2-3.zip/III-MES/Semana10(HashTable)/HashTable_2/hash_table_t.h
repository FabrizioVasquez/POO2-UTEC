//
// Created by Fabrizio on 6/11/20.
//

#ifndef HASHTABLE_2_HASH_TABLE_T_H
#define HASHTABLE_2_HASH_TABLE_T_H

#include <iostream>
#include <list>
#include <array>
#include <forward_list>
#include <random>
#include <map>


class hash_table_t {
    using text_t = std::string;
    using hashgroup_t = std::map<int,std::vector<std::string>>;
    using uuint_t = size_t;
    hashgroup_t table;
    int hash_ = 0;

public:
    hash_table_t()= default;
    /*
    long int rand_int(long int first, long int last) {
        std::random_device dev;
        std::mt19937_64 eng(dev());
        std::uniform_int_distribution<long int> gen{ first, last };
        for (int i = 0; i < pow(2,32); ++i) {
            auto f = gen(eng);
            if(f % 2 != 0){
                return f;
            }
        }
    }*/

    auto hash_code_t(const std::string &word){
        int hash = 0;
        for (int i = 0; i < word.size(); ++i) {
            hash = int(word[i]) + (31 * hash);
        }
        return hash;
    }

    int hash_t(const std::string &pal){
        int M = 7;

        if(table.size()/M >= 8)
            M /=2;
        if((table.size()/M) <= 2)
            M++;

        return (((hash_code_t(pal)) & 0x7fffffff) % M);
    }

    /*
    long int generate_odd_A(){
        auto w = 32;
        long int num = rand_int(pow(2,w-1),pow(2,w));
        return num;
    }*/
/*
std::bitset<32> getA(){
    return std::bitset<32>(generate_odd_A());
}*/

/*
std::bitset<32> getK(const std::string &word){
    std::bitset<32> k;
    for (std::size_t i = 0; i < word.size(); ++i)
    {
        k = std::bitset<32>(word.c_str()[i]);
    }

    return k;
}*/

/*
    auto hash_t(std::string pal){
        int w = 32;
        long int aux = pow(2,w);
        long r = ceil(log2(7));
        return (((getK(pal)*generate_odd_A()) % aux) >> (w-r));
    }*/

    /*
    auto size_table_m(std::string pal, std::string pal_search){
        auto x_size = pal.size();
        auto y_size = pal_search.size();
        return ceil((x_size/y_size));
    }
    long int getK(const std::string &word){
        auto size = 0;
        for(char i : word){
            size += int(i);
        }
        return size;
    }*/

    //Average length of list N / M = constant.

    void getValue(const std::string &word){

    }

    void insert(const std::string &word){
        auto hashValue = hash_t(word);
        table[hashValue].emplace_back(word);
    }


    std::string search(const std::string &word , const std::string &word_search){
        auto hash_word_search = hash_t(word);
        std::vector<std::string> vec;
        std::cout<<"INDICE: "<<hash_t(word);

        for(auto it = begin(table); it != end(table); ++it){
            if(it->first == hash_word_search) {
                vec = (*it).second;
            }
        }
        std::string s = std::accumulate(vec.begin(), vec.end(), std::string{});
        auto it = std::search(s.begin(), s.end(),word.begin(),   word.end(),[](char ch1, char ch2) {
            return (ch1) == (ch2);
        });
        if(it != s.end()){
            return " Se encontro la palabra";
        }
        else{
            return " No se encontro la palabra";
        };
    }

    void print(){
        for(auto ii=table.begin(); ii!=table.end(); ++ii){
            std::cout << (*ii).first << ": ";
            std::vector <std::string> inVect = (*ii).second;
            for (unsigned j=0; j<inVect.size(); j++){
                std::cout << inVect[j] << " ";
            }
            std::cout << std::endl;
        }
    }


    void sizeTable(){
        std::cout<<std::endl<<table.size();
    }




};


#endif //HASHTABLE_2_HASH_TABLE_T_H
