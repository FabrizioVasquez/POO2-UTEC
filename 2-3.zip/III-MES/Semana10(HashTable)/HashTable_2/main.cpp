#include <iostream>
#include "hash_table_t.h"
#include <fstream>


int main() {
    /*auto b = generate_odd_A();
    auto c = getK("Hello, World");
    std::string pal = "Hello";
    std::cout<<b;
    std::cout<<std::endl;
    std::cout<<c;
    std::cout << "\nHello, World!" << std::endl;
    std::cout<<hash(pal);*/
    hash_table_t table;
    std::ifstream file("texto.txt");
    std::string words;
    int sum = 0;
    while(file.is_open()){
        while(getline(file,words,' ')) {
            sum += 1;
            table.insert(words);
        }
        file.close();
    }

    //Busqueda de una parte de una palabra en multiples palabras o oraciones;
    table.print();
    std::cout<<std::endl;
    std::cout<<"emocionante - emo"<<std::endl;
    std::cout<<table.search("emocionante","emo");
    std::cout<<std::endl;
    std::cout<<"nombre - nom"<<std::endl;
    std::cout<<table.search("nombre","nom");
    std::cout<<std::endl;
    std::cout<<"Nombre - nom"<<std::endl;
    std::cout<<table.search("Nombre","nom");
    std::cout<<std::endl;
    std::cout<<"Science - cience"<<std::endl;
    std::cout<<table.search("Science","cience");
    std::cout<<std::endl;
    std::cout<<std::endl;

    std::cout<<"Existe un total de: "<<sum <<" palabras";

    /*
    hash_table_t table;
    table.insert("Hola");
    table.insert("Hello");
    table.insert("Fabrizio");
    table.insert("Wolo");
    table.insert("Fallen");
    table.insert("Stranger");
    table.insert("Leonidas");
    */

    //table.print();
    return 0;
}
