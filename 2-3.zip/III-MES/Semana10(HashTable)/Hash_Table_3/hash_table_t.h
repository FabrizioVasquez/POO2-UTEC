//
// Created by Fabrizio on 6/12/20.
//

#ifndef HASH_TABLE_3_HASH_TABLE_T_H
#define HASH_TABLE_3_HASH_TABLE_T_H
#include<iostream>
#include<random>
#include <vector>
#include<map>
class hash_table_t {
private:
    using hashtable_t = std::map<size_t,std::vector<int>>;
    hashtable_t hashTable;

public:
    hash_table_t(){}
    auto hash_t(size_t number){
        return number % 7;
    }
    bool exist(int number_exist){
        bool exist = false;
        auto index_exist = hash_t(number_exist);
        for(const auto&f: hashTable){
            if(f.first == index_exist)
                exist = true;
        }
        return exist;
    }



    void insert(size_t number_insert){
        auto new_hash = hash_t(number_insert);
        if(exist(number_insert)){
                //hashTable[new_hash]item.second.push_back(number_insert);
                hashTable[hash_t(number_insert)].push_back(number_insert);
        }else{
            hashTable[hash_t(number_insert)].push_back(number_insert);
        }
    }


    void serch(const std::string &word , const std::string &word_search){
        size_t hash = 0;
        for (int i = 0; i < word.size(); ++i) {
            hash += int(word[i]) + (31 * hash);
        }
        std::cout<<std::endl<<hash;
    }

    void print(){
        for(std::map<size_t,std::vector<int>>::iterator ii= hashTable.begin(); ii!=hashTable.end(); ++ii){
            std::cout << (*ii).first << ": ";
            std::vector <int> inVect = (*ii).second;
            for (unsigned j=0; j<inVect.size(); j++){
                std::cout << inVect[j] << " ";
            }
            std::cout << std::endl;
        }

        /*
        for(auto&i:hashTable){
            std::cout<<"INDEX: "<<i.first<<std::endl;
        }*/
        /*
        for(auto it1 = hashTable.begin(); it1 != hashTable.end(); ++it1){
            for(auto it2 = it1->second.begin(); it2 != it1->second.end(); ++it2){
                std::cout<< (it1->first)<<" -> "<< *it2<<std::endl;
            }
            std::cout<<std::endl;
        }*/

    }


};


#endif //HASH_TABLE_3_HASH_TABLE_T_H
