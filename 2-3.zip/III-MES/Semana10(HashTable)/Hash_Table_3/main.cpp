#include <iostream>
#include "hash_table_t.h"
int main() {

    hash_table_t table;
    table.insert(412); //mod 6
    table.insert(123); //mod 4
    table.insert(413); //mod 0
    table.insert(111); //mode 6

    table.print();



    std::cout << "Hello, World!" << std::endl;
    return 0;
}
