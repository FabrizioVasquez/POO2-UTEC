#include <iostream>
#include "HashTable.h"
#include "Utils.h"



int main() {

    /*HashTable hashTable;
    hashTable.insert_("LEO");
    hashTable.insert_("FAB");
    hashTable.insert_("BAF");
    std::cout<<hashTable.search_("");*/
    //std::cout<<hashTable.prehash("LEO");
    //hashTable.print();
    /*auto b = generate_prime();
    std::cout<< b;*/
    //std::string string = "Hello World";
    //size_t g = getK(string);
    //std::cout<<g;

    return 0;
}
