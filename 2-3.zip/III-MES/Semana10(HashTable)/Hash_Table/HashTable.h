//
// Created by Fabrizio on 6/10/20.
//

#ifndef HASH_TABLE_HASHTABLE_H
#define HASH_TABLE_HASHTABLE_H
#include<iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>

class HashTable {
private:
    using uuint_t = size_t;
    using text_t = std::string;
    using hashgroup_t = std::map<uuint_t , std::vector <std::string>>;
    hashgroup_t hashGroup;
    text_t text;

public:
    HashTable() = default;
    void        insert_(const text_t &item_){
        text = item_;
        hashGroup[prehash(item_)].push_back(item_);

    }
    void        delete_(const text_t &item){

    }
    bool       search_(const text_t &pal){
        bool found = false;
        uuint_t valpre = prehash(pal);
        for(const auto&h : hashGroup ){
            if(h.first == valpre){
                for(int i{}, j=h.second.size() ; i< h.second.size(); ++i , j--){
                    found = pal[i] == h.second[i][i];
                }
            }
        }
        return found;
    }

    uuint_t prehash(const text_t &item){
        uuint_t sum = 0;
        uuint_t mod = (item.size());
        for(int i{} ; i < item.size();++i){
            auto b = (uuint_t)item[i];
            sum += b;
        }
        if(mod == 2 || mod == 5 ){
            mod++;
        }
        return sum % mod ;
    }

    void           print(){
        for(const auto&h : hashGroup){
            for (int i = 0; i < h.second.size(); ++i) {
                std::cout<< h.second[i]<<" ";
                std::cout<<h.first<<std::endl;

            }
        }
    }

};


#endif //HASH_TABLE_HASHTABLE_H
