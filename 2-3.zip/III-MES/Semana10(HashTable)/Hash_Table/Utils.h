//
// Created by Fabrizio on 6/10/20.
//

#ifndef HASH_TABLE_UTILS_H
#define HASH_TABLE_UTILS_H
#include <random>
#include <bitset>

template <typename integer_t, typename = std::enable_if_t<std::is_integral<integer_t>::value >>
integer_t rand_int(integer_t first, integer_t last) {
    std::random_device dev;
    std::mt19937_64 eng(dev());
    std::uniform_int_distribution<integer_t> gen{ first, last };
    return gen(eng);
}
bool isPrime(int number)
{
    for (int a = 2; a < number; a++) {
        if (number % a == 0) {
            return false;
        }
    }
    return true;
}


auto generate_prime(){
    int num =rand_int(1,100);
    if(isPrime(num))
        return num;
}


size_t getK(const std::string &word){
    size_t count_k {};
    static const int TAM = word.size();
    std::bitset<8> k_word;
    for (std::size_t i = 0; i < word.size(); ++i)
    {
        k_word = std::bitset<8>(word.c_str()[i]);
    }
    std::cout<<k_word;
    return count_k;
}

// w == 8 ;

#endif //HASH_TABLE_UTILS_H
