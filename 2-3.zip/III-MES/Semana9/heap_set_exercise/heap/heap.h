#include<iostream>
#include<algorithm>
#include <vector>
#include<cmath>
#include<map>
using namespace std;

template < typename T>
class max_heap{
    private:
        vector<T>data_;
    public:
        void percolate_down(size_t);
        void percolate_up(size_t);
        static size_t left_child(size_t);
        static size_t right_child(size_t);
        static size_t getParent(size_t);
        
        void push(T);
        T removeMax();
        void removeAsteriscos();
        void pop();
        void replace(T,T);
        bool isEmpty();
        void erasebyIndex(size_t);
        void eraseAllbyValue(T);
        void print();
};


template < typename T> void 
max_heap<T>::push(T value){
    data_.push_back(value);
    if(data_.size()-1 == 0){
    }
    else if(data_.size() != 0){
        for(int i = 0 ; i < log(data_.size());++i){
            percolate_up(i);
        }
    }
}

template < typename T > T
max_heap<T>::removeMax(){
    cout<<"\n------------"<<endl;
    auto charc = data_.erase(data_.begin()-1);
    cout<<endl;
    for(auto&i:data_)cout<<i<<" ";
    for (int i = 0; i < data_.size(); i++) {
        if((*charc) == '*'){
            data_.erase(data_.begin()+i);
        } 
    }/*
    if((*charc) == '*'){
        charc = data_.erase(data_.begin());
    }*/
    cout<<"\nANOTHER CAMP\n";
    this->percolate_down(0);
    for(auto&i:data_)cout<<i<<" ";
    return (*charc);
}

template < typename T > void
max_heap<T>::removeAsteriscos(){
    vector<T> word_max;
    for (int i = 0; i < data_.size(); i++) {
        if(data_[i] == '*'){
            auto c = removeMax();
            word_max.push_back(c);
        } 
    }
    cout<<endl;
    for(const auto&i:word_max)cout<<i<<"-";
}

template < typename T > void 
max_heap<T>::pop(){
    //data_.erase(data_.begin());
    //percolate_down(0);
}

template < typename T > void
max_heap<T>::replace(T fvalue,T svalue){
    vector<int>pos;
    vector<int>sva;
    for (int i = 0; i < 3; i++) {
        sva.push_back(svalue);
    }
    for (size_t i = 0; i < data_.size(); i++) {
        if (data_[i] == fvalue){
            data_[i] = svalue;
            percolate_down(i);
        }
    } 
}
template < typename T > bool
max_heap<T>::isEmpty(){
    return false;
} 

template < typename T > void 
max_heap<T>::erasebyIndex(size_t index){
    data_.erase(data_.begin()+index);
    percolate_down(index);
    
}

template < typename T > void
max_heap<T>::eraseAllbyValue(T value){
    vector<size_t> pos;
    for (int i = 0; i < data_.size();++i) {
        if(data_[i] == value){
            erasebyIndex(i);
        }        
    }
}


template < typename T> size_t
max_heap<T>::getParent(size_t index){
    auto i = 0;
    if(index % 2 == 0){
        i = ((index/2)-1);
    }
    else if (index % 2 != 0){
        i = (index/2);
    }
    return i;
}

template < typename T> void
max_heap<T>::percolate_down(size_t index){
    
    auto index_left = this->left_child(index);
    auto index_right = this->right_child(index);
     
    while(data_[index] < data_[index_left] ||  data_[index] < data_[index_right]){
        if(data_[index_left] > data_[index_right] && data_[index_left] > data_[index]){
            swap(data_[index],data_[index_left]);
            percolate_down(index_left);
        }
        else if(data_[index_right] > data_[index_left] && data_[index_right] > data_[index]){
            swap(data_[index],data_[index_right]);
            percolate_down(index_right);
        }    
    }
}

template < typename T> void
max_heap<T>::percolate_up(size_t index){

    auto index_left = this->left_child(index);
    auto index_right = this->right_child(index);
    auto index_parent =this->getParent(index);
    
    while(data_[index_left] >= data_[index] || data_[index_right] >= data_[index]){
    if(data_[index_left] >= data_[index_right] && data_[index] <= data_[index_left]){
        swap(data_[index],data_[index_left]);
        if(index_parent == -1){
            return;
        }else{
            percolate_up(index_parent);
        }
    }
    else if(data_[index_right] >= data_[index_left] && data_[index] <= data_[index_right]){
        swap(data_[index],data_[index_right]);
        if(index_parent == -1){
            return;
        }
        else{
            percolate_up(index_parent);
        }
    }
   }
}

template < typename T> void
max_heap<T>::print(){
    for(auto&i:data_)cout<<i<<endl;
}

template <typename T> size_t
max_heap<T>::left_child(size_t index){
    return 2*index+1;
}

template < typename T> size_t
max_heap<T>::right_child(size_t index){
    return 2*index+2;
}
