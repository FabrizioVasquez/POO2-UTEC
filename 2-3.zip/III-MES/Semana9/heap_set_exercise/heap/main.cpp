#include<iostream>
#include"heap.h" 
using namespace std;

int main(){
    /*max_heap<int> max_heap;
    max_heap.push(3);
    max_heap.push(3);
    max_heap.push(3);
    max_heap.push(6);
    max_heap.push(8);
    max_heap.push(9);
    max_heap.push(10);
    max_heap.push(20);
    max_heap.push(18);*/
    //auto lc = max_heap.right_child(1); 
    //cout<<lc<<endl;
    max_heap<char>max_heap_char;
    max_heap_char.push('P');
    max_heap_char.push('R');
    max_heap_char.push('I');
    max_heap_char.push('O');
    max_heap_char.push('*');
    max_heap_char.push('R');
    max_heap_char.push('*');
    max_heap_char.push('*');
    max_heap_char.push('I');
    max_heap_char.push('*');
    max_heap_char.push('T');
    max_heap_char.push('*');
    max_heap_char.push('Y');
    max_heap_char.push('*');
    max_heap_char.push('*');
    max_heap_char.push('*');
    max_heap_char.push('Q');
    max_heap_char.push('U');
    max_heap_char.push('E');
    max_heap_char.print();
    cout<<endl;
    /*for (int i = 4; i >= 0; i--) {
        max_heap_char.percolate_up(i); 
    }*/
    max_heap_char.print();
    //max_heap_char.print();
    //cout<<"Remover"<<endl;
    max_heap_char.removeAsteriscos();
    //max_heap.erasebyIndex(0);
    //max_heap.eraseAllbyValue(3);
    //max_heap.replace(10,1);
    cout<<endl;
    cout<<endl;
    //max_heap.print();
    //max_heap_char.print();
    return 0;
}
