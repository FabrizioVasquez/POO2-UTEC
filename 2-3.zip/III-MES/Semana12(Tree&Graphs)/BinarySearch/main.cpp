#include <iostream>
#include "binary_search.h"
int main() {

    /*binary_tree_t<int> t1(2);
    t1.insert(99);
    t1.insert(23);
    t1.insert(99);
    t1.insert(91);
    t1.insert(76);*/

    binary_tree_t<int> t2(50);
    t2.insert(70);
    t2.insert(30);
    t2.insert(20);
    t2.insert(40);
    t2.insert(60);
    t2.insert(80);
    /*binary_tree_t<int> t2(1);
    t2.insert(2);
    t2.insert(3);
    t2.insert(5);
    t2.insert(4);
    t2.insert(6);
    t2.insert(7);*/
    //cout<< t1.count_leafs()<<endl;
    //cout<< t1.count_nodehalf();
    cout<<t2.findDiameter(t2.get_root());

    /*t1.post_order();
    cout<<t1.minimum()<<endl;
    cout<<t1.maximum()<<endl;
    for(const auto&i:t1.in_order())cout<<i<<" ";
    cout<<t1.count_leafs();*/
    return 0;
}
