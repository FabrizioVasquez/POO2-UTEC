#include <iostream>
#include "tree.h"
using namespace std;
int main() {

    tree t1{1};
    tree::insert_left(t1.get_root(), 8);
    tree::insert_left(t1.get_root(), 4);
    auto curr = tree::insert_left(t1.get_root(), 2);
    tree::insert_right(curr, 5);
    curr = tree::insert_right(t1.get_root(), 3);
    tree::insert_right(curr, 7);
    curr = tree::insert_left(curr, 6);
    tree::insert_right(curr, 10);
    tree::insert_left(curr, 9);

    auto i_pre = t1.in_order();
    auto d_pre = t1.pre_order();

    for (const auto item: i_pre)
        cout << item << " ";
    cout << endl;

    for (const auto item: d_pre)
        cout << item << " ";
    cout << endl;

    return 0;
}
