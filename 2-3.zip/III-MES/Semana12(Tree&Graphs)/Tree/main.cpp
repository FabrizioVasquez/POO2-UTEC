#include <iostream>
#include "tree.h"

int main() {
    tree t1{1};
    tree::insert_left(t1.get_root(), 8);
    tree::insert_left(t1.get_root(), 4);
    auto curr = tree::insert_left(t1.get_root(), 2);
    tree::insert_right(curr, 5);
    curr = tree::insert_right(t1.get_root(), 3);
    tree::insert_right(curr, 7);
    curr = tree::insert_left(curr, 6);
    tree::insert_right(curr, 10);
    tree::insert_left(curr, 9);

    auto d_pre = t1.pre_order();

    for (const auto item: d_pre)
        cout << item << " ";
    cout << endl;

    auto d_lev = t1.level_order();
    for (const auto item: d_lev)
        cout << item << " ";
    cout << endl;

    return 0;
}
