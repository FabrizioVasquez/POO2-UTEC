//
// Created by Fabrizio on 6/23/20.
//

#ifndef TREE_TREE_H
#define TREE_TREE_H
#include <iostream>
#include <memory>
#include <vector>
#include <queue>
using namespace std;


//declaracion forward de la clase para usarla
struct node;
using T = int8_t;
using node_t = std::shared_ptr<node>;

struct node{
    T data;
    node_t left;
    node_t right;
    //node* left
    //node* right
    //Usar shared_ptr es lo mismo que usar con la notacion de arriba pero le va a dar ventajas  como no tenemos la necesidad de liberarlos
    node()=default;
    node(T data): data{data},left{nullptr},right{nullptr}{}
};

class tree{
private:
    std::shared_ptr<node>root;
public:

    tree(T data): root{std::make_shared<node>(data)}{}
    //usamos funciones staticas porque tenemos que especificar a partir de que valor queremos adicionar valores
    //STATIC es para que funcione mas alla de la clase. Es un metodo de clase. Lo declaramos como tree::insert_left cuando usamos static
    //Los metodos estáticos no tiene acceso a los atributos

    node_t get_root(){return root;}
    static node_t insert_left(node_t start, T data){
        if(!start->left){
            start->left = std::make_shared<node>(data);
        }
        else{
            auto temp =  std::make_shared<node>(data);
            temp->left = start->left;
            start->left = temp;
        }
        return start->left;
    }

    static node_t insert_right  (node_t start, T data){
        if(!start->right){
            start->right = std::make_shared<node>(data);
        }
        else{
            auto temp =  std::make_shared<node>(data);
            temp->right = start->right;
            start->right = temp;
        }
        return start->right;
    }

    void pre_order_rec(node_t start, std::vector<T>& result) {
        if(!start) return;
        result.push_back(start->data);
        pre_order_rec(start->left, result);
        pre_order_rec(start->right, result);
    }

    std::vector<T> pre_order() {
        std::vector<T> result;
        pre_order_rec(root, result);
        return result;
    }

    std::vector<T> level_order(){
        vector<T> result;
        queue<node_t> q;
        q.push(root);
        while(!q.empty()){
            auto node = q.front();
            q.pop();
            result.push_back(node->data);
            if(node->left) q.push(node->left);
            if(node->right) q.push(node->right);
        }
        return result;
    }

};


#endif //TREE_TREE_H

