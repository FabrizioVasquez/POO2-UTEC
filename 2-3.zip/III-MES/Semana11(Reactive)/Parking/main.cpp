#include <iostream>
#include "parking.h"

int main() {
    user_t user_1("Fabrizio");
    user_t user_2("Jairo");
    user_t user_3("Andrea");
    user_t user_4("Ana");
    user_t user_5("Ernesto");
    user_t user_6("Gerardo");

    parking_t parking(5);
    parking.check_in(&user_1);
    parking.check_in(&user_2);
    parking.check_in(&user_3);
    parking.check_in(&user_4);
    parking.check_in(&user_5);
    auto result = parking.check_in(&user_6);
    if(result.second == false)
        parking.attach(&user_6);
    parking.check_out(&user_1);
    parking.check_in(&user_6);
    parking.detach(&user_6);

    return 0;
}
