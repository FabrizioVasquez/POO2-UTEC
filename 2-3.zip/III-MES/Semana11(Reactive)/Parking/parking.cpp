//
// Created by Fabrizio on 6/10/20.
//

#include "parking.h"

void observable_t::attach(observer_t *observer){
    observers.push_back(observer);
}

void observable_t::detach(observer_t *observer){
    auto it = std::find(begin(observers),end(observers),observer); // busca dentro de los observers
    if(it != end(observers)){
        observers.erase(it);
    }
}

void observable_t::notify(){
    for(const auto& o: observers) o->update();
}



void user_t::update() {
    std::cout<< name << " was notify of a free lot ";
}


std::pair<int,bool> parking_t::check_in(user_t *user) {
    auto it = std::find_if(begin(lots), end(lots), [](user_t *user) { return user == nullptr; });
    if (it != end(lots)) {
        *it = user;
        auto index = std::distance(it, begin(lots));//devuelve el indice donde colocare en el vector
        //verificar si hay lots vacios
        it = std::find_if(begin(lots), end(lots), [](user_t *user) { return user == nullptr; });
        if (it != end(lots)) {
            notify();
            return {index, true};
        }
        return {-1, false};
    }
}

bool parking_t::check_out(user_t*user){
    auto it = find(begin(lots),end(lots),user);
    if(it != end(lots)){
        *it = nullptr;
        notify();
        return true;
    }
    return false;
}