//
// Created by Fabrizio on 6/10/20.
//

#ifndef EJERCICIO_1_PARKING_H
#define EJERCICIO_1_PARKING_H

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

//clase abstracta
class observer_t{
public:
    virtual void update()=0;
};

//admin del parking.h
class observable_t{
    //Hacemos con punteros porque usamos polimorfismo. Es requisito usar punteros al usar polimorfismo
    std::vector<observer_t*> observers{}; //con esto inicializa los punteros con nullptr
public:
    void attach(observer_t* observer);  //registra
    void detach(observer_t* observer);
    void notify();

};

class user_t : public observer_t{
    std::string name;
public:
    user_t(const std::string &name_):name(name_){};
    void update() override ;
};


class parking_t: public observable_t{
    std::vector<user_t*> lots;

public:
    parking_t(const int& capacity): lots(capacity){}
    std::pair<int, bool> check_in(user_t* user);
    bool check_out(user_t* user);
};


#endif //EJERCICIO_1_PARKING_H
