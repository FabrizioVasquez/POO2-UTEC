//
// Created by Fabrizio on 6/19/20.
//

#ifndef PC_TEMPLATES_HASH_FUNCTIONS_H
#define PC_TEMPLATES_HASH_FUNCTIONS_H
#include <iostream>
#include <array>
#include <map>
#include <unordered_set>
#include <set>
#include <deque>
#include <queue>

using namespace std;

//max heap
class point_t{
public:
    int x_;
    int y_;
public:
    point_t(){};
    point_t(int x , int y){
        x_ = x;
        y_ = y;
    }
    int getX()const {return x_;}
    int getY()const {return y_;}
};

class comparator_t{
public:
    point_t aux;
    int operator()(const point_t &p1, const point_t &p2)
    {
        return (sqrt(pow(p1.getX()-0,2)+pow((p1.getY()-0),2)) > sqrt(pow(p2.getX()-0,2)+pow((p2.getY()-0),2)) );
    }
};




//HASH
template < typename T = int >
auto array_eliminate_duplicated(std::array<T,6> array_)
{
    set<T> aux;
    aux.insert(array_.begin(),array_.end());
    return aux;
}

bool same_vector(const vector<int> &v1, const vector<int> &v2){
    set<int>v1o,v2o;
    v1o.insert(v1.begin(),v1.end());
    v2o.insert(begin(v2),end(v2));
    return (v1o == v2o)?true:false;
}

void vector_pair_search_invert(vector<pair<int,int>> &vector_pairs){
    auto j = (vector_pairs.size()-1) ;
    auto i = 0;
    while(i < (vector_pairs.size()) && j > 0) {
        if (vector_pairs[i].first == vector_pairs[j].second && vector_pairs[i].second == vector_pairs[j].first) {
            cout << vector_pairs[i].first << "-" << vector_pairs[i].second << endl;
            j--;
        }
        else{
            --j;
            if(j == 0){
                j = (vector_pairs.size()-1);
                ++i;
            }
            if(vector_pairs[i].first == vector_pairs[j].second && vector_pairs[i].second == vector_pairs[j].first){
                cout << vector_pairs[i].first << "-" << vector_pairs[i].second << endl;
                --j;
                if(j == 0){
                    j = (vector_pairs.size()-1);
                    ++i;
                }
            }
        }
    }
}

class Node {
public:
    int data;
    Node* next;
};

void push(Node** head_ref, int new_data)
{
    /* allocate node */
    Node* new_node = new Node();

    /* put in the data */
    new_node->data = new_data;

    /* link the old list off the new node */
    new_node->next = (*head_ref);

    /* move the head to point to the new node */
    (*head_ref) = new_node;
}

int detectLoop(Node* list)
{
    Node *slow_p = list, *fast_p = list;

    while (slow_p && fast_p && fast_p->next) {
        slow_p = slow_p->next;
        fast_p = fast_p->next->next;
        if (slow_p == fast_p) {
            return 1;
        }
    }
    return 0;
}


void search_triple(array<int,10> arr_)
{
    map<int,int> map_;
    vector<int>triples;
    for(const auto&i:arr_) map_[i]++;

    for(auto&i:map_){
        if(i.second == 3){
            triples.push_back(i.first);
        }
    }

    for (int j = 0; j < arr_.size(); ++j) {
        if(triples[0] == arr_[j]){
            cout<<j;
        }
    }
    /*for(const auto&i: map_)
        cout<<i.first<<" -> "<<i.second<<endl;*/

}


void find_sets(int k){
    set<int> f{2,3,1};
    set<int> v{2,5,4};
    for(const auto &item:f){
        for(const auto &item2:v){
           if(item + item2 == k){
               cout<<item << " "<<item2<<endl;
           }
        }
    }
}


void eliminate_word(const string &word,const string eliminate_word){
    vector<char> su;
    vector<char> su_word;
    for(auto &i:eliminate_word)su.push_back(i);
    for(auto &i:word)su_word.push_back(i);
    for(auto it = begin(word); it != end(word); it++){
        for(auto it2 = begin(eliminate_word) ; it2 != end(eliminate_word); it2++){
            if(*it == *it2){
                su.erase(it,it+1);
            }
        }
    }

    for(auto&i:su)cout<<i;


    /*for(const auto i:word){
        cout<<i;
    }*/
}


class hash_table_t{
private:
    vector<list<pair<string,int>>> words;
public:

};



#endif //PC_TEMPLATES_HASH_FUNCTIONS_H
