//
// Created by Fabrizio on 6/16/20.
//

#ifndef PC_TEMPLATES_TEMPLATE_H
#define PC_TEMPLATES_TEMPLATE_H
#include <vector>
#include <cstddef>
#include <iostream>
#include <unordered_set>

template <typename Container, template <typename...> class Result=std::vector>
Result<Container> split_range(Container cnt, size_t n) {
    Result<Container> result(n);
    auto range = cnt.size() / n;
    auto start = begin(cnt);
    for (auto& item : result) {
        auto stop = next(start, range);
        copy(start, stop, back_inserter(item));
        start = stop;
    }
    copy(start, end(cnt), back_inserter(result.back()));
    return result;
}

template <typename Container>
Container suma_range(Container cnt1, Container cnt2) {
    auto& max = cnt1.size() > cnt2.size() ? cnt1 : cnt2;
    auto& min = cnt1.size() < cnt2.size() ? cnt1 : cnt2;
    if (min.empty()) return max;
    auto current = begin(min);
    for (auto& item : max) {
        item += *(current++);
        current = current != end(min) ? current : begin(min);
    }
    return max;
}

template <typename Container, typename FilterType, typename ComparerType>
Container delete_range(Container cnt, FilterType value, ComparerType comparer) {
    auto current = begin(cnt);
    for (const auto& item : cnt)
        if (comparer(item, value))
            *(current++) = item;
    cnt.erase(current, end(cnt));
    return cnt;
}

template <typename T, template <typename...> class Container>
Container<T> delete_range(Container<T> cnt, const T& value) {
    return delete_range(cnt, value,
                        [](const T& item, const T& value) {
                            return item != value;
                        });
}

template <typename T, template <typename...> class Container>
Container<T> delete_range(Container<T> cnt, const std::initializer_list<T>& lst) {
    return delete_range(cnt, lst,[](const T& item, const std::initializer_list<T>& lst) {
                            return find(begin(lst), end(lst), item) == end(lst);
                        });
}

template <typename T, template <typename...> class Container>
Container<T> delete_duplicated(Container<T> cnt) {
    std::unordered_set<T> st;
    auto current = begin(cnt);
    for (const auto& item : cnt) {
        if (st.find(item) == end(st))
            *(current++) = item;
        st.emplace(item);
    }
    cnt.erase(current, end(cnt));
    return cnt;
}


#endif //PC_TEMPLATES_TEMPLATE_H
