#include <iostream>
#include "template.h"
#include <list>
#include"hash_functions.h"

using namespace std;
int main() {

    priority_queue<point_t, vector<point_t>, comparator_t> pq;
    pq.push(point_t(10,2));
    pq.push(point_t(2,1));
    pq.push(point_t(1,5));
    pq.push(point_t(0,1));
    pq.push(point_t(0,0));
    int i = 0;
    while (!pq.empty() && i < 4)
    {
        point_t p = pq.top();
        cout << "(" << p.getX() << ", " << p.getY() << ")";
        cout << endl;
        pq.pop();
        ++i;
    }

    return 0;
}
