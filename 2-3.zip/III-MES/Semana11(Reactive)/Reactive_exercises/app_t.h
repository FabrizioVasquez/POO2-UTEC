//
// Created by Fabrizio on 6/13/20.
//

#ifndef REACTIVE_EXERCISES_APP_T_H
#define REACTIVE_EXERCISES_APP_T_H

#include <iostream>
#include <utility>
#include <vector>
#include <algorithm>
using namespace std;

class component_t;
class event_t;
using on_click_t = std::function<void(event_t)>;
using on_mouse_move_t = std::function<void(event_t)>;

class app_t {
private:
    std::vector<component_t*> components;
    void notify(const char& action);

public:
    void run();
    void add(component_t*);
    void remove(component_t*);

};




class component_t{
protected:
    on_click_t click_event;
    on_click_t mouse_move;
public:
    void on_click(on_click_t callable);
    void on_mouse (on_click_t callable);
    virtual void draw(){}
};


struct event_t{
    int x;
    int y;
    event_t(const int &x_, const int &y_){
        x = x_;
        y = y_;
    }
    void setPosition(const int&_x,const int&_y){
        x = _x;
        y = _y;
    }
    int get_x();
    int get_y();

};


class circle_t : public component_t{
private:
    int x{};
    int y{};
    size_t width{};
    size_t height{};
    int getX(){return x;}
    int getY(){return y;}
public:
    void on_mouse_move(on_mouse_move_t callable) {
        click_event = std::move(callable);
    }
    circle_t(int,int);
    void draw() override;
};

class rectangle_t : public component_t{
    int x{};
    int y{};
    size_t width{};
    size_t height{};
    int getX(){return x;}
    int getY(){return y;}
public:
    rectangle_t(int,int);
    void draw() override;
};



#endif //REACTIVE_EXERCISES_APP_T_H
