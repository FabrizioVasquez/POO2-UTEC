//
// Created by Fabrizio on 6/13/20.
//
#include "app_t.h"

#include <utility>

void app_t::notify(const char& action) {
     if(action == 'C') {
        for(auto c: components) {
            c->on_click([](event_t e){e.setPosition(50,60);});
            c->draw();
        }
    }
}

void app_t::run() {
    while (true) {
        int acton;
        char action;
        cout << "Ingrese C , para presentar el historial de pantalla: ";

        cin >> action;
        notify((toupper(action)));
        cout << "Escriba 0 para salir o 1 para eliminar el ultimo elemento del historial :"; cin>>acton;
        switch (acton) {
            case 1: components.pop_back();
                    if(components.empty())cout<<"No hay elementos"<<endl;
                    break;
            default :break;
        }
        if(acton == 0)break;
    }
}



void app_t::add(component_t *component) {
    components.emplace_back(component);
}

void app_t::remove(component_t *component){
    auto it = std::find(begin(components),end(components),component);
    if(it != end(components)){
        components.erase(it);
    }
}

void component_t::on_click(on_click_t callable) {
    click_event = std::move(callable);
}

void component_t::on_mouse(on_click_t callable) {
    mouse_move = std::move(callable);
}


int event_t::get_x() {
    return x;
}

int event_t::get_y(){
    return y;
}

circle_t::circle_t(int x_, int y_) {
    x = x_;
    y = y_;
}

void circle_t::draw() {
    cout<<__PRETTY_FUNCTION__ <<endl;
    cout<<"Hola mandando mensaje desde la clase circle_t draw y su informacion del circulo es la siguiente:"<<endl;
    cout<<"El vertice es el siguiente: "<<getX()<<endl;
    cout<<"El radio es el siguinete: "<<getY()<<endl;
}


rectangle_t::rectangle_t(int x_ ,int y_) {
    x = x_;
    y = y_;
}

void rectangle_t::draw() {
    cout<<__PRETTY_FUNCTION__ <<endl;
    cout<<"Hola mandando mensaje desde la clase rectangle_t draw y su informacion del rectangulo es la siguiente:"<<endl;
    cout<<"El largo es el siguiente: "<<getX()<<endl;
    cout<<"El ancho es el siguinete: "<<getY()<<endl;
}



