#include <iostream>
#include "app_t.h"
using namespace std;
//Reactive Exercises
int main() {


    app_t app ;
    circle_t circle1(0,0);
    circle_t circle2(10,2);
    rectangle_t rectangle1(10,20);
    rectangle_t rectangle2(20,60);
    rectangle_t rectangle3(100,200);
    //circle_t *circle2;
    //circle_t *circle3;

    app.add(&circle1);
    app.add(&rectangle1);
    app.add(&circle2);
    app.add(&rectangle2);
    app.add(&rectangle3);

    /*circle1.on_click([](event_t e){
        cout<<"Hola"<<e.x<<endl;
    });*/

    circle1.on_click([](event_t e){
        e.setPosition(e.get_x(), e.get_y());
    });
    app.run();


    return 0;
}
