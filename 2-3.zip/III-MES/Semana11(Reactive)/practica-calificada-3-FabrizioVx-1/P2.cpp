//
// Created by rudri on 6/19/2020.
//

#include "P2.h"

class point_t{
public:
    float r;
    float sw;
};


void P2() {

}
