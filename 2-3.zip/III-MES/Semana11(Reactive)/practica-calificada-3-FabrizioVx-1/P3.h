//
// PREGUNTA #3
//

#ifndef P3_H
#define P3_H
#include<iostream>
#include<set>
#include<random>
#include <map>
using namespace std;
void P3();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//

class hash_table_t {
    using text_t = std::string;
    using hashgroup_t = std::map<int,std::vector<std::string>>;
    using uuint_t = size_t;
    hashgroup_t table;
    int hash_ = 0;

public:
    hash_table_t()= default;

    long int rand_int(long int first, long int last) {
        std::random_device dev;
        std::mt19937_64 eng(dev());
        std::uniform_int_distribution<long int> gen{ first, last };
        for (int i = 0; i < pow(2,32); ++i) {
            auto f = gen(eng);
            if(f % 2 != 0){
                return f;
            }
        }
    }

    auto hash_code_t(const std::string &word){
        int hash = 0;
        for (int i = 0; i < word.size(); ++i) {
            hash = int(word[i]) + (31 * hash);
        }
        return hash;
    }



    long int generate_odd_A(){
        auto w = 32;
        long int num = rand_int(pow(2,w-1),pow(2,w));
        return num;
    }

    std::bitset<32> getA(){
        return std::bitset<32>(generate_odd_A());
    }



    auto hash_t(std::string pal){
        int w = 32;
        long int aux = pow(2,w);
        long r = ceil(log2(7));
        return (((getK(pal)*generate_odd_A()) % aux) >> (w-r));
    }


    auto size_table_m(std::string pal, std::string pal_search){
        auto x_size = pal.size();
        auto y_size = pal_search.size();
        return ceil((x_size/y_size));
    }
    long int getK(const std::string &word){
        auto size = 0;
        for(char i : word){
            size += int(i);
        }
        return size;
    }

    //Average length of list N / M = constant.


    void insert(const std::string &word){
        auto hashValue = hash_t(word);
        table[hashValue].emplace_back(word);
    }






#endif //P3_H
