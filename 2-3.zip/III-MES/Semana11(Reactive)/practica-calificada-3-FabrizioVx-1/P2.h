//
// PREGUNTA #2
//

#ifndef P2_H
#define P2_H
#include <queue>
#include <set>
#include <iostream>
using namespace std;
void P2();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//
//no corre por un problema con pq
#include <cmath>
#define pi 3.14
class nearest_spheres{
public:
    priority_queue<nearest_spheres,set<nearest_spheres>> pq;
    vector<nearest_spheres> esferes_return;
    double sw;
    double r;
    double sum_pesos = 0;
    nearest_spheres(){}
    nearest_spheres(int x, int y){
        sw = x;
        r = y;
    }
    double getMs(){
        return sw;
    }
    double getR(){
        return r;
    }
    void add_esfere(const nearest_spheres &p){
        pq.push(p);
        sum_pesos += p.sw*((4*pi/3)*pow((p.r),3));
    }
    double peso(){
        return this->sw*((4*pi/3)*pow((this->r),3));
    }
    double prom(){
        return (sum_pesos/pq.size());
    }

    vector<nearest_spheres> add_vector(){
        while(!pq.empty()){
            if(this->peso() < this->prom()){
                esferes_return.push_back(*this);
            }
            pq.pop();
        }
        return esferes_return;
    }
};












#endif //P2_H
