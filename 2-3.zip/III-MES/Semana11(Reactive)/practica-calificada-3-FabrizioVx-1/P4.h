//
// PREGUNTA #4
//

#ifndef P4_H
#define P4_H
#include <queue>
#include <set>
#include <iostream>
void P4();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//
//terminado
template <typename T ,typename Container1, typename Container2>
bool contain_same_values(const Container1 &ctn1, const Container2 &ctn2){
    std::vector<bool> ver;
    std::priority_queue<T,Container1,std::greater<T>>pq1;
    std::priority_queue<T,Container2,std::greater<T>>pq2;
    for(auto it = ctn1.begin(); it != ctn1.end(); ++it)pq1.push(*it);
    for(auto it = ctn2.begin(); it != ctn2.end(); ++it)pq2.push(*it);
    /*std::set<T> set1,set2;
    set1.insert(begin(ctn1),end(ctn1));
    set2.insert(begin(ctn2),end(ctn2));*/
    while(!pq1.empty() && !pq2.empty()){
        auto cmp1 = pq1.top();
        auto cmp2 = pq2.top();
        if(cmp1 == cmp2){
            ver.push_back(true);
            pq1.pop();
            pq2.pop();
        }
        else{
            ver.push_back(false);
            pq1.pop();
            pq2.pop();
        }
    }
    return ver[ver.size() - 1];
}





#endif //P4_H
