//
// PREGUNTA #1
//

#ifndef P1_H
#define P1_H
#include <iostream>
#include <vector>
#include <queue>
#include <set>
#include <list>
using namespace std;
void P1();

//
// INCLUIR EL CODIGO EN ESTA SECCION
//

//profe lo hize con priority queue no me castigue, no me alcanzo el tiempo :'( terminado
template <template<typename, typename...>class Container, typename T,typename ...Args>
Container<T> sort_number(Args... args){
    priority_queue<T,vector<T>,greater<>> pq;
    Container<T>you_container;
    (pq.push(args),...);
    while(!pq.empty()){
        you_container.push_back(pq.top());
        pq.pop();
    }
    return you_container;
}











#endif //P1_H
