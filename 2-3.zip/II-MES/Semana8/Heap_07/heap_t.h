//
// Created by Fabrizio on 6/2/20.
//

#ifndef HEAP_07_HEAP_T_H
#define HEAP_07_HEAP_T_H

#include <iostream>
#include <vector>
#include <map>
#include <exception>
using namespace std;


template<class T, template<class...> class container = std::vector>
class max_heap {
public:
    vector<int> data_;
    void percolate_down();
    void percolate_up();
    size_t max_child(size_t index);

public:
    static size_t left_child(T index);
    static size_t right_child(T index);
    size_t getPadre(T index);
    max_heap() = default;
    max_heap(const max_heap& another) = default;
    int find(size_t index = 0);
    void push(T value);
    void pop(T index);
    void pop_all(T index);
    void replace(int value);
    bool is_empty() const;
    size_t size() const;
    void dfs();
    max_heap operator+(const max_heap& another);
    void print(){
        for(auto&i:data_)cout<<i<<" ";
    }
    void Swap(T child, T parent);


};

template<class T, template<class...> class container>
void max_heap<T,container>::Swap(T child, T parent) {
    T temp;
    temp = data_[child];
    data_[child] = data_[parent];
    data_[parent] = temp;
}

template<class T, template<class...> class container>
size_t max_heap<T,container> :: getPadre(T child) {
    if (child % 2 == 0)
        return (child /2 ) -1;
    else
        return child/2;
}

template<class T, template<class...> class container>
size_t max_heap<T,container>::left_child(T parent){
    return 2*parent +1;
}

template<class T, template<class...> class container>
size_t max_heap<T,container> ::right_child(T parent){
    return 2 * parent + 2;
}

template<class T, template<class...> class container>
void max_heap<T,container> :: push(T value) {
    data_.push_back(value);
    percolate_up()
}

template<class T, template<class...> class container>
void max_heap <T,container>:: percolate_up() {
    auto child = data_.size() - 1;
    T parent = getPadre(child);

    while (data_[child] > data_[parent] && child >=0 && parent >= 0) {
        Swap(child, parent);
        child = parent;
        parent = getPadre(child);
    }
}

template<class T, template<class...> class container>
void max_heap<T, container>::pop(T index) {
    data_.erase(data_.begin()+index);
    percolate_up();

}

template<class T, template<class...> class container>
void max_heap<T, container>::pop_all(T data) {
    /*vector<int> indexes;
    for(const auto&i:data){
        if(i == data)
    }*/
}

template<class T, template<class...> class container>
void max_heap<T,container> :: percolate_down() {
    int parent = 0;
    while (1) {
        int izq = left_child(parent);
        int der = right_child(parent);
        auto length = data_.size();
        int largest = parent;

        if (izq < length && data_[izq] > data_[largest])
            largest = izq;

        if (der < length && data_[der] > data_[largest])
            largest = der;

        if (largest != parent) {
            Swap(largest, parent);
            parent = largest;
        }
        else
            break;
    }
}



#endif //HEAP_07_HEAP_T_H
