//
// Created by Fabrizio on 6/2/20.
//

#include "heap_t.h"


/*
size_t max_heap::left_child(size_t index) {
    return data_[2*index+1];
}

size_t max_heap::right_child(size_t index) {
    return data_[2*index+2];
}

void max_heap::percolate_up(size_t index) {
    while(data_[(index/2)-1] > data_[index]) {
        if (data_.size() > index) {
            if (index == 0) {
                return;
            } else if (index % 2 == 0) {
                swap(data_[(index / 2) - 1], data_[index]);
            } else if (index % 2 != 0) {
                swap(data_[(index - 1) / 2], data_[index]);
            }
        }
        index = (index/2) - 1;
    }
}

void max_heap::percolate_down(size_t index) {
    if(index == 0){

        while (data_[2*index] > data_[2 * index+2] && right_child(index) < left_child(index)) {
            swap(data_[2*index], data_[2 * index+2]);
            index = (index * 2);
        }

        while (data_[2*index+1] < data_[2*index] && right_child(index) > left_child(index)) {
            swap(data_[2*index+1], data_[2 * index]);
            index = (index*2)+1;
        }
    }
*/
    /*
    while(data_[index*2] > data_[index]){
        if(data_.size() > index){
            if(index == 0){
                swap(data_[index],data_[2*index]);
            }
            else if(index %2 == 0){

            }
        }
    }

}
*/

/*
void max_heap::push(int value) {
    data_.push_back(value);
}


void max_heap::print() {
    for(auto&i:data_)cout<<i<<" ";
}
*/


