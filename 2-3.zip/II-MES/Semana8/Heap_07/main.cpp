#include <iostream>
#include "heap_t.h"
int main() {
    max_heap<int> heap;
    heap.push(14);
    heap.push(4);
    heap.push(3);
    heap.push(7);
    heap.push(5);
    heap.push(8);
    heap.push(10);
    heap.push(11);
    heap.push(9);
    heap.push(9);
    heap.push(6);

    heap.print();cout<<endl;
    heap.pop(3);
    heap.print();
    return 0;
}
