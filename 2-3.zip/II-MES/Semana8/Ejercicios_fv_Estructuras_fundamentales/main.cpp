#include <iostream>
#include "heap.h"


int main() {

    heap_t heap =  heap_t();
    heap.push(8);
    heap.push(11);
    heap.push(9);
    heap.push(2);
    heap.push(10);
    heap.push(16);
    //cout<<heap->min_child(4);





    return 0;
}
