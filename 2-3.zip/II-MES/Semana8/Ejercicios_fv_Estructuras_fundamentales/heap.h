//
// Created by Fabrizio on 5/30/20.
//

#ifndef EJERCICIOS_FV_ESTRUCTURAS_FUNDAMENTALES_HEAP_H
#define EJERCICIOS_FV_ESTRUCTURAS_FUNDAMENTALES_HEAP_H

#include <iostream>
#include <vector>
#include <numeric>
#include <compare>
#include <bits/stdc++.h>

using namespace std;


template < typename T>
class heap_t{
private:
    vector<int> data_;
    void percolate_down(size_t index);
    void percolate_up(size_t index);

public:

    size_t max_child(size_t index);
    static size_t left_child(size_t index);
    static size_t right_child(size_t index);
    static size_t Parent(size_t index);
    heap_t() = default;
    heap_t(const heap_t& another) = default;
    int find(size_t index = 0);
    void push(int value);
    void pop();
    void replace(int value);
    bool is_empty() const;
    size_t size() const;
    void DFS(int index);
    heap_t operator+(const heap_t& another);



    /*
    void sum(){
        T sum = (accumulate(h.begin(), h.end(), 0));
        cout<<sum;
    }*/

    /*
    void percolate_up() {
        T child = data_.size()-1;
        T parent = getParent(child);
        while( data_[child] > data_[parent] && child > 0){
            T aux=data_[child];
            data_[child] = data_[parent];
            data_[parent] = aux;
            child = parent;
            parent = getParent(child);
        }
    }*/


};




#endif //EJERCICIOS_FV_ESTRUCTURAS_FUNDAMENTALES_HEAP_H
