//
// Created by Fabrizio on 5/30/20.
//

#include "heap.h"


void heap_t::percolate_down(size_t index) {
    int parent = index;

    while (1) {
        int izq = left_child(parent);
        int der = right_child(parent);
        auto length = data_.size();
        int largest = parent;

        if (izq < length && data_[izq] > data_[largest])
            largest = izq;

        if (der < length && data_[der] > data_[largest])
            largest = der;

        if (largest != parent) {
            swap(largest, parent);
            parent = largest;
        }
        else
            break;
    }
}


void heap_t::percolate_up(size_t index) {
    while( data_[index] < data_[index/2]){
        auto aux=data_[index/2];
        data_[index/2] = data_[index];
        data_[index] = aux;
        index /=2;
    }
}


size_t heap_t::max_child(size_t index) {
    if(index * 2 + 1 > data_.size() ){
        return index*2;
    }
    else if(data_[index*2] < data_[index*2+1]){
        return index*2;
    }
    else{
        return index*2+1;
    }
}


size_t heap_t::left_child(size_t index) {
    return 2*index+1;
}

size_t heap_t::right_child(size_t index) {
    return 2*index+2;
}

size_t heap_t::Parent(size_t index) {
    auto index_t = 0;
    if(index % 2 == 0){
        index_t = (index / 2) - 1;
    }
    else if( index % 2 != 0){
        index_t = index / 2;
    }
    return index_t;
}


int heap_t::find(size_t index) {
    return 0;
}


void heap_t::push(int value) {
    data_.push_back(value);
    percolate_up(data_.size()-1);
}


void heap_t::pop() {

}

void heap_t::replace(int value) {

}

bool heap_t::is_empty() const {
    return false;
}

size_t heap_t::size() const {
    return 0;
}


void heap_t::DFS(int index) {
    

}

