#include <iostream>
#include<vector>
#include "Tablero.h"
using namespace std;

int main() {
    Tablero tablero(0);
    tablero.inicializar_tablero();
    tablero.mostrar_tablero();
    tablero.atack();
    cout<<endl;
    tablero.mostrar_tablero();


    return 0;
}
