//
// Created by Fabrizio on 6/1/20.
//

#ifndef EXAMPLE_PROYECT_CASILLERO_H
#define EXAMPLE_PROYECT_CASILLERO_H

#include "Utils.h"

class Casillero {
public:
    Casillero();

    Casillero(int i);

    t_bool hundido;
    t_tipo tipo;
    t_bool ocupado;
};


#endif //EXAMPLE_PROYECT_CASILLERO_H
