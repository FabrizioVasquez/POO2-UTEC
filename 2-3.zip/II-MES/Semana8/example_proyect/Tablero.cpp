//
// Created by Fabrizio on 6/1/20.
//

#include "Tablero.h"


void Tablero::inicializar_tablero() {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            tablero[i][j].ocupado = FALSE;
        }
    }
    /* 1 ACORAZADO */
    tablero[4][18].ocupado = TRUE;
    tablero[4][18].tipo = ACORAZADO;
    tablero[4][18].hundido = FALSE;
    tablero[5][18].ocupado = TRUE;
    tablero[5][18].tipo = ACORAZADO;
    tablero[5][18].hundido = FALSE;
    tablero[6][18].ocupado = TRUE;
    tablero[6][18].tipo = ACORAZADO;
    tablero[6][18].hundido = FALSE;

    /*2 CRUCEROS*/
    tablero[9][2].ocupado = TRUE;
    tablero[9][2].tipo = CRUCERO;
    tablero[9][2].hundido = FALSE;
    tablero[9][3].ocupado = TRUE;
    tablero[9][3].tipo = CRUCERO;
    tablero[9][3].hundido = FALSE;

    tablero[3][9].ocupado = TRUE;
    tablero[3][9].tipo = CRUCERO;
    tablero[3][9].hundido = FALSE;
    tablero[4][9].ocupado = TRUE;
    tablero[4][9].tipo = CRUCERO;
    tablero[4][9].hundido = FALSE;



    /*3 portaaviones*/
    tablero[1][1].ocupado = TRUE;
    tablero[1][1].tipo = PORTAAVION;
    tablero[1][1].hundido = FALSE;
    tablero[6][12].ocupado = TRUE;
    tablero[6][12].tipo = PORTAAVION;
    tablero[6][12].hundido = FALSE;
    tablero[8][19].ocupado = TRUE;
    tablero[8][19].tipo = PORTAAVION;
    tablero[8][19].hundido = FALSE;
}

void Tablero::mostrar_tablero() {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            if(!(tablero[i][j].ocupado)){
                cout<<"0";
            }
            else{
                if(tablero[i][j].hundido == FALSE) {
                    switch (tablero[i][j].tipo) {
                        case ACORAZADO:
                            cout << "A";
                            break;
                        case CRUCERO:
                            cout << "C";
                            break;
                        case PORTAAVION:
                            cout << "P";
                            break;
                        default:
                            cout << "S";
                            break;
                    }
            }
                else{
                    switch (tablero[i][j].tipo){
                        case ACORAZADO:
                            cout<<"X";
                            break;
                        case CRUCERO:
                            cout<<"X";
                            break;
                        case PORTAAVION:
                            cout<<"X";
                            break;
                        case SUBMARINO:
                            cout<<"X";
                            break;
                    }
                }
            }
        }
        cout<<endl;
    }
}


void Tablero::change_to_values() {
    for (int i = 0; i < 10; ++i) {
        for (int j = 0; j < 20; ++j) {
            if(tablero[i][j].tipo == ACORAZADO){
                tablero[i][j] = 1;
            }
        }
    }
}

void Tablero::atack() {
    tablero[4][18].hundido = TRUE;
    tablero[1][1].hundido = TRUE;

}


Tablero::Tablero(int i) : Casillero(i) {
    /*tablero = new Casillero*[10];
    for (int i = 0; i < 10; ++i) {
        tablero[i] = new Casillero[10];
    }*/
    tablero.resize(10,vector<Casillero>(20));

}

Tablero::~Tablero() {}
/*
Tablero::~Tablero() {
    for (int i = 0; i < 0; ++i) {
        delete [] tablero[i];
    }
    delete [] tablero;
}
*/
