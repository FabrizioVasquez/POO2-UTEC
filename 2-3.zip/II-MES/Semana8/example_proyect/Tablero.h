//
// Created by Fabrizio on 6/1/20.
//

#ifndef EXAMPLE_PROYECT_TABLERO_H
#define EXAMPLE_PROYECT_TABLERO_H

#include "Casillero.h"

class Tablero : public Casillero {
private:

    //Casillero **tablero;
    vector<vector<Casillero>> tablero;
public:
    Tablero(int i);
    ~Tablero();
    void inicializar_tablero();
    void mostrar_tablero();
    void change_to_values();
    void atack();

};

#endif //EXAMPLE_PROYECT_TABLERO_H
