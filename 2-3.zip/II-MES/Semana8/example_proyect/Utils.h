//
// Created by Fabrizio on 6/1/20.
//

#ifndef EXAMPLE_PROYECT_UTILS_H
#define EXAMPLE_PROYECT_UTILS_H

#include <iostream>
#include <vector>
using namespace std;

typedef enum {ACORAZADO,CRUCERO,PORTAAVION,SUBMARINO} t_tipo;
typedef enum {FALSE, TRUE} t_bool;

#endif //EXAMPLE_PROYECT_UTILS_H
