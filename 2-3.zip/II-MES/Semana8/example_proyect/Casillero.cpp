//
// Created by Fabrizio on 6/1/20.
//

#include "Casillero.h"

Casillero::Casillero(int i) {

}

Casillero::Casillero() {

}
