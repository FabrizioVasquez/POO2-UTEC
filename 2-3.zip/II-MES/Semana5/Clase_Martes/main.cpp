#include <iostream>
#include <ctime>
#include <tgmath.h>
using namespace std;

int fun(int n){
    int count =  0;
    for(int i = 0 ; i < n ; ++i) {
        for (int j = i; j > 0; --j) {
            count += 1;
        }
    }
    return count;
}

int fun2(int n){
    for (int i = 1; i < n; ++i) {
        for (int j = 1; j < log(i); ++j) {
            cout<<"abc"<<endl;
        }
    }
    cout<<endl;
}

int main() {

    unsigned t0 = clock();
    fun(4);
    unsigned t1 = clock();
    double time = (double(t1-t0)/CLOCKS_PER_SEC);
    cout<<time<<endl;
    unsigned t3 = clock();
    fun2(10);
    unsigned t4 = clock();
    double time2 = (double(t4-t3)/CLOCKS_PER_SEC);
    cout<<time2<<endl;

    std::cout << "Hello, World!" << std::endl;
    return 0;
}
