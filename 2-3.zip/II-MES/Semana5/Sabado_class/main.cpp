#include <iostream>
#include <ctime>
#include <string>
#include <fstream>
#include<vector>
#include<set>
#include "exercise11.h"
#include "uva12541.h"
#include <tgmath.h>
using namespace std;
/*
int fun(int n){
    int count =  0;
    for(int i = 0 ; i < n ; ++i) {
        for (int j = i; j > 0; --j) {
            count += 1;
        }
    }
    return count;
}

int fun2(int n){
    for (int i = 1; i < n; ++i) {
        for (int j = 1; j < log(i); ++j) {
            cout<<"abc"<<endl;
        }
    }
    cout<<endl;
}

//Exercise 4
//D) n^1.98

//Exercise 5

void recursive(int n ){
    if(n <= 1){
        return;
    }
    cout<<"utec"<<endl;
    recursive(n/2);
    recursive(n/2);
}

//Exercise 6
void loop(int& n, int& k){
    for (int i = 0; i < n; ++i) {
        for (int j = 1; j < n; j=j*k) {
            cout<<"utec"<<endl;
        }
    }
    cout<<endl;
}


//Exercise 7
void f1(int n){
    for(int i = 0; i < n; i = i+int(pow(n,log(n)))){
        cout<<"utec";
    }
}

//Exercise 8
vector<string> get_anagram (string word ,string filename){
    //  n : elementos en el file
    //  m : elementos en el texto : constante
    //  k : numero de veces que aparece = count
    // r :  resto de palabras que no son
    vector<std::string>pal_anagram;
    vector<char>pal;
    size_t count=0;
    string line;
    ifstream file_read;
    file_read.open(filename);
    if(!file_read.is_open()){
        cout<<"Error"<<endl;
    }
    else{
        while(getline(file_read,line)){ // n ->lineas
            if ( line == word) {                 // (n-r)
                count++;                        // k
                pal_anagram.push_back(line);    // O(1)
            }
            for(int i = 0 ; i < line.size() ; ++i ){    //n
                for(int j = 0; j < line.size(); ++j){   //n^2
                    if(word[i] == line[j]){             //n^2 - r
                        continue;
                    }
                }
            }
        }
        //Mejor caso: El elemento buscado se encuentra (n - r).
        //Peor caso : El elemento buscado se encuentra en todas las lineas ( n - 0)
        // (n^2-r) (n-r) + n + O(1) => n^2-r + n - r + n  => O(n^2)
    }
    return pal_anagram;
}

//Exercise 9
class suma_cuatro{
private:
    int * ar;
    size_t n;
public:
    suma_cuatro(size_t _n):n(_n){
        srand(time(NULL));
        ar = new int[n];
        for(int i = 0 ; i < n; i++){
            ar[i] = rand()%10;
        }
    }
    pair<int*,set<int*>>operator()(int value){
        set<int*>set_ar;
        for(int i = 0 ; i < n ; i++){
            if(ar[i] + ar[n-1] == 10){
                set_ar.insert(ar);
            }
        }
        return make_pair(ar,set_ar);
    }
};

//Exercise 10
class Functor{
private:
    int n ;
public:
    Functor(int _n):n(_n){}
    pair<int,int> operator()(){

    }
};

void time_f(unsigned n1, unsigned n2){
    double time = (double (n2-n1)/CLOCKS_PER_SEC);
    cout<<"\nEl tiempo de ejecución es: "<< time<<"\n";
}


//Exercise 11

*/
int main() {
    /*
    //Exercise 1
    cout<<"Exercise 1"<<endl;
    unsigned t0 = clock();
    fun(4);
    unsigned t1 = clock();
    time_f(t0,t1);

    //Exercise 2
    cout<<"Exercise 2"<<endl;
    unsigned t3 = clock();
    fun2(10);
    unsigned t4 = clock();
    time_f(t3,t4);

    //Exercise 4
    //D) n^1.98

    //Exercise 5
    cout<<"Exercise 5"<<endl;
    unsigned t5 = clock();
    recursive(20);
    unsigned t6 = clock();
    time_f(t5,t6);

    //Exercise 6
    cout<<"Exercise 6"<<endl;
    unsigned t7 = clock();
    int n = 10, k = 2;
    loop(n,k);
    unsigned t8 = clock();
    time_f(t7,t8);

    //Exercise 7
    cout<<"Exercise 7"<<endl;
    cout<<"F1"<<endl;
    unsigned t9 = clock();
    f1(20);
    unsigned t10 = clock();
    time_f(t9,t10);

    //Exercise 8

    cout<<"Exercise 8"<<endl;
    unsigned t11 = clock();
    cout<<"Mejor caso: "<<endl;
    for(auto &item:get_anagram("gae","exercise8.txt")) {
        cout << item;
    }
    unsigned t12 = clock();
    time_f(t11,t12);
    cout<<"Peor caso: "<<endl;
    unsigned t13 = clock();
    for(auto &item:get_anagram("utec","exercise8.txt")) {
        cout << item;
    }
    unsigned t14 = clock();
    time_f(t13,t14);

    */
    //Exercise 9
    //Functor f(10);
    //auto x = f();
    //Exercise 10

    //Exercise 11
    /*auto b = par_cercano(10);
    auto c = b.operator()().first;
    auto d = b.operator()().second;
    cout<<c<<" "<<d;*/

    //Exercise12
    //auto local = minimo_local(10);
    //local.find();

    uva1251();

    return 0;
}
