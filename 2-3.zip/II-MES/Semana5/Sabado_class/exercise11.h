//
// Created by Fabrizio on 5/12/20.
//

#ifndef SABADO_CLASS_EXERCISE11_H
#define SABADO_CLASS_EXERCISE11_H

#include <bits/stdc++.h>
using namespace std;

class par_cercano{
private:
    double *arr;
    int n;
public:
    par_cercano(int n_):n(n_){
        arr = new double[n];
        srand(time_t(nullptr));
        for (size_t i = 0; i <n; ++i) {
            arr[i] = rand()%50;
        }
    }
    int getSize(){
        return n;
    }
    pair<size_t,size_t> operator()(){
        sort(arr,arr+10);
        return make_pair(arr[(getSize()/2)-1],arr[(getSize()/2)]);
    }
    void print_(){
        for (int i = 0; i < getSize(); ++i) {
            cout<<arr[i]<<endl;
        }
    };

};


#endif //SABADO_CLASS_EXERCISE11_H
