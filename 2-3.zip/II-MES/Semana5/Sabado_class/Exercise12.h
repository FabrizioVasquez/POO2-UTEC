//
// Created by Fabrizio on 5/13/20.
//

#ifndef SABADO_CLASS_EXERCISE12_H
#define SABADO_CLASS_EXERCISE12_H

#include <bits/stdc++.h>
#include<tgmath.h>
using namespace std;
class minimo_local{
private:
    int arr[10]={8,6,2,5,4,3,7,1,9,10};
    int size;
public:
    minimo_local(int n_):size(n_){

    }
    int getSize(){
        return size;
    }
    void find(){
        for (int i = 0; i < getSize(); i=i+(log(getSize())/log(2))) {
            cout<<"Minimo "<< "Medio " <<" Maximo"<<endl;
            cout<<arr[(i/2)-1]<<"       "<<arr[(i/2)] <<"        "<<arr[(i/2)+1]<<endl;
        }
    }

    void print(){
        for (int i = 0; i < getSize(); ++i) {
            cout<<arr[i]<<" ";
        }
    }


};

#endif //SABADO_CLASS_EXERCISE12_H
