//
// Created by Fabrizio on 5/13/20.
//

#ifndef SABADO_CLASS_UVA12541_H
#define SABADO_CLASS_UVA12541_H

#include <bits/stdc++.h>
using namespace std;

class Info_persons{
public:
    string name;
    int day,moth,year;
    Info_persons(string name_,int day_, int moth_, int year_){
       name = name_;
       day = day_;
       moth = moth_;
       year = year_;
    }

    bool operator < (Info_persons &persons)
    {
        if(year!=persons.year)
            return year > persons.year;
        else if(moth !=persons.moth)
            return moth > persons.moth;
        return day > persons.day;
    }
};


void uva1251() {
    ifstream file_read("uva1251.txt");
    int size_ages = 0, count_ages = 0;
    string line;
    char name[500];
    int day, moth, year;
    vector<Info_persons> data;
    if (!file_read.is_open()) {
        cout << " File not found " << endl;
    } else {
        file_read >> size_ages;
        file_read.get();
        while (size_ages > count_ages) {
            while (getline(file_read, line)) {
                istringstream i(line);
                i >> name >> day >> moth >> year;
                data.push_back(Info_persons(name, day, moth, year));
            }
            count_ages++;
        }

        sort(data.begin(),data.end(),[](Info_persons &a, Info_persons &b){
            return a < b;
        });
        cout << data[0].name << endl;
        cout << data.back().name << endl;
    }
}

#endif //SABADO_CLASS_UVA12541_H
