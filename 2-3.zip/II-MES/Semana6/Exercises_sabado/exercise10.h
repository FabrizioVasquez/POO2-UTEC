//
// Created by Fabrizio on 5/19/20.
//

#ifndef EXERCISES_SABADO_EXERCISE10_H
#define EXERCISES_SABADO_EXERCISE10_H

#include <vector>
#include <list>

vector<int> vectu;
template < typename T, typename ... Args, template<typename ...> class Container = vector>
auto print(Container<T> ctn1, Args& ...args){
    vectu.push_back(ctn1.size());
    (print(args),...);
}

template < typename T, typename ... Args, template<typename ...> class Container = vector>
auto min_size(Container<T>& ctn1, Args &...args){
    auto min = 9999;
    print(ctn1,args...);
    for (int i = 0; i < vectu.size(); ++i) {
        if(vectu[i] < min ){
            min = vectu[i];
        }
    }
    return min;
}

/*
template <typename ... Args, typename T>
T &min_size(T &ctn, Args &...args) {
    auto value = min_size(args...);
    return value;
}*/


#endif //EXERCISES_SABADO_EXERCISE10_H
