//
// Created by Fabrizio on 5/17/20.
//

#ifndef EXERCISES_SABADO_ALL_EXERCISES_H
#define EXERCISES_SABADO_ALL_EXERCISES_H

#include "exercise2.h"
#include "exercise3.h"
#include "exercise4.h"
#include "exercise7.h"
#include "exercise8.h"
#include "exercise9.h"
#include "exercise10.h"
#include "class_exercise1.h"
#include "class_exercise2.h"


#endif //EXERCISES_SABADO_ALL_EXERCISES_H
