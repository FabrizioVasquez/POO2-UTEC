//
// Created by Fabrizio on 5/16/20.
//

#ifndef EXERCISES_SABADO_EXERCISE2_H
#define EXERCISES_SABADO_EXERCISE2_H

#include <vector>
#include <list>
using namespace std;




template <typename T, typename U, typename ... Args>
void f(T& container, U First, Args... args){
    ((container = args), ...);
}

template < typename T, typename ... Args>
void push(T &cnt, Args ... args){
    (cnt.push_back(args),...);
}

//Es un template de Contenedores
template < typename T, template<typename ...> class Container>
void split_range1(Container<T> container, int n){
    for(typename Container<T>::iterator it = container.begin(); it != end(container);++it){
        cout<<*it<<" ";
    }
}


template < typename T,typename ...Args, template < typename> class Container=vector>
vector<T,Args...> split_rane(T cnt, int n){
    vector<vector<int>> f;
}


class Myexception: public exception{
public:
    virtual const char* what() const noexcept{
        return "¡EXCEPTION!";
    }
    friend ostream&operator<<(ostream &os, Myexception &e){
        os<<e;
        return os;
    }
}excep ;



template < template <typename...> class Container=vector, typename T, typename ...Args>
vector<vector<T>> split_range(Container<T>&ctn, int n ){
    vector<vector<int>>ctn_real{};
    return ctn_real;
}





#endif //EXERCISES_SABADO_EXERCISE2_H
