//
// Created by Fabrizio on 5/17/20.
//

#ifndef EXERCISES_SABADO_EXERCISE4_H
#define EXERCISES_SABADO_EXERCISE4_H
#include <vector>
#include <list>
#include <unordered_map>
#include <unordered_set>
#include <map>
#include <deque>
template < typename T,template<typename ...> class Container>
Container<T> delete_items(Container<T>&ctn, int n){
    typename Container<T>::iterator it;
    for(it = ctn.begin();it!=end(ctn);it++){
        while(*it == n){
            ctn.erase(it);
        }
    }
    return ctn;
}

template < typename T, typename ... Args, template<typename ...> class Container>
Container<T> delete_items(Container<T>&ctn,int n, Args...args ) {
    delete_items(ctn,n);
    return delete_items(ctn,args...);
}


template < typename T, typename ... Args, template<typename ...> class Container>
Container<T> delete_items(Container<T>&ctn, Container<T> ctn_eliminate ) {
    typename Container<T>::iterator it;
    unordered_set<T>ctn_real;
    Container<T>ctn_real_noFake;
    map<T,T> veces;

    for(auto&i:ctn){
        veces[i]++;
        ctn_real.insert(i);
    }
    for(auto&j:ctn_real){
        ctn_real_noFake.push_back(j);
    }

    for(it = ctn_eliminate.begin();it!=end(ctn_eliminate);it++){
        for(auto it2 = ctn_real_noFake.begin();it!=end(ctn_real_noFake);it2++){
            if(*it == *it2){
                ctn_real_noFake.erase(it2);
                break;
            }
        }
    }

    //ctn_eliminate{ 1,4 }
    //ctn{1, 3, 4, 1, 3, 2, 3, 4, 6, 5};
    //ctn_real{1, 2, 3 ,4 ,5, 6}

    for(auto i: veces){
        for(auto it1 = ctn_eliminate.begin(); it1 != end(ctn_eliminate);it1++){
            if(i.first != *it1 && i.second > 2){
                ctn_real_noFake.push_back(i.second);
            }
        }
    }
    return ctn_real_noFake;
}

template < typename T, typename ... Args, template<typename ...> class Container>
Container<T> delete_items(Container<T>&ctn,Container<T> ctn_eliminate,Args ... args ) {
    delete_item(ctn,ctn_eliminate);
    return delete_items(ctn,args...);
}


#endif //EXERCISES_SABADO_EXERCISE4_H
