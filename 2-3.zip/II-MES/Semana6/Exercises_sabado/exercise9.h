//
// Created by Fabrizio on 5/17/20.
//

#ifndef EXERCISES_SABADO_EXERCISE9_H
#define EXERCISES_SABADO_EXERCISE9_H

#include <vector>
#include <list>
/*
 * Another example but only work in std::vector
template <typename T,typename ...Args,template<typename>class Container>
Container<int> generar_contenedor(Args const & ... args){
    vector<int>vec;
    (vec.push_back(args),...);
    cout<<__PRETTY_FUNCTION__ <<endl;
    return vec;
}*/

template <template<typename, typename...> class Container=vector, typename T, typename ...Args>
Container<T> generar_contenedor(const T& first, const Args& ... args){
    Container<T> cont;
    cont.push_back(first);
    (cont.push_back(args), ...);
    cout<<__PRETTY_FUNCTION__ <<endl;
    return cont;
}

#endif //EXERCISES_SABADO_EXERCISE9_H
