//
// Created by Fabrizio on 5/19/20.
//

#ifndef EXERCISES_SABADO_CLASS_EXERCISE2_H
#define EXERCISES_SABADO_CLASS_EXERCISE2_H

#include <iostream>
using namespace std;
template<class T, template<class...> class Container = std::vector>
class max_heap{
public:
    T find_max();
    void insert(T item);
    T Delete();
    void print();

    void up();
    void down();
    void swap(T padre, T hijo);
    T getPadre(T hijo);
    T getNodoIzquierdo(T);
    T getNodoDerecho(T);

private:
    Container<T> container1;
};

template<class T, template<class...> class container>
T max_heap<T,container> ::getNodoIzquierdo(T parent){
    return 2*parent +1;
}

template<class T, template<class...> class container>
T max_heap<T,container> ::getNodoDerecho(T parent){
    return 2 * parent + 2;
}

template<class T, template<class...> class Container>
T max_heap<T, Container>::find_max() {
    auto hijo = container1.size()  - 1;
    swap(hijo, 0);
    T value = container1.back();
    container1.pop_back();
    down();
    return value;
}

template<class T, template<class...> class Container>
void max_heap<T, Container>::insert(T item) {
    container1.push_back(item);
    up();
}

template<class T, template<class...> class Container>
T max_heap<T, Container>::Delete() {
    container1.pop_back();
    return container1[container1.size()];
}

template<class T, template<class...> class Container>
void max_heap<T, Container>::print() {
    for(auto&i:container1){
        cout<< i <<endl;
    }
}

template<class T, template<class...> class Container>
T max_heap<T, Container>::getPadre(T hijo) {
    if(hijo % 2 == 0){
        return (hijo/2)-1;
    }else{
        return (hijo/2);
    };
}

template<class T, template<class...> class Container>
void max_heap<T, Container>::up() {
    auto hijo = container1.size()-1;
    T padre = getPadre(hijo);

    while(hijo >= 0 && padre >= 0 && container1[hijo] > container1[padre]){
        swap(hijo, padre);
        hijo = padre;
        padre = getPadre(hijo);
    }
}

template<class T, template<class...> class Container>
void max_heap<T, Container>::swap(T padre, T hijo) {
    T aux;
    aux = container1[padre];
    container1[padre] = container1[hijo];
    container1[hijo] = aux;
}

template<class T, template<class...> class Container>
void max_heap<T, Container>::down() {
    int padre = 0;

    while (1) {
        int index_iz = getNodoIzquierdo(padre);
        int index_de = getNodoDerecho(padre);
        auto length = container1.size();
        int largest = padre;

        if (index_iz < length && container1[index_iz] > container1[largest])
            largest = index_iz;

        if (index_de < length && container1[index_de] > container1[largest])
            largest = index_de;

        if (largest != padre) {
            swap(largest, padre);
            padre = largest;
        }
        else
            break;
    }
}



#endif //EXERCISES_SABADO_CLASS_EXERCISE2_H
