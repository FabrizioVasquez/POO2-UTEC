//
// Created by Fabrizio on 5/19/20.
//

#ifndef EXERCISES_SABADO_EXERCISE8_H
#define EXERCISES_SABADO_EXERCISE8_H

#include <vector>
#include <list>

//More information in tie function
template <typename ...Args>
tuple<Args &...> unpack_8(Args & ... args){
    return tuple<Args&...>(args...);
}



#endif //EXERCISES_SABADO_EXERCISE8_H
