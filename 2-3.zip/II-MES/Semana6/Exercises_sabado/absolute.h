//
// Created by Fabrizio on 5/16/20.
//

#ifndef EXERCISES_SABADO_ABSOLUTE_H
#define EXERCISES_SABADO_ABSOLUTE_H

#include <bits/stdc++.h>
using namespace std;
template < typename T>
T absolute(T value){
    return (value * -1);
}



#endif //EXERCISES_SABADO_ABSOLUTE_H
