#include <iostream>
#include "all_exercises.h"

int main() {

    cout<<"EXERCISE 2"<<endl;
    deque<int> v1 = {1, 2, 3, 4, 5, 6, 7};
    int n = 1 ;
    v1.resize(2);
    auto resultado = split_range(v1,n);
    for(auto&i:v1)cout<<i<<" ";


    cout<<"\nEXERCISE 3"<<endl;
    vector<int> v31 = {1,2, 3, 4,5};
    vector<int> v32 = {10, 20};
    auto v33 = suma_rango(v32,v31);
    for(auto&i:v33)cout<<i<<" ";

    cout<<endl;

    list<int> l31 = {1,2,3,4};
    list<int> l32 = {10,20};
    auto l33 = suma_rango(l31,l32);
    for(auto&i:l33)cout<<i<<" ";

    cout<<endl;

    list<int> l31e = {2,6,7};
    list<int> l32e = {10,20,30};
    auto l33e = suma_rango(l31e,l32e);
    for(auto&i:l33e)cout<<i<<" ";

    cout<<endl;
    cout<<endl;


    cout<<"EXERCISE 4"<<endl;
    vector<int> v41 = {1, 3, 4, 1, 3, 2, 3, 4, 6, 5};
    auto v4e = delete_items(v41, 1,3,4);
    for(auto&i:v41)cout<<i <<" ";
    cout<<endl;
    list<int> v42 = {1, 3, 4, 1, 3, 2, 3, 4, 6, 5};
    auto v42e = delete_items(v42, {1,2});
    for(auto&i:v42e)cout<<i <<" ";

    std::cout<<endl;
    std::cout<<endl;



    cout<<"EXERCISE 7"<<endl;
    std::pair<int, string> p1 = {1321, "Jose Perez"};
    int key_2; string name;
    unpack_7(key_2, name) = p1;
    std::cout << key_2 << " " << name;
    std::cout<<endl;
    std::cout<<endl;



    cout<<"EXERCISE 8"<<endl;
    std::tuple<int, string, string, double> t1 = {1321, "Jose", "Perez", 1.68};
    int key;string first_name; string last_name; double height;
    unpack_8(key, first_name, last_name, height) = t1;
    std::cout << key << " "<< first_name<<" "<< last_name<<" " << height;
    std::cout<<endl;



    cout<<"EXERCISE 9"<<endl;
    auto c1 = generar_contenedor(1, 3, 3, 4);
    for (const auto& item: c1)
        std::cout << item << " ";
    std::cout << endl;
    std:cout<<endl;

    auto c2 = generar_contenedor<list>(1, 7, 1, 9);
    for (const auto& item: c2)
        std::cout << item << " ";
    std::cout << endl;
    std::cout<<endl;


    cout<<"EXERCISE 10"<<endl;
    vector<int> v110 = { 11 };
    vector<int> v2 = { 21, 22, 23, 1, 2 };
    vector<int> v3 = { 31, 32, 33, 4 };
    vector<int> v4 = { 3, 6, 7};
    vector<int> v5 = { 5, 2};

    cout<<min_size(v2,v3)<<endl;
    cout<<min_size(v2, v3,v4)<<endl;
    cout<<min_size(v110, v2,v3,v5)<<endl;
    std::cout<<endl;
    std::cout<<endl;


    cout<<"EXERCISE CLASS_1"<<endl;
    LinkedList<int> p;

    p.push_front(6);
    p.push_front(7);
    p.push_back(5);
    auto i = p.pop_front();
    auto k = p.back();
    cout<<k;
    std::cout<<endl;
    std::cout<<endl;



    cout<<"EXERCISE CLASS_2"<<endl;
    auto b = new max_heap<int>;
    b->insert(10);
    b->insert(20);
    b->insert(7500);
    b->insert(500);
    b->insert(8000);
    b->insert(2000);
    cout<<b->find_max();
    cout<<"\nPRINT:"<<endl;
    b->print();



    /*
    string r_str =
            R"(Dear Programmers,
            I'm using C++11
            Regards, Swift!)";
    cout << r_str;
    */

    return 0;
}


