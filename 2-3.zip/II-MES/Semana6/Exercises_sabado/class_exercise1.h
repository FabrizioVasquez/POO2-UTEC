//
// Created by Fabrizio on 5/19/20.
//

#ifndef EXERCISES_SABADO_CLASS_EXERCISE1_H
#define EXERCISES_SABADO_CLASS_EXERCISE1_H


template <typename T, typename ... Args>
struct Node{
    T value{};
    Node *next= nullptr;
};

template < typename T>
class LinkedList{
public:
    void push_front(T value);
    void push_back(T value);
    T pop_front();
    T pop_back()noexcept ;
    T front();
    T back();
    LinkedList()= default;
    ~LinkedList();
    LinkedList(const LinkedList &);
    friend ostream &operator<<(ostream& os, LinkedList &other){
        while (other.head_ != nullptr) {
            os << other.head_->value << " - ";
            other.head_ = other.head_->next;
            if(other.head_ == nullptr){
                os<<"nullptr";
                os<<endl;
            }
        }
        return os;
    }

private:
    typedef size_t type_u;
    Node<T>* tail_ = nullptr;
    Node<T>* head_ = nullptr;

    type_u size_ = 0;
};

template<typename T>
LinkedList<T>::~LinkedList() {
    for(Node<T>* c = head_; c != nullptr; ){
        Node<T>* p = c;
        c = c->next;
        delete p;
    }
}

template<typename T>
LinkedList<T>::LinkedList(const LinkedList<T> &other){
    while(head_ != nullptr){
        pop_front();
    }
    size_ = other.size_;
    auto node = other.head_;
    while(node != nullptr){
        push_back(node->value);
        node = node->next_;
    }
}

template<typename T>
void LinkedList<T>::push_front(T value) {
    head_ = new Node<T>{value,head_};     //SE CREA UN NODO Y EL HEAD APUNTA A NODE A TAIL YA HAY DOS NODOS
    if(tail_ == nullptr)
        tail_ = head_;
    size_++;
}

template<typename T>
void LinkedList<T>::push_back(T value) {
    auto last = new Node<T>{ value, nullptr };
    auto current = head_;
    if (head_ == nullptr)head_ = last;
    while (current->next != nullptr)
        current = current->next;
    current->next = last;
    size_++;
}
template<typename T>
T LinkedList<T>::pop_front() {
    auto nextt = head_->next;
    if(head_ == tail_){
        delete head_;
        head_ = tail_ = nullptr;
        size_ = 0;
    }
    else{
        nextt = head_->next;
        delete head_;
        head_ = nextt;
        --size_;
    }
    return nextt->value;
}
template<typename T>
T LinkedList<T>::pop_back() noexcept {
    auto aux = new Node<T>{0,head_};
    if(head_ == tail_){
        delete tail_;
        head_ = tail_ = nullptr;
        size_ = 0;
    }
    else{
        for (type_u i = 0; i < size_-1 ; ++i) {
            aux = aux->next;
        }
        delete aux;
        aux->next = nullptr;
    }
    --size_;
    return aux->value;
}
template<typename T>
T LinkedList<T>::front() {
    return head_->value;
}
template<typename T>
T LinkedList<T>::back() {
    auto aux = new Node<T>{0,head_};
    for (type_u i = 0; i < size_ ; ++i) {
        aux = aux->next;
    }
    return aux->value;
}

#endif //EXERCISES_SABADO_CLASS_EXERCISE1_H
