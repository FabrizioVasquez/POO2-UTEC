//
// Created by Fabrizio on 5/19/20.
//

#ifndef EXERCISES_SABADO_EXERCISE7_H
#define EXERCISES_SABADO_EXERCISE7_H

#include <vector>
#include <list>
#include <utility>
template <typename ...Args>
std::pair<Args &...> unpack_7(Args &... args){
    return pair<Args &...>(args...);
}
#endif //EXERCISES_SABADO_EXERCISE7_H
