//
// Created by Fabrizio on 5/16/20.
//

#ifndef EXERCISES_SABADO_EXERCISE3_H
#define EXERCISES_SABADO_EXERCISE3_H

#include <vector>
#include <list>


template < typename T, template<typename ...> class Container = list>
list<T> sumar_i(list<T>&ctn1,list<T>&ctn2){
    list<T> ret;
    while(!ctn1.empty()){
         while(!ctn2.empty()){
             auto p1 = ctn1.front();
             auto p2 = ctn2.front();
             ret.push_back(p1+p2);
             ctn1.pop_front();
             ctn2.pop_front();
         }
     }

    return ret;
}

template < typename T, template<typename ...> class Container = vector>
vector<T> sumar_i(vector<T>&ctn1,vector<T>&ctn2){
    vector<T> ret(ctn1.size());
    for(int i = 0; i <ret.size();i++){
        ret[i] = ctn1[i]+ctn2[i];
    }
    return ret;
}

template < typename T, typename ... Args, template<typename ...> class Container=vector>
constexpr vector<T> copy_(vector<T>&ctn1,vector<T>&ctn2){
    auto size_ctn2 = ctn2.size();
    if(ctn2.size() < ctn1.size()){
        ctn2.resize(ctn1.size());
        copy(ctn2.begin(),ctn2.begin()+size_ctn2, ctn2.begin()+size_ctn2);
    }
    for(auto &i:ctn2){
        if (i == 0){
            ctn2.resize(ctn1.size());
            copy(ctn2.begin(),ctn2.begin()+distance(ctn1.begin(),ctn1.end()),ctn2.begin()+distance(ctn1.begin(),ctn1.end()-1));
        }
    }
    return ctn2;
}

template < typename T, typename ... Args, template<typename ...> class Container=list>
constexpr list<T> copy_(list<T>&ctn1,list<T>&ctn2){
    typename list<T>::iterator it2;
    //typename list<T>::iterator it1;
    list<T> aux;
    it2 = ctn2.begin();
    if(ctn2.size() < ctn1.size()){
        /*advance(it,2);
        ctn2.insert(it,*ctn2.begin());
        it++;
        ctn2.insert(it,20);*/
    }

    for(auto it = ctn2.begin();it !=end(ctn2);it++){
        if(ctn2.size()%4 == 0 ){
            break;
        }
        ctn2.push_back(*it);
    }
    return ctn2;
}

template < typename T, typename ... Args, template<typename ...> class Container=vector>
vector<T> suma_rango(vector<T>&ctn1,vector<T>&ctn2){
    vector<T> aux_contain;
    if(ctn1.size() == ctn2.size()){
        if(ctn1.empty() && ctn2.empty()){
            cout<<"Los contenedores estan vacíos"<<endl;

        }else{
            cout<<"Son iguales"<<endl;
            return sumar_i(ctn1,ctn2);
        }
    }
    else if(ctn1.size() < ctn2.size()) {
        cout<<"El segundo contenedor es mayor"<<endl;
        auto new_container = copy_(ctn2,ctn1);
        return sumar_i(ctn2,new_container);
    }
    else if(ctn1.size() > ctn2.size()){
        cout<<"El primer contenedor es mayor"<<endl;
        auto new_container = copy_(ctn1,ctn2);
        return sumar_i(ctn1,new_container);
    }
}

template < typename T, typename ... Args, template<typename ...> class Container=list>
list<T> suma_rango(list<T>&ctn1,list<T>&ctn2){
    list<T> aux_contain;
    if(ctn1.size() == ctn2.size()){
        if(ctn1.empty() && ctn2.empty()){
            cout<<"Los contenedores estan vacíos"<<endl;

        }else{
            cout<<"Son iguales"<<endl;
            return sumar_i(ctn1,ctn2);
        }
    }
    else if(ctn1.size() < ctn2.size()) {
        cout<<"El segundo contenedor es mayor"<<endl;
        auto new_container = copy_(ctn2,ctn1);
        return sumar_i(ctn2,new_container);
    }
    else if(ctn1.size() > ctn2.size()){
        cout<<"El primer contenedor es mayor"<<endl;
        auto new_container = copy_(ctn1,ctn2);
        return sumar_i(ctn1,new_container);
    }

}




#endif //EXERCISES_SABADO_EXERCISE3_H
