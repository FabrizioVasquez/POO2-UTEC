//
// Created by Fabrizio on 5/14/20.
//

#ifndef EXERCISES_PART2_STL_UVA10258_H
#define EXERCISES_PART2_STL_UVA10258_H

#include <bits/stdc++.h>
using namespace std;

struct Contestant{
    size_t name;
    size_t number_problem;
    size_t time_resolution;
    char state;

    Contestant(size_t name_, size_t number_problem_ ,size_t time_resolution_, char state_ ):
    name(name_),number_problem(number_problem_),time_resolution(time_resolution_)
    {
        state = state_;
    }
    void print(){
        cout<<this->name<< " "<<this->number_problem<<" "<<this->time_resolution<<" "<<this->state<<endl;
    }
};

map<int,Contestant> real_persons;

bool comp(int a, int b) {
    if (real_persons[a].number_problem != real_persons[b].number_problem) {
        return (real_persons[a].number_problem > real_persons[b].number_problem);
    }
    if (real_persons[a].time_resolution != real_persons[b].time_resolution) {
        return (real_persons[a].time_resolution < real_persons[b].time_resolution);
    }
    return (a < b);
}




#endif //EXERCISES_PART2_STL_UVA10258_H
