#include <iostream>
#include "uva10258.h"

int main() {

    vector<Contestant> persons;
    persons.push_back(Contestant(1,2,30,'I'));
    persons.push_back(Contestant(2,3,41,'C'));
    persons.push_back(Contestant(1,1,20,'C'));
    persons.push_back(Contestant(1,1,10,'C'));


    //Imprime toods los datos
    //for(auto&i:persons)i.print();






    return 0;
}
