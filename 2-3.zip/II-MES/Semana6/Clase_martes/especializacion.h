//
// Created by Fabrizio on 5/13/20.
//

#ifndef CLASE_MARTES_ESPECIALIZACION_H
#define CLASE_MARTES_ESPECIALIZACION_H

#include<bits/stdc++.h>
using namespace std;

template<typename T>
struct type_int{
    static const bool value = false;
};


//Especializacion total
template<>
struct type_int<float>{
    static const bool value = false;
};

template<>
struct type_int<int>{
    static const bool value = true;
};

//template generico
template <typename T, typename U>
struct C{
    void get(T param1, U param2){
        cout<<__PRETTY_FUNCTION__<<endl;
    }
};

//Especialización parcial
template<typename T>
struct C<T,T>{
    void get(T param1, T param2){
        cout<<__PRETTY_FUNCTION__<<endl;
    }
};


template<typename ...Types>
auto suma(Types...args){
    return (...+args);
}


template <typename T1 ,typename T2>
struct Change{
    T1 first;
    T2 second;
    Change(const T1& n1, const T2&n2):first(n1),second(n2){
    }
    Change<T2,T1> swap(const Change<T1,T2>& pair){
        return Change<T2,T1>(pair.second,pair.first);
    }

};


#endif //CLASE_MARTES_ESPECIALIZACION_H
