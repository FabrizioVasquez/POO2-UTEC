#include <iostream>
#include "especializacion.h"
#include "Exercises_templates.h"




//TEMA: TEMPLATES
int main() {
    /*
    int valueA = 20;
    float valueB = 30.3;
    Change p1(valueA,valueB);
    auto b = p1.swap(p1);
    cout<<b.second;
    */

    //EXERCISE 2
    //cout<<boolalpha<<comparar(1,1,2,2)<<endl;

    //EXERCISE 3
    //cout<<sum_product(2,4,10,2)<<endl;

    //EXERCISE 4
    int h1 = 90;
    float h2 = 12.12;
    cout<<h1<<" "<<h2<<endl;
    cout<<intercambiar(h1,h2).first<<" "<<intercambiar(h1,h2).second<<endl;

    //EXERCISE 5
    int sum = 0;
    multiples(sum,5,3);
    cout<<sum<<endl;

    //EXERCISE 6
    float c {};
    auto b = init(10,20,c);
    cout<<b;

    //cout<<suma(10.3,10,3);
    return 0;
}
