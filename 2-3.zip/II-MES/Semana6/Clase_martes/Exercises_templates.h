//
// Created by Fabrizio on 5/14/20.
//

#ifndef CLASE_MARTES_EXERCISES_TEMPLATES_H
#define CLASE_MARTES_EXERCISES_TEMPLATES_H

//EXERCISE 1
template < typename T>
bool comparar(T a){
    return false;
}
template <typename T>
bool comparar(T a, T b){
    return a == b;
}

template < typename T, typename ... Types>
bool comparar (T a , T b , Types ... args){
    return a == b && comparar(args...);
}

//EXERCISE 2

/*
template < typename T>
auto sum_product(T a){
    return a;
}*/


template <typename T>
auto sum_product(T a, T b){
    T c = a * b;
    return c;
}

template < typename T, typename ... Args>
auto sum_product(T a , T b, Args ... args ){
    return sum_product(a,b) + sum_product(args...);
}

/*template < typename T, typename ... Args>
auto sum_product(Args ... args,T a){
    return sum_product(args...) + sum_product(a);
}*/

//EXERCISE 4
template < typename T , typename U >
pair<U,T> intercambiar(T &val1 , U &val2){
    return make_pair(val2,val1);
}

//EXERCISE 5
template < typename WhatKind>
void multiples(WhatKind &sum, WhatKind x, int n){
    WhatKind aux = 0;
    sum = (WhatKind) 1;
    for (int i = 0; i < n; ++i) {
        aux += x;
        sum += aux;
    }
}

//EXERCISE 6
template <typename T1, typename T2>
T1 init(T1 num1, T1 num2, T2& start){
    start = T2(0);
    return num1+num2;
}





#endif //CLASE_MARTES_EXERCISES_TEMPLATES_H
