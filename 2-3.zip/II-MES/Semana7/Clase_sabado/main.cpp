#include <iostream>
#include "MaxHeap.h"


int main() {

    MaxHeap b;
    cout<<b.getSize();
    b.push(9);
    b.push(100);
    b.push(1);
    b.push(2);
    b.push(20);


    return 0;
}
