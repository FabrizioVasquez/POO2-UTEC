//
// Created by Fabrizio on 5/23/20.
//

#ifndef CLASE_SABADO_MAXHEAP_H
#define CLASE_SABADO_MAXHEAP_H

#include <iostream>
#include <bits/stdc++.h>
using namespace std;


class MaxHeap {
private:
    vector<int> mheap_;
public:
    MaxHeap(){}

    //Utils
    size_t getF(size_t child){
        if (child % 2 == 0)
            return (child /2);
        else
            return ((child/2)-1);
    }

    auto swap(size_t child, size_t parent){
        int aux = mheap_[child];
        mheap_[child] = mheap_[parent];
        mheap_[parent] = aux;
    }

    size_t getSize(){
        return mheap_.size();
    }

    //Main
    void percolate_up(){
        size_t child = mheap_.size()-1;
        size_t parent = getF(child);
        while (mheap_[child] > mheap_[parent] && child >=0 && parent >= 0) {
            swap(child, parent);
            child = parent;
            parent = getF(child);
        }
    }

    void push(int item){
        mheap_.push_back(item);
        percolate_up();
    }



};


#endif //CLASE_SABADO_MAXHEAP_H
